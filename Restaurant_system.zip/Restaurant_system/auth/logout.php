<?php
// Logout functionality
require_once '../config/session.php';
require_once '../config/functions.php';

// Log the logout activity if user is logged in
if (isLoggedIn()) {
    logActivity('User Logout', 'users', $_SESSION['user_id']);
}

// Destroy the session
destroySession();

// Redirect to login page with success message
header('Location: /Restaurant_system/index.php?success=logout');
exit();
?>