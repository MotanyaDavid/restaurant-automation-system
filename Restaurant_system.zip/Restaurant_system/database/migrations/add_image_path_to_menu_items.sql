-- Migration script to add image_path column to menu_items table
-- This script should be run on the existing database

ALTER TABLE menu_items ADD image_path VARCHAR(255) NULL;

-- Add an index for better performance when querying by image_path
CREATE INDEX idx_image_path ON menu_items (image_path);