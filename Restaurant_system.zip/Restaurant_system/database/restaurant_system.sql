-- Restaurant Automation System Database Schema
-- Created: 2025-08-02
-- Description: Complete database structure for restaurant management system

-- Create database
CREATE DATABASE IF NOT EXISTS restaurant_system;
USE restaurant_system;

-- Set charset and collation
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- =============================================
-- CORE TABLES
-- =============================================

-- 1. Users Table
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(20),
    role ENUM('business_owner', 'manager', 'sales_clerk') NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE SET NULL,
    INDEX idx_username (username),
    INDEX idx_role (role),
    INDEX idx_status (status)
);

-- 2. Financial Settings Table
CREATE TABLE financial_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    available_funds DECIMAL(15,2) DEFAULT 0.00,
    updated_by INT NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (updated_by) REFERENCES users(user_id),
    INDEX idx_updated_at (updated_at)
);

-- 3. Ingredients Table
CREATE TABLE ingredients (
    ingredient_id INT PRIMARY KEY AUTO_INCREMENT,
    ingredient_name VARCHAR(100) NOT NULL,
    ingredient_code VARCHAR(20) UNIQUE NOT NULL,
    unit VARCHAR(20) NOT NULL,
    current_stock DECIMAL(10,2) DEFAULT 0.00,
    threshold_quantity DECIMAL(10,2) NOT NULL DEFAULT 10.00,
    unit_price DECIMAL(10,2) DEFAULT 0.00,
    supplier_info TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_ingredient_code (ingredient_code),
    INDEX idx_stock_threshold (current_stock, threshold_quantity),
    INDEX idx_ingredient_name (ingredient_name)
);

-- 4. Menu Items Table
CREATE TABLE menu_items (
    item_id INT PRIMARY KEY AUTO_INCREMENT,
    item_name VARCHAR(100) NOT NULL,
    item_code VARCHAR(20) UNIQUE NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    category VARCHAR(50) DEFAULT 'Main Course',
    image_path VARCHAR(255) NULL,
    status ENUM('available', 'unavailable') DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_item_code (item_code),
    INDEX idx_category (category),
    INDEX idx_status (status),
    INDEX idx_item_name (item_name)
);

-- 5. Menu Item Ingredients (Recipe) Table
CREATE TABLE menu_item_ingredients (
    id INT PRIMARY KEY AUTO_INCREMENT,
    item_id INT NOT NULL,
    ingredient_id INT NOT NULL,
    quantity_required DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (item_id) REFERENCES menu_items(item_id) ON DELETE CASCADE,
    FOREIGN KEY (ingredient_id) REFERENCES ingredients(ingredient_id) ON DELETE CASCADE,
    UNIQUE KEY unique_item_ingredient (item_id, ingredient_id),
    INDEX idx_item_id (item_id),
    INDEX idx_ingredient_id (ingredient_id)
);

-- 6. Orders Table
CREATE TABLE orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    order_number VARCHAR(20) UNIQUE NOT NULL,
    customer_name VARCHAR(100),
    table_number VARCHAR(10),
    total_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    status ENUM('pending', 'preparing', 'ready', 'served', 'cancelled') DEFAULT 'pending',
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(user_id),
    INDEX idx_order_number (order_number),
    INDEX idx_status (status),
    INDEX idx_created_by (created_by),
    INDEX idx_created_at (created_at),
    INDEX idx_table_number (table_number)
);

-- 7. Order Items Table
CREATE TABLE order_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    item_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (item_id) REFERENCES menu_items(item_id),
    INDEX idx_order_id (order_id),
    INDEX idx_item_id (item_id)
);

-- 8. Purchase Orders Table
CREATE TABLE purchase_orders (
    po_id INT PRIMARY KEY AUTO_INCREMENT,
    po_number VARCHAR(20) UNIQUE NOT NULL,
    supplier_name VARCHAR(100),
    total_amount DECIMAL(10,2) DEFAULT 0.00,
    status ENUM('pending', 'ordered', 'received', 'paid') DEFAULT 'pending',
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(user_id),
    INDEX idx_po_number (po_number),
    INDEX idx_status (status),
    INDEX idx_created_by (created_by),
    INDEX idx_created_at (created_at)
);

-- 9. Purchase Order Items Table
CREATE TABLE purchase_order_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    po_id INT NOT NULL,
    ingredient_id INT NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (po_id) REFERENCES purchase_orders(po_id) ON DELETE CASCADE,
    FOREIGN KEY (ingredient_id) REFERENCES ingredients(ingredient_id),
    INDEX idx_po_id (po_id),
    INDEX idx_ingredient_id (ingredient_id)
);

-- 10. Invoices Table
CREATE TABLE invoices (
    invoice_id INT PRIMARY KEY AUTO_INCREMENT,
    invoice_number VARCHAR(20) UNIQUE NOT NULL,
    po_id INT,
    supplier_name VARCHAR(100) NOT NULL,
    invoice_date DATE NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'paid') DEFAULT 'pending',
    payment_method VARCHAR(50),
    cheque_number VARCHAR(20),
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (po_id) REFERENCES purchase_orders(po_id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES users(user_id),
    INDEX idx_invoice_number (invoice_number),
    INDEX idx_po_id (po_id),
    INDEX idx_status (status),
    INDEX idx_invoice_date (invoice_date),
    INDEX idx_cheque_number (cheque_number)
);

-- 11. Stock Movements Table
CREATE TABLE stock_movements (
    id INT PRIMARY KEY AUTO_INCREMENT,
    ingredient_id INT NOT NULL,
    movement_type ENUM('in', 'out') NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    reference_type ENUM('purchase', 'usage', 'adjustment') NOT NULL,
    reference_id INT,
    notes TEXT,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ingredient_id) REFERENCES ingredients(ingredient_id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(user_id),
    INDEX idx_ingredient_id (ingredient_id),
    INDEX idx_movement_type (movement_type),
    INDEX idx_reference_type (reference_type),
    INDEX idx_created_at (created_at)
);

-- =============================================
-- ADDITIONAL UTILITY TABLES
-- =============================================

-- 12. System Settings Table
CREATE TABLE system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(50) UNIQUE NOT NULL,
    setting_value TEXT,
    description TEXT,
    updated_by INT NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (updated_by) REFERENCES users(user_id),
    INDEX idx_setting_key (setting_key)
);

-- 13. Activity Logs Table
CREATE TABLE activity_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(50),
    record_id INT,
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_action (action),
    INDEX idx_table_name (table_name),
    INDEX idx_created_at (created_at)
);

-- =============================================
-- VIEWS FOR REPORTING
-- =============================================

-- View for low stock ingredients
CREATE VIEW low_stock_ingredients AS
SELECT 
    i.ingredient_id,
    i.ingredient_name,
    i.ingredient_code,
    i.current_stock,
    i.threshold_quantity,
    i.unit,
    (i.threshold_quantity - i.current_stock) AS shortage_quantity
FROM ingredients i
WHERE i.current_stock <= i.threshold_quantity;

-- View for daily sales summary
CREATE VIEW daily_sales_summary AS
SELECT 
    DATE(o.created_at) as sale_date,
    COUNT(o.order_id) as total_orders,
    SUM(o.total_amount) as total_sales,
    AVG(o.total_amount) as average_order_value
FROM orders o
WHERE o.status IN ('served', 'ready')
GROUP BY DATE(o.created_at)
ORDER BY sale_date DESC;

-- View for monthly sales by item
CREATE VIEW monthly_item_sales AS
SELECT 
    YEAR(o.created_at) as year,
    MONTH(o.created_at) as month,
    mi.item_name,
    mi.item_code,
    SUM(oi.quantity) as total_quantity_sold,
    SUM(oi.subtotal) as total_revenue
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
JOIN menu_items mi ON oi.item_id = mi.item_id
WHERE o.status IN ('served', 'ready')
GROUP BY YEAR(o.created_at), MONTH(o.created_at), mi.item_id
ORDER BY year DESC, month DESC, total_revenue DESC;

-- =============================================
-- STORED PROCEDURES
-- =============================================

DELIMITER //

-- Procedure to calculate ingredient threshold based on 3-day average
CREATE PROCEDURE CalculateIngredientThreshold(IN ingredient_id_param INT)
BEGIN
    DECLARE avg_consumption DECIMAL(10,2) DEFAULT 0;
    DECLARE new_threshold DECIMAL(10,2) DEFAULT 0;
    
    -- Calculate average consumption over last 3 days
    SELECT COALESCE(AVG(daily_usage), 0) INTO avg_consumption
    FROM (
        SELECT 
            DATE(sm.created_at) as usage_date,
            SUM(sm.quantity) as daily_usage
        FROM stock_movements sm
        WHERE sm.ingredient_id = ingredient_id_param
        AND sm.movement_type = 'out'
        AND sm.reference_type = 'usage'
        AND sm.created_at >= DATE_SUB(CURDATE(), INTERVAL 3 DAY)
        GROUP BY DATE(sm.created_at)
        ORDER BY usage_date DESC
        LIMIT 3
    ) as daily_consumption;
    
    -- Set threshold to 2 days worth of average consumption
    SET new_threshold = avg_consumption * 2;
    
    -- Ensure minimum threshold of 5 units
    IF new_threshold < 5 THEN
        SET new_threshold = 5;
    END IF;
    
    -- Update the ingredient threshold
    UPDATE ingredients 
    SET threshold_quantity = new_threshold,
        updated_at = CURRENT_TIMESTAMP
    WHERE ingredient_id = ingredient_id_param;
    
END //

-- Procedure to process order and update stock
CREATE PROCEDURE ProcessOrder(IN order_id_param INT)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE item_id_var INT;
    DECLARE quantity_var INT;
    DECLARE ingredient_id_var INT;
    DECLARE required_quantity DECIMAL(10,2);
    
    -- Cursor for order items
    DECLARE order_cursor CURSOR FOR
        SELECT item_id, quantity FROM order_items WHERE order_id = order_id_param;
    
    -- Cursor for ingredients per item
    DECLARE ingredient_cursor CURSOR FOR
        SELECT ingredient_id, quantity_required 
        FROM menu_item_ingredients 
        WHERE item_id = item_id_var;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    -- Start transaction
    START TRANSACTION;
    
    -- Open order cursor
    OPEN order_cursor;
    
    order_loop: LOOP
        FETCH order_cursor INTO item_id_var, quantity_var;
        IF done THEN
            LEAVE order_loop;
        END IF;
        
        -- Reset done flag for inner cursor
        SET done = FALSE;
        
        -- Open ingredient cursor
        OPEN ingredient_cursor;
        
        ingredient_loop: LOOP
            FETCH ingredient_cursor INTO ingredient_id_var, required_quantity;
            IF done THEN
                LEAVE ingredient_loop;
            END IF;
            
            -- Update ingredient stock
            UPDATE ingredients 
            SET current_stock = current_stock - (required_quantity * quantity_var),
                updated_at = CURRENT_TIMESTAMP
            WHERE ingredient_id = ingredient_id_var;
            
            -- Log stock movement
            INSERT INTO stock_movements (
                ingredient_id, movement_type, quantity, reference_type, 
                reference_id, created_by, created_at
            ) VALUES (
                ingredient_id_var, 'out', (required_quantity * quantity_var), 
                'usage', order_id_param, 
                (SELECT created_by FROM orders WHERE order_id = order_id_param),
                CURRENT_TIMESTAMP
            );
            
        END LOOP ingredient_loop;
        
        CLOSE ingredient_cursor;
        SET done = FALSE;
        
    END LOOP order_loop;
    
    CLOSE order_cursor;
    
    -- Update order status
    UPDATE orders 
    SET status = 'preparing', updated_at = CURRENT_TIMESTAMP 
    WHERE order_id = order_id_param;
    
    COMMIT;
    
END //

DELIMITER ;

-- =============================================
-- TRIGGERS
-- =============================================

-- Trigger to update order total when order items change
DELIMITER //
CREATE TRIGGER update_order_total_after_insert
AFTER INSERT ON order_items
FOR EACH ROW
BEGIN
    UPDATE orders 
    SET total_amount = (
        SELECT SUM(subtotal) 
        FROM order_items 
        WHERE order_id = NEW.order_id
    ),
    updated_at = CURRENT_TIMESTAMP
    WHERE order_id = NEW.order_id;
END //

CREATE TRIGGER update_order_total_after_update
AFTER UPDATE ON order_items
FOR EACH ROW
BEGIN
    UPDATE orders 
    SET total_amount = (
        SELECT SUM(subtotal) 
        FROM order_items 
        WHERE order_id = NEW.order_id
    ),
    updated_at = CURRENT_TIMESTAMP
    WHERE order_id = NEW.order_id;
END //

CREATE TRIGGER update_order_total_after_delete
AFTER DELETE ON order_items
FOR EACH ROW
BEGIN
    UPDATE orders 
    SET total_amount = (
        SELECT COALESCE(SUM(subtotal), 0) 
        FROM order_items 
        WHERE order_id = OLD.order_id
    ),
    updated_at = CURRENT_TIMESTAMP
    WHERE order_id = OLD.order_id;
END //

-- Trigger to update purchase order total
CREATE TRIGGER update_po_total_after_insert
AFTER INSERT ON purchase_order_items
FOR EACH ROW
BEGIN
    UPDATE purchase_orders 
    SET total_amount = (
        SELECT SUM(subtotal) 
        FROM purchase_order_items 
        WHERE po_id = NEW.po_id
    ),
    updated_at = CURRENT_TIMESTAMP
    WHERE po_id = NEW.po_id;
END //

DELIMITER ;

-- =============================================
-- SAMPLE DATA
-- =============================================

-- Insert default business owner
INSERT INTO users (username, password, full_name, email, role, status) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'admin@restaurant.com', 'business_owner', 'active');

-- Insert initial financial settings
INSERT INTO financial_settings (available_funds, updated_by) VALUES
(50000.00, 1);

-- Insert system settings
INSERT INTO system_settings (setting_key, setting_value, description, updated_by) VALUES
('restaurant_name', 'Delicious Restaurant', 'Name of the restaurant', 1),
('currency', 'KES', 'Currency symbol', 1),
('tax_rate', '16.00', 'Tax rate percentage', 1),
('min_stock_days', '2', 'Minimum stock days to maintain', 1),
('threshold_calculation_days', '3', 'Days to consider for threshold calculation', 1);

-- Insert sample ingredients
INSERT INTO ingredients (ingredient_name, ingredient_code, unit, current_stock, threshold_quantity, unit_price, supplier_info) VALUES
('Rice', 'ING001', 'kg', 50.00, 10.00, 120.00, 'Local Supplier - Contact: 0712345678'),
('Chicken Breast', 'ING002', 'kg', 25.00, 8.00, 450.00, 'Meat Supplier Ltd - Contact: 0723456789'),
('Tomatoes', 'ING003', 'kg', 15.00, 5.00, 80.00, 'Fresh Produce Co - Contact: 0734567890'),
('Onions', 'ING004', 'kg', 20.00, 6.00, 60.00, 'Fresh Produce Co - Contact: 0734567890'),
('Cooking Oil', 'ING005', 'liters', 10.00, 3.00, 200.00, 'Oil Distributors - Contact: 0745678901'),
('Salt', 'ING006', 'kg', 5.00, 2.00, 50.00, 'Spice Traders - Contact: 0756789012'),
('Black Pepper', 'ING007', 'kg', 2.00, 1.00, 800.00, 'Spice Traders - Contact: 0756789012'),
('Bread', 'ING008', 'loaves', 20.00, 5.00, 45.00, 'Bakery Supplies - Contact: 0767890123');

-- Insert sample menu items
INSERT INTO menu_items (item_name, item_code, description, price, category, image_path, status) VALUES
('Chicken Rice', 'MENU001', 'Delicious chicken served with rice', 350.00, 'Main Course', NULL, 'available'),
('Chicken Burger', 'MENU002', 'Grilled chicken burger with fresh vegetables', 280.00, 'Fast Food', NULL, 'available'),
('Fried Rice', 'MENU003', 'Special fried rice with vegetables', 250.00, 'Main Course', NULL, 'available'),
('Chicken Sandwich', 'MENU004', 'Fresh chicken sandwich with tomatoes', 200.00, 'Light Meals', NULL, 'available');

-- Insert menu item ingredients (recipes)
INSERT INTO menu_item_ingredients (item_id, ingredient_id, quantity_required) VALUES
-- Chicken Rice
(1, 1, 0.2),  -- Rice
(1, 2, 0.15), -- Chicken Breast
(1, 3, 0.05), -- Tomatoes
(1, 4, 0.03), -- Onions
(1, 5, 0.02), -- Cooking Oil
(1, 6, 0.01), -- Salt
(1, 7, 0.005), -- Black Pepper

-- Chicken Burger
(2, 2, 0.12), -- Chicken Breast
(2, 8, 1),    -- Bread (1 loaf = 2 buns)
(2, 3, 0.03), -- Tomatoes
(2, 4, 0.02), -- Onions
(2, 5, 0.01), -- Cooking Oil

-- Fried Rice
(3, 1, 0.25), -- Rice
(3, 3, 0.04), -- Tomatoes
(3, 4, 0.04), -- Onions
(3, 5, 0.03), -- Cooking Oil
(3, 6, 0.01), -- Salt

-- Chicken Sandwich
(4, 2, 0.08), -- Chicken Breast
(4, 8, 0.5),  -- Bread
(4, 3, 0.02), -- Tomatoes
(4, 5, 0.01); -- Cooking Oil

-- Enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;

-- =============================================
-- INDEXES FOR PERFORMANCE
-- =============================================

-- Additional indexes for better performance
CREATE INDEX idx_orders_date_status ON orders(created_at, status);
CREATE INDEX idx_stock_movements_date ON stock_movements(created_at);
CREATE INDEX idx_ingredients_stock_status ON ingredients(current_stock, threshold_quantity);
CREATE INDEX idx_menu_items_category_status ON menu_items(category, status);

-- =============================================
-- COMPLETION MESSAGE
-- =============================================

SELECT 'Restaurant System Database Created Successfully!' as Status,
       'Default admin user: admin / password: password' as Login_Info,
       'Initial funds: KES 50,000' as Financial_Status;