<?php
// Business Owner - User Management
$page_title = 'User Management';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/business_owner/'],
    ['title' => 'User Management', 'url' => '']
];

require_once '../../common/header.php';
requireRole('business_owner');

// Handle form submissions
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!validateCSRFToken($csrf_token)) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        try {
            $pdo = getPDO();
            
            switch ($action) {
                case 'add_user':
                    $username = sanitizeInput($_POST['username']);
                    $password = $_POST['password'];
                    $full_name = sanitizeInput($_POST['full_name']);
                    $email = sanitizeInput($_POST['email']);
                    $phone = sanitizeInput($_POST['phone']);
                    $role = $_POST['role'];
                    
                    // Validate input
                    if (empty($username) || empty($password) || empty($full_name) || empty($role)) {
                        throw new Exception('Please fill in all required fields.');
                    }
                    
                    if (!isStrongPassword($password)) {
                        throw new Exception('Password must be at least 8 characters long and contain uppercase, lowercase, and numbers.');
                    }
                    
                    if (!empty($email) && !isValidEmail($email)) {
                        throw new Exception('Please enter a valid email address.');
                    }
                    
                    if (!in_array($role, ['manager', 'sales_clerk'])) {
                        throw new Exception('Invalid role selected.');
                    }
                    
                    // Check if username already exists
                    $stmt = $pdo->prepare("SELECT user_id FROM users WHERE username = ?");
                    $stmt->execute([$username]);
                    if ($stmt->fetch()) {
                        throw new Exception('Username already exists. Please choose a different username.');
                    }
                    
                    // Insert new user
                    $stmt = $pdo->prepare("
                        INSERT INTO users (username, password, full_name, email, phone, role, created_by)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ");
                    
                    $stmt->execute([
                        $username,
                        hashPassword($password),
                        $full_name,
                        $email,
                        $phone,
                        $role,
                        $_SESSION['user_id']
                    ]);
                    
                    logActivity('User Created', 'users', $pdo->lastInsertId(), null, [
                        'username' => $username,
                        'role' => $role
                    ]);
                    
                    $success_message = 'User created successfully!';
                    break;
                    
                case 'update_user':
                    $user_id = intval($_POST['user_id']);
                    $full_name = sanitizeInput($_POST['full_name']);
                    $email = sanitizeInput($_POST['email']);
                    $phone = sanitizeInput($_POST['phone']);
                    $role = $_POST['role'];
                    $status = $_POST['status'];
                    
                    // Validate input
                    if (empty($full_name) || empty($role)) {
                        throw new Exception('Please fill in all required fields.');
                    }
                    
                    if (!empty($email) && !isValidEmail($email)) {
                        throw new Exception('Please enter a valid email address.');
                    }
                    
                    if (!in_array($role, ['manager', 'sales_clerk'])) {
                        throw new Exception('Invalid role selected.');
                    }
                    
                    if (!in_array($status, ['active', 'inactive'])) {
                        throw new Exception('Invalid status selected.');
                    }
                    
                    // Get old values for logging
                    $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
                    $stmt->execute([$user_id]);
                    $old_user = $stmt->fetch();
                    
                    if (!$old_user) {
                        throw new Exception('User not found.');
                    }
                    
                    // Update user
                    $stmt = $pdo->prepare("
                        UPDATE users 
                        SET full_name = ?, email = ?, phone = ?, role = ?, status = ?
                        WHERE user_id = ?
                    ");
                    
                    $stmt->execute([$full_name, $email, $phone, $role, $status, $user_id]);
                    
                    logActivity('User Updated', 'users', $user_id, $old_user, [
                        'full_name' => $full_name,
                        'email' => $email,
                        'phone' => $phone,
                        'role' => $role,
                        'status' => $status
                    ]);
                    
                    $success_message = 'User updated successfully!';
                    break;
                    
                case 'reset_password':
                    $user_id = intval($_POST['user_id']);
                    $new_password = $_POST['new_password'];
                    
                    if (empty($new_password)) {
                        throw new Exception('Please enter a new password.');
                    }
                    
                    if (!isStrongPassword($new_password)) {
                        throw new Exception('Password must be at least 8 characters long and contain uppercase, lowercase, and numbers.');
                    }
                    
                    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE user_id = ?");
                    $stmt->execute([hashPassword($new_password), $user_id]);
                    
                    logActivity('Password Reset', 'users', $user_id);
                    
                    $success_message = 'Password reset successfully!';
                    break;
                    
                case 'delete_user':
                    $user_id = intval($_POST['user_id']);
                    
                    // Get user details before deletion
                    $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
                    $stmt->execute([$user_id]);
                    $user_to_delete = $stmt->fetch();
                    
                    if (!$user_to_delete) {
                        throw new Exception('User not found.');
                    }
                    
                    // Prevent deletion of business owner accounts
                    if ($user_to_delete['role'] === 'business_owner') {
                        throw new Exception('Cannot delete business owner accounts.');
                    }
                    
                    // Prevent self-deletion
                    if ($user_id == $_SESSION['user_id']) {
                        throw new Exception('You cannot delete your own account.');
                    }
                    
                    $pdo->beginTransaction();
                    
                    // Check if user has any orders
                    $stmt = $pdo->prepare("SELECT COUNT(*) as order_count FROM orders WHERE created_by = ?");
                    $stmt->execute([$user_id]);
                    $order_count = $stmt->fetch()['order_count'];
                    
                    if ($order_count > 0) {
                        // Instead of deleting, deactivate the user to preserve data integrity
                        $stmt = $pdo->prepare("UPDATE users SET status = 'inactive' WHERE user_id = ?");
                        $stmt->execute([$user_id]);
                        
                        logActivity('User Deactivated', 'users', $user_id, $user_to_delete, [
                            'reason' => 'Has existing orders - deactivated instead of deleted',
                            'order_count' => $order_count
                        ]);
                        
                        $success_message = "User deactivated instead of deleted due to existing orders ({$order_count} orders).";
                    } else {
                        // Safe to delete - no orders associated
                        $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = ?");
                        $stmt->execute([$user_id]);
                        
                        logActivity('User Deleted', 'users', $user_id, $user_to_delete, [
                            'username' => $user_to_delete['username'],
                            'full_name' => $user_to_delete['full_name'],
                            'role' => $user_to_delete['role']
                        ]);
                        
                        $success_message = 'User deleted successfully!';
                    }
                    
                    $pdo->commit();
                    break;
            }
            
        } catch (Exception $e) {
            $error_message = $e->getMessage();
            logError($error_message);
        }
    }
}

// Get all users (excluding business owners)
try {
    $pdo = getPDO();
    $stmt = $pdo->prepare("
        SELECT u.*, creator.full_name as created_by_name
        FROM users u
        LEFT JOIN users creator ON u.created_by = creator.user_id
        WHERE u.role IN ('manager', 'sales_clerk')
        ORDER BY u.created_at DESC
    ");
    $stmt->execute();
    $users = $stmt->fetchAll();
} catch (Exception $e) {
    $error_message = "Error loading users: " . $e->getMessage();
    $users = [];
}

$csrf_token = generateCSRFToken();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">User Management</h1>
        <p class="text-muted">Manage managers and sales clerks</p>
    </div>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addUserModal">
        <i class="fas fa-plus me-2"></i>Add New User
    </button>
</div>

<?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i>
        <?php echo htmlspecialchars($success_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error_message): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Users Table -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-users me-2"></i>
            System Users
        </h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover data-table">
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Role</th>
                        <th>Contact</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="avatar-circle me-3">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <div>
                                        <strong><?php echo htmlspecialchars($user['full_name']); ?></strong>
                                        <br>
                                        <small class="text-muted">@<?php echo htmlspecialchars($user['username']); ?></small>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo $user['role'] === 'manager' ? 'info' : 'success'; ?>">
                                    <?php echo getRoleDisplayName($user['role']); ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($user['email']): ?>
                                    <div><i class="fas fa-envelope me-1"></i> <?php echo htmlspecialchars($user['email']); ?></div>
                                <?php endif; ?>
                                <?php if ($user['phone']): ?>
                                    <div><i class="fas fa-phone me-1"></i> <?php echo htmlspecialchars($user['phone']); ?></div>
                                <?php endif; ?>
                                <?php if (!$user['email'] && !$user['phone']): ?>
                                    <span class="text-muted">No contact info</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo $user['status'] === 'active' ? 'success' : 'danger'; ?>">
                                    <?php echo ucfirst($user['status']); ?>
                                </span>
                            </td>
                            <td>
                                <div><?php echo formatDisplayDate($user['created_at']); ?></div>
                                <?php if ($user['created_by_name']): ?>
                                    <small class="text-muted">by <?php echo htmlspecialchars($user['created_by_name']); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <button type="button" class="btn btn-sm btn-outline-primary"
                                            onclick="editUser(<?php echo htmlspecialchars(json_encode($user)); ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-warning"
                                            onclick="resetPassword(<?php echo $user['user_id']; ?>, '<?php echo htmlspecialchars($user['full_name']); ?>')">
                                        <i class="fas fa-key"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-danger"
                                            onclick="deleteUser(<?php echo $user['user_id']; ?>, '<?php echo htmlspecialchars($user['full_name']); ?>', '<?php echo htmlspecialchars($user['username']); ?>')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add User Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-user-plus me-2"></i>Add New User
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="add_user">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="username" class="form-label">Username *</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                            <div class="invalid-feedback">Please enter a username.</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="role" class="form-label">Role *</label>
                            <select class="form-select" id="role" name="role" required>
                                <option value="">Select Role</option>
                                <option value="manager">Manager</option>
                                <option value="sales_clerk">Sales Clerk</option>
                            </select>
                            <div class="invalid-feedback">Please select a role.</div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="full_name" class="form-label">Full Name *</label>
                        <input type="text" class="form-control" id="full_name" name="full_name" required>
                        <div class="invalid-feedback">Please enter the full name.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">Password *</label>
                        <input type="password" class="form-control" id="password" name="password" required minlength="8">
                        <div class="form-text">Must be at least 8 characters with uppercase, lowercase, and numbers.</div>
                        <div class="invalid-feedback">Please enter a strong password.</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="phone" class="form-label">Phone</label>
                            <input type="tel" class="form-control" id="phone" name="phone">
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Create User
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit User Modal -->
<div class="modal fade" id="editUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-user-edit me-2"></i>Edit User
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="update_user">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="user_id" id="edit_user_id">
                
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="edit_role" class="form-label">Role *</label>
                            <select class="form-select" id="edit_role" name="role" required>
                                <option value="manager">Manager</option>
                                <option value="sales_clerk">Sales Clerk</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="edit_status" class="form-label">Status *</label>
                            <select class="form-select" id="edit_status" name="status" required>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_full_name" class="form-label">Full Name *</label>
                        <input type="text" class="form-control" id="edit_full_name" name="full_name" required>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="edit_email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="edit_email" name="email">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="edit_phone" class="form-label">Phone</label>
                            <input type="tel" class="form-control" id="edit_phone" name="phone">
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Update User
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Reset Password Modal -->
<div class="modal fade" id="resetPasswordModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-key me-2"></i>Reset Password
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="reset_password">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="user_id" id="reset_user_id">
                
                <div class="modal-body">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        You are about to reset the password for <strong id="reset_user_name"></strong>.
                    </div>
                    
                    <div class="mb-3">
                        <label for="new_password" class="form-label">New Password *</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" required minlength="8">
                        <div class="form-text">Must be at least 8 characters with uppercase, lowercase, and numbers.</div>
                        <div class="invalid-feedback">Please enter a strong password.</div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning">
                        <i class="fas fa-key me-2"></i>Reset Password
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete User Modal -->
<div class="modal fade" id="deleteUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-trash me-2"></i>Delete User
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="delete_user">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="user_id" id="delete_user_id">
                
                <div class="modal-body">
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <strong>Warning!</strong> This action cannot be undone.
                    </div>
                    
                    <p>You are about to delete the following user:</p>
                    <ul class="list-unstyled">
                        <li><strong>Name:</strong> <span id="delete_user_name"></span></li>
                        <li><strong>Username:</strong> <span id="delete_user_username"></span></li>
                    </ul>
                    
                    <p>Are you sure you want to proceed with this deletion?</p>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-trash me-2"></i>Delete User
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$additional_js = "
<script>
function editUser(user) {
    document.getElementById('edit_user_id').value = user.user_id;
    document.getElementById('edit_full_name').value = user.full_name;
    document.getElementById('edit_email').value = user.email || '';
    document.getElementById('edit_phone').value = user.phone || '';
    document.getElementById('edit_role').value = user.role;
    document.getElementById('edit_status').value = user.status;
    
    new bootstrap.Modal(document.getElementById('editUserModal')).show();
}

function resetPassword(userId, userName) {
    document.getElementById('reset_user_id').value = userId;
    document.getElementById('reset_user_name').textContent = userName;
    document.getElementById('new_password').value = '';
    
    new bootstrap.Modal(document.getElementById('resetPasswordModal')).show();
}

function deleteUser(userId, userName, username) {
    document.getElementById('delete_user_id').value = userId;
    document.getElementById('delete_user_name').textContent = userName;
    document.getElementById('delete_user_username').textContent = username;
    
    new bootstrap.Modal(document.getElementById('deleteUserModal')).show();
}

// Avatar circle styling
document.addEventListener('DOMContentLoaded', function() {
    const style = document.createElement('style');
    style.textContent = `
        .avatar-circle {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1rem;
        }
    `;
    document.head.appendChild(style);
});
</script>
";

require_once '../../common/footer.php';
?>