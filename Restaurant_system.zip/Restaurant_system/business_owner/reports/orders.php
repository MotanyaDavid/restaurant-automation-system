<?php
// Business Owner - Orders Report
$page_title = 'Orders Report';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/business_owner/'],
    ['title' => 'Orders Report', 'url' => '']
];

require_once '../../common/header.php';
requireRole('business_owner');

// Get filter parameters
$date_from = $_GET['date_from'] ?? date('Y-m-01'); // First day of current month
$date_to = $_GET['date_to'] ?? date('Y-m-d'); // Today
$status_filter = $_GET['status'] ?? '';
$clerk_filter = $_GET['clerk'] ?? '';

try {
    $pdo = getPDO();
    
    // Build query with filters
    $where_conditions = ["DATE(o.created_at) BETWEEN ? AND ?"];
    $params = [$date_from, $date_to];
    
    if (!empty($status_filter)) {
        $where_conditions[] = "o.status = ?";
        $params[] = $status_filter;
    }
    
    if (!empty($clerk_filter)) {
        $where_conditions[] = "o.created_by = ?";
        $params[] = $clerk_filter;
    }
    
    $where_clause = 'WHERE ' . implode(' AND ', $where_conditions);
    
    // Get orders with filters
    $stmt = $pdo->prepare("
        SELECT o.*, u.full_name as clerk_name,
               COUNT(oi.id) as item_count
        FROM orders o
        JOIN users u ON o.created_by = u.user_id
        LEFT JOIN order_items oi ON o.order_id = oi.order_id
        $where_clause
        GROUP BY o.order_id
        ORDER BY o.created_at DESC
    ");
    $stmt->execute($params);
    $orders = $stmt->fetchAll();
    
    // Get summary statistics
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_orders,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_orders,
            SUM(CASE WHEN status = 'preparing' THEN 1 ELSE 0 END) as preparing_orders,
            SUM(CASE WHEN status = 'ready' THEN 1 ELSE 0 END) as ready_orders,
            SUM(CASE WHEN status = 'served' THEN 1 ELSE 0 END) as served_orders,
            SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_orders,
            COALESCE(SUM(CASE WHEN status IN ('served', 'ready') THEN total_amount ELSE 0 END), 0) as total_revenue,
            COALESCE(AVG(CASE WHEN status IN ('served', 'ready') THEN total_amount ELSE NULL END), 0) as avg_order_value
        FROM orders o
        $where_clause
    ");
    $stmt->execute($params);
    $summary = $stmt->fetch();
    
    // Get daily breakdown
    $stmt = $pdo->prepare("
        SELECT 
            DATE(o.created_at) as order_date,
            COUNT(*) as orders_count,
            COALESCE(SUM(CASE WHEN status IN ('served', 'ready') THEN total_amount ELSE 0 END), 0) as daily_revenue
        FROM orders o
        $where_clause
        GROUP BY DATE(o.created_at)
        ORDER BY order_date DESC
    ");
    $stmt->execute($params);
    $daily_breakdown = $stmt->fetchAll();
    
    // Get sales clerks for filter
    $stmt = $pdo->prepare("
        SELECT user_id, full_name 
        FROM users 
        WHERE role = 'sales_clerk' AND status = 'active'
        ORDER BY full_name
    ");
    $stmt->execute();
    $sales_clerks = $stmt->fetchAll();
    
} catch (Exception $e) {
    $error_message = "Error loading orders report: " . $e->getMessage();
    $orders = [];
    $summary = [];
    $daily_breakdown = [];
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Orders Report</h1>
        <p class="text-muted">Comprehensive orders analysis and reporting</p>
    </div>
    <div>
        <button type="button" class="btn btn-success" onclick="exportReport()">
            <i class="fas fa-download me-2"></i>Export Report
        </button>
    </div>
</div>

<?php if (isset($error_message)): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
    </div>
<?php endif; ?>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-filter me-2"></i>Report Filters
        </h5>
    </div>
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-3">
                <label for="date_from" class="form-label">From Date</label>
                <input type="date" class="form-control" id="date_from" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>">
            </div>
            
            <div class="col-md-3">
                <label for="date_to" class="form-label">To Date</label>
                <input type="date" class="form-control" id="date_to" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>">
            </div>
            
            <div class="col-md-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="">All Statuses</option>
                    <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                    <option value="preparing" <?php echo $status_filter === 'preparing' ? 'selected' : ''; ?>>Preparing</option>
                    <option value="ready" <?php echo $status_filter === 'ready' ? 'selected' : ''; ?>>Ready</option>
                    <option value="served" <?php echo $status_filter === 'served' ? 'selected' : ''; ?>>Served</option>
                    <option value="cancelled" <?php echo $status_filter === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                </select>
            </div>
            
            <div class="col-md-3">
                <label for="clerk" class="form-label">Sales Clerk</label>
                <select class="form-select" id="clerk" name="clerk">
                    <option value="">All Clerks</option>
                    <?php foreach ($sales_clerks as $clerk): ?>
                        <option value="<?php echo $clerk['user_id']; ?>" <?php echo $clerk_filter == $clerk['user_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($clerk['full_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-12">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search me-2"></i>Generate Report
                </button>
                <a href="/Restaurant_system/business_owner/reports/orders.php" class="btn btn-outline-secondary">
                    <i class="fas fa-times me-2"></i>Clear Filters
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Summary Statistics -->
<div class="row mb-4">
    <div class="col-xl-2 col-md-4 mb-3">
        <div class="stats-card">
            <div class="text-center">
                <h4 class="text-primary mb-1"><?php echo $summary['total_orders'] ?? 0; ?></h4>
                <small class="text-muted">Total Orders</small>
            </div>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 mb-3">
        <div class="stats-card">
            <div class="text-center">
                <h4 class="text-success mb-1"><?php echo formatCurrency($summary['total_revenue'] ?? 0); ?></h4>
                <small class="text-muted">Total Revenue</small>
            </div>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 mb-3">
        <div class="stats-card">
            <div class="text-center">
                <h4 class="text-info mb-1"><?php echo formatCurrency($summary['avg_order_value'] ?? 0); ?></h4>
                <small class="text-muted">Avg Order Value</small>
            </div>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 mb-3">
        <div class="stats-card">
            <div class="text-center">
                <h4 class="text-success mb-1"><?php echo $summary['served_orders'] ?? 0; ?></h4>
                <small class="text-muted">Served</small>
            </div>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 mb-3">
        <div class="stats-card">
            <div class="text-center">
                <h4 class="text-warning mb-1"><?php echo $summary['pending_orders'] ?? 0; ?></h4>
                <small class="text-muted">Pending</small>
            </div>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 mb-3">
        <div class="stats-card">
            <div class="text-center">
                <h4 class="text-danger mb-1"><?php echo $summary['cancelled_orders'] ?? 0; ?></h4>
                <small class="text-muted">Cancelled</small>
            </div>
        </div>
    </div>
</div>

<!-- Daily Breakdown Chart -->
<?php if (!empty($daily_breakdown)): ?>
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-chart-line me-2"></i>Daily Revenue Trend
                </h5>
            </div>
            <div class="card-body">
                <canvas id="dailyRevenueChart" height="100"></canvas>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Orders Table -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-list me-2"></i>
            Orders Details (<?php echo count($orders); ?> orders)
        </h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover data-table">
                <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Customer</th>
                        <th>Items</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Sales Clerk</th>
                        <th>Date/Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($order['order_number']); ?></strong>
                            </td>
                            <td>
                                <?php echo htmlspecialchars($order['customer_name'] ?: 'Walk-in'); ?>
                                <?php if ($order['customer_phone']): ?>
                                    <br><small class="text-muted"><?php echo htmlspecialchars($order['customer_phone']); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-info"><?php echo $order['item_count']; ?> items</span>
                            </td>
                            <td>
                                <strong><?php echo formatCurrency($order['total_amount']); ?></strong>
                            </td>
                            <td>
                                <?php
                                $status_classes = [
                                    'pending' => 'warning',
                                    'preparing' => 'info',
                                    'ready' => 'primary',
                                    'served' => 'success',
                                    'cancelled' => 'danger'
                                ];
                                ?>
                                <span class="badge bg-<?php echo $status_classes[$order['status']] ?? 'secondary'; ?>">
                                    <?php echo ucfirst($order['status']); ?>
                                </span>
                            </td>
                            <td>
                                <?php echo htmlspecialchars($order['clerk_name']); ?>
                            </td>
                            <td>
                                <small><?php echo formatDisplayDateTime($order['created_at']); ?></small>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
$additional_js = "
<script>
function exportReport() {
    const params = new URLSearchParams(window.location.search);
    params.set('export', 'csv');
    window.location.href = window.location.pathname + '?' + params.toString();
}

// Daily Revenue Chart
" . (!empty($daily_breakdown) ? "
const dailyCtx = document.getElementById('dailyRevenueChart').getContext('2d');
const dailyChart = new Chart(dailyCtx, {
    type: 'line',
    data: {
        labels: [" . implode(',', array_map(function($item) { return "'" . date('M d', strtotime($item['order_date'])) . "'"; }, $daily_breakdown)) . "],
        datasets: [{
            label: 'Daily Revenue',
            data: [" . implode(',', array_column($daily_breakdown, 'daily_revenue')) . "],
            borderColor: '#28a745',
            backgroundColor: 'rgba(40, 167, 69, 0.1)',
            borderWidth: 3,
            fill: true,
            tension: 0.4
        }, {
            label: 'Orders Count',
            data: [" . implode(',', array_column($daily_breakdown, 'orders_count')) . "],
            borderColor: '#007bff',
            backgroundColor: 'rgba(0, 123, 255, 0.1)',
            borderWidth: 2,
            fill: false,
            yAxisID: 'y1'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Revenue (KES)'
                },
                ticks: {
                    callback: function(value) {
                        return 'KES ' + value.toLocaleString();
                    }
                }
            },
            y1: {
                type: 'linear',
                display: true,
                position: 'right',
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Orders Count'
                },
                grid: {
                    drawOnChartArea: false,
                }
            }
        },
        plugins: {
            tooltip: {
                callbacks: {
                    label: function(context) {
                        if (context.dataset.label === 'Daily Revenue') {
                            return 'Revenue: KES ' + context.parsed.y.toLocaleString();
                        }
                        return context.dataset.label + ': ' + context.parsed.y;
                    }
                }
            }
        }
    }
});
" : "") . "

// Initialize DataTable
document.addEventListener('DOMContentLoaded', function() {
    if (typeof $ !== 'undefined' && $.fn.DataTable) {
        $('.data-table').DataTable({
            responsive: true,
            pageLength: 25,
            order: [[6, 'desc']], // Sort by date/time descending
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ]
        });
    }
});
</script>
";

require_once '../../common/footer.php';
?>