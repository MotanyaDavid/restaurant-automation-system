<?php
// Business Owner - Sales Report
$page_title = 'Sales Report';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/business_owner/'],
    ['title' => 'Sales Report', 'url' => '']
];

require_once '../../common/header.php';
requireRole('business_owner');

// Get filter parameters
$date_from = $_GET['date_from'] ?? date('Y-m-01'); // First day of current month
$date_to = $_GET['date_to'] ?? date('Y-m-d'); // Today
$report_type = $_GET['report_type'] ?? 'daily';

try {
    $pdo = getPDO();
    
    // Get sales summary
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_orders,
            COALESCE(SUM(total_amount), 0) as total_revenue,
            COALESCE(AVG(total_amount), 0) as avg_order_value,
            COUNT(DISTINCT created_by) as active_clerks
        FROM orders 
        WHERE DATE(created_at) BETWEEN ? AND ?
        AND status IN ('served', 'ready')
    ");
    $stmt->execute([$date_from, $date_to]);
    $sales_summary = $stmt->fetch();
    
    // Get sales by period
    if ($report_type === 'daily') {
        $stmt = $pdo->prepare("
            SELECT 
                DATE(created_at) as period,
                COUNT(*) as orders_count,
                COALESCE(SUM(total_amount), 0) as revenue
            FROM orders 
            WHERE DATE(created_at) BETWEEN ? AND ?
            AND status IN ('served', 'ready')
            GROUP BY DATE(created_at)
            ORDER BY period DESC
        ");
    } elseif ($report_type === 'monthly') {
        $stmt = $pdo->prepare("
            SELECT 
                DATE_FORMAT(created_at, '%Y-%m') as period,
                COUNT(*) as orders_count,
                COALESCE(SUM(total_amount), 0) as revenue
            FROM orders 
            WHERE DATE(created_at) BETWEEN ? AND ?
            AND status IN ('served', 'ready')
            GROUP BY DATE_FORMAT(created_at, '%Y-%m')
            ORDER BY period DESC
        ");
    } else { // weekly
        $stmt = $pdo->prepare("
            SELECT 
                YEARWEEK(created_at) as period,
                COUNT(*) as orders_count,
                COALESCE(SUM(total_amount), 0) as revenue
            FROM orders 
            WHERE DATE(created_at) BETWEEN ? AND ?
            AND status IN ('served', 'ready')
            GROUP BY YEARWEEK(created_at)
            ORDER BY period DESC
        ");
    }
    $stmt->execute([$date_from, $date_to]);
    $sales_by_period = $stmt->fetchAll();
    
    // Get top selling items
    $stmt = $pdo->prepare("
        SELECT 
            mi.item_name,
            mi.category,
            SUM(oi.quantity) as total_sold,
            COALESCE(SUM(oi.subtotal), 0) as total_revenue
        FROM order_items oi
        JOIN menu_items mi ON oi.item_id = mi.item_id
        JOIN orders o ON oi.order_id = o.order_id
        WHERE DATE(o.created_at) BETWEEN ? AND ?
        AND o.status IN ('served', 'ready')
        GROUP BY mi.item_id
        ORDER BY total_sold DESC
        LIMIT 10
    ");
    $stmt->execute([$date_from, $date_to]);
    $top_items = $stmt->fetchAll();
    
    // Get sales by clerk
    $stmt = $pdo->prepare("
        SELECT 
            u.full_name,
            COUNT(*) as orders_count,
            COALESCE(SUM(o.total_amount), 0) as revenue
        FROM orders o
        JOIN users u ON o.created_by = u.user_id
        WHERE DATE(o.created_at) BETWEEN ? AND ?
        AND o.status IN ('served', 'ready')
        GROUP BY u.user_id
        ORDER BY revenue DESC
    ");
    $stmt->execute([$date_from, $date_to]);
    $sales_by_clerk = $stmt->fetchAll();
    
    // Get sales by category
    $stmt = $pdo->prepare("
        SELECT 
            mi.category,
            COUNT(*) as orders_count,
            SUM(oi.quantity) as items_sold,
            COALESCE(SUM(oi.subtotal), 0) as revenue
        FROM order_items oi
        JOIN menu_items mi ON oi.item_id = mi.item_id
        JOIN orders o ON oi.order_id = o.order_id
        WHERE DATE(o.created_at) BETWEEN ? AND ?
        AND o.status IN ('served', 'ready')
        GROUP BY mi.category
        ORDER BY revenue DESC
    ");
    $stmt->execute([$date_from, $date_to]);
    $sales_by_category = $stmt->fetchAll();
    
} catch (Exception $e) {
    $error_message = "Error loading sales report: " . $e->getMessage();
    $sales_summary = [];
    $sales_by_period = [];
    $top_items = [];
    $sales_by_clerk = [];
    $sales_by_category = [];
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Sales Report</h1>
        <p class="text-muted">Comprehensive sales analysis and performance metrics</p>
    </div>
    <div>
        <button type="button" class="btn btn-success" onclick="exportReport()">
            <i class="fas fa-download me-2"></i>Export Report
        </button>
    </div>
</div>

<?php if (isset($error_message)): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
    </div>
<?php endif; ?>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-filter me-2"></i>Report Filters
        </h5>
    </div>
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-4">
                <label for="date_from" class="form-label">From Date</label>
                <input type="date" class="form-control" id="date_from" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>">
            </div>
            
            <div class="col-md-4">
                <label for="date_to" class="form-label">To Date</label>
                <input type="date" class="form-control" id="date_to" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>">
            </div>
            
            <div class="col-md-4">
                <label for="report_type" class="form-label">Report Type</label>
                <select class="form-select" id="report_type" name="report_type">
                    <option value="daily" <?php echo $report_type === 'daily' ? 'selected' : ''; ?>>Daily</option>
                    <option value="weekly" <?php echo $report_type === 'weekly' ? 'selected' : ''; ?>>Weekly</option>
                    <option value="monthly" <?php echo $report_type === 'monthly' ? 'selected' : ''; ?>>Monthly</option>
                </select>
            </div>
            
            <div class="col-12">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search me-2"></i>Generate Report
                </button>
                <a href="/Restaurant_system/business_owner/reports/sales.php" class="btn btn-outline-secondary">
                    <i class="fas fa-times me-2"></i>Clear Filters
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Summary Statistics -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon success me-3">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Total Revenue</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($sales_summary['total_revenue'] ?? 0); ?></h4>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon primary me-3">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Total Orders</h6>
                    <h4 class="mb-0"><?php echo $sales_summary['total_orders'] ?? 0; ?></h4>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon info me-3">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Avg Order Value</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($sales_summary['avg_order_value'] ?? 0); ?></h4>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon warning me-3">
                    <i class="fas fa-users"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Active Clerks</h6>
                    <h4 class="mb-0"><?php echo $sales_summary['active_clerks'] ?? 0; ?></h4>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Charts Row -->
<div class="row mb-4">
    <!-- Sales Trend Chart -->
    <div class="col-lg-8 mb-3">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-chart-area me-2"></i>Sales Trend (<?php echo ucfirst($report_type); ?>)
                </h5>
            </div>
            <div class="card-body">
                <canvas id="salesTrendChart" height="100"></canvas>
            </div>
        </div>
    </div>
    
    <!-- Category Distribution -->
    <div class="col-lg-4 mb-3">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-chart-pie me-2"></i>Sales by Category
                </h5>
            </div>
            <div class="card-body">
                <canvas id="categoryChart" height="200"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Data Tables Row -->
<div class="row">
    <!-- Top Selling Items -->
    <div class="col-lg-6 mb-3">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-trophy me-2"></i>Top Selling Items
                </h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th>Category</th>
                                <th>Sold</th>
                                <th>Revenue</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_items as $item): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($item['item_name']); ?></strong></td>
                                    <td><span class="badge bg-secondary"><?php echo htmlspecialchars($item['category']); ?></span></td>
                                    <td><?php echo $item['total_sold']; ?></td>
                                    <td><strong class="text-success"><?php echo formatCurrency($item['total_revenue']); ?></strong></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Sales by Clerk -->
    <div class="col-lg-6 mb-3">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-user-tie me-2"></i>Sales by Clerk
                </h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Sales Clerk</th>
                                <th>Orders</th>
                                <th>Revenue</th>
                                <th>Avg/Order</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($sales_by_clerk as $clerk): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($clerk['full_name']); ?></strong></td>
                                    <td><?php echo $clerk['orders_count']; ?></td>
                                    <td><strong class="text-success"><?php echo formatCurrency($clerk['revenue']); ?></strong></td>
                                    <td><?php echo formatCurrency($clerk['orders_count'] > 0 ? $clerk['revenue'] / $clerk['orders_count'] : 0); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$additional_js = "
<script>
function exportReport() {
    const params = new URLSearchParams(window.location.search);
    params.set('export', 'csv');
    window.location.href = window.location.pathname + '?' + params.toString();
}

// Sales Trend Chart
" . (!empty($sales_by_period) ? "
const salesCtx = document.getElementById('salesTrendChart').getContext('2d');
const salesChart = new Chart(salesCtx, {
    type: 'line',
    data: {
        labels: [" . implode(',', array_map(function($item) use ($report_type) { 
            if ($report_type === 'monthly') {
                return "'" . date('M Y', strtotime($item['period'] . '-01')) . "'";
            } elseif ($report_type === 'weekly') {
                return "'Week " . substr($item['period'], -2) . "'";
            } else {
                return "'" . date('M d', strtotime($item['period'])) . "'";
            }
        }, array_reverse($sales_by_period))) . "],
        datasets: [{
            label: 'Revenue',
            data: [" . implode(',', array_column(array_reverse($sales_by_period), 'revenue')) . "],
            borderColor: '#28a745',
            backgroundColor: 'rgba(40, 167, 69, 0.1)',
            borderWidth: 3,
            fill: true,
            tension: 0.4
        }, {
            label: 'Orders',
            data: [" . implode(',', array_column(array_reverse($sales_by_period), 'orders_count')) . "],
            borderColor: '#007bff',
            backgroundColor: 'rgba(0, 123, 255, 0.1)',
            borderWidth: 2,
            fill: false,
            yAxisID: 'y1'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Revenue (KES)'
                },
                ticks: {
                    callback: function(value) {
                        return 'KES ' + value.toLocaleString();
                    }
                }
            },
            y1: {
                type: 'linear',
                display: true,
                position: 'right',
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Orders Count'
                },
                grid: {
                    drawOnChartArea: false,
                }
            }
        }
    }
});
" : "") . "

// Category Chart
" . (!empty($sales_by_category) ? "
const categoryCtx = document.getElementById('categoryChart').getContext('2d');
const categoryChart = new Chart(categoryCtx, {
    type: 'doughnut',
    data: {
        labels: [" . implode(',', array_map(function($cat) { return "'" . $cat['category'] . "'"; }, $sales_by_category)) . "],
        datasets: [{
            data: [" . implode(',', array_column($sales_by_category, 'revenue')) . "],
            backgroundColor: ['#007bff', '#28a745', '#ffc107', '#dc3545', '#6f42c1', '#fd7e14'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});
" : "") . "
</script>
";

require_once '../../common/footer.php';
?>