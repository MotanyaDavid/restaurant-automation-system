<?php
// Business Owner Dashboard
$page_title = 'Business Owner Dashboard';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '']
];

require_once '../common/header.php';
requireRole('business_owner');

try {
    $pdo = getPDO();
    
    // Get dashboard statistics
    // Total users
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM users WHERE status = 'active'");
    $stmt->execute();
    $total_users = $stmt->fetch()['count'];
    
    // Today's orders
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count, COALESCE(SUM(total_amount), 0) as revenue
        FROM orders 
        WHERE DATE(created_at) = CURDATE() 
        AND status IN ('served', 'ready')
    ");
    $stmt->execute();
    $today_stats = $stmt->fetch();
    
    // This month's revenue
    $stmt = $pdo->prepare("
        SELECT COALESCE(SUM(total_amount), 0) as revenue
        FROM orders 
        WHERE YEAR(created_at) = YEAR(CURDATE()) 
        AND MONTH(created_at) = MONTH(CURDATE())
        AND status IN ('served', 'ready')
    ");
    $stmt->execute();
    $month_revenue = $stmt->fetch()['revenue'];
    
    // Low stock items
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count 
        FROM ingredients 
        WHERE current_stock <= threshold_quantity
    ");
    $stmt->execute();
    $low_stock_count = $stmt->fetch()['count'];
    
    // Pending payments
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count, COALESCE(SUM(total_amount), 0) as amount
        FROM invoices 
        WHERE status = 'pending'
    ");
    $stmt->execute();
    $pending_payments = $stmt->fetch();
    
    // Available funds
    $available_funds = getAvailableFunds();
    
    // Recent orders
    $stmt = $pdo->prepare("
        SELECT o.order_id, o.order_number, o.customer_name, o.total_amount, 
               o.status, o.created_at, u.full_name as clerk_name
        FROM orders o
        JOIN users u ON o.created_by = u.user_id
        ORDER BY o.created_at DESC
        LIMIT 10
    ");
    $stmt->execute();
    $recent_orders = $stmt->fetchAll();
    
    // Recent user activity
    $stmt = $pdo->prepare("
        SELECT al.action, al.created_at, u.full_name, u.role
        FROM activity_logs al
        JOIN users u ON al.user_id = u.user_id
        ORDER BY al.created_at DESC
        LIMIT 10
    ");
    $stmt->execute();
    $recent_activity = $stmt->fetchAll();
    
    // Monthly sales data for chart (last 6 months)
    $stmt = $pdo->prepare("
        SELECT 
            DATE_FORMAT(created_at, '%Y-%m') as month,
            COALESCE(SUM(total_amount), 0) as revenue,
            COUNT(*) as orders
        FROM orders 
        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
        AND status IN ('served', 'ready')
        GROUP BY DATE_FORMAT(created_at, '%Y-%m')
        ORDER BY month ASC
    ");
    $stmt->execute();
    $monthly_data = $stmt->fetchAll();
    
} catch (Exception $e) {
    $error_message = "Error loading dashboard data: " . $e->getMessage();
    logError($error_message);
}

$auto_refresh = true; // Enable auto-refresh for dashboard
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Business Owner Dashboard</h1>
        <p class="text-muted">Welcome back, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</p>
    </div>
    <div class="text-end">
        <div class="current-date text-muted small"></div>
        <div class="current-time fw-bold"></div>
    </div>
</div>

<?php if (isset($error_message)): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
    </div>
<?php endif; ?>

<!-- Key Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon primary me-3">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Available Funds</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($available_funds ?? 0); ?></h4>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon success me-3">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Today's Revenue</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($today_stats['revenue'] ?? 0); ?></h4>
                    <small class="text-muted"><?php echo $today_stats['count'] ?? 0; ?> orders</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon warning me-3">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Low Stock Items</h6>
                    <h4 class="mb-0"><?php echo $low_stock_count ?? 0; ?></h4>
                    <small class="text-muted">Need attention</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon danger me-3">
                    <i class="fas fa-file-invoice-dollar"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Pending Payments</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($pending_payments['amount'] ?? 0); ?></h4>
                    <small class="text-muted"><?php echo $pending_payments['count'] ?? 0; ?> invoices</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Charts and Analytics -->
<div class="row mb-4">
    <div class="col-lg-12 mb-10">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-chart-area me-2"></i>
                    Monthly Revenue Trend
                </h5>
            </div>
            <div class="card-body">
                <canvas id="revenueChart" height="200"></canvas>
            </div>
        </div>
    </div>
    
    <!-- <div class="col-lg-4 mb-3">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-users me-2"></i>
                    System Users
                </h5>
            </div>
            <div class="card-body">
                <?php
                try {
                    $stmt = $pdo->prepare("
                        SELECT role, COUNT(*) as count 
                        FROM users 
                        WHERE status = 'active' 
                        GROUP BY role
                    ");
                    $stmt->execute();
                    $user_roles = $stmt->fetchAll();
                } catch (Exception $e) {
                    $user_roles = [];
                }
                ?>
                
                <canvas id="usersChart" height="200"></canvas>
                
                <div class="mt-3">
                    <?php foreach ($user_roles as $role): ?>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted"><?php echo getRoleDisplayName($role['role']); ?></span>
                            <span class="fw-bold"><?php echo $role['count']; ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div> -->
</div>

<!-- Recent Activity and Orders -->
<div class="row">
    <div class="col-lg-6 mb-3">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="fas fa-shopping-cart me-2"></i>
                    Recent Orders
                </h5>
                <a href="/Restaurant_system/business_owner/reports/orders.php" class="btn btn-sm btn-outline-primary">
                    View All
                </a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Order #</th>
                                <th>Customer</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_orders)): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-3">
                                        No recent orders found
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($recent_orders as $order): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($order['order_number']); ?></strong>
                                        </td>
                                        <td>
                                            <?php echo htmlspecialchars($order['customer_name'] ?: 'Walk-in'); ?>
                                            <br>
                                            <small class="text-muted">by <?php echo htmlspecialchars($order['clerk_name']); ?></small>
                                        </td>
                                        <td><?php echo formatCurrency($order['total_amount']); ?></td>
                                        <td>
                                            <?php
                                            $status_class = [
                                                'pending' => 'warning',
                                                'preparing' => 'info',
                                                'ready' => 'primary',
                                                'served' => 'success',
                                                'cancelled' => 'danger'
                                            ];
                                            ?>
                                            <span class="badge bg-<?php echo $status_class[$order['status']] ?? 'secondary'; ?>">
                                                <?php echo ucfirst($order['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <small><?php echo formatDisplayDateTime($order['created_at']); ?></small>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-6 mb-2">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="fas fa-history me-2"></i>
                    Recent Activity
                </h5>
                <a href="/Restaurant_system/common/activity_log.php" class="btn btn-sm btn-outline-primary">
                    View All
                </a>
            </div>
            <div class="card-body">
                <?php if (empty($recent_activity)): ?>
                    <p class="text-center text-muted py-3 mb-0">No recent activity found</p>
                <?php else: ?>
                    <div class="activity-feed">
                        <?php foreach ($recent_activity as $activity): ?>
                            <div class="activity-item d-flex mb-3">
                                <div class="activity-icon me-3">
                                    <i class="fas fa-circle text-primary" style="font-size: 0.5rem;"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <div class="activity-content">
                                        <strong><?php echo htmlspecialchars($activity['full_name']); ?></strong>
                                        <span class="text-muted"><?php echo htmlspecialchars($activity['action']); ?></span>
                                    </div>
                                    <small class="text-muted">
                                        <?php echo formatDisplayDateTime($activity['created_at']); ?> • 
                                        <?php echo getRoleDisplayName($activity['role']); ?>
                                    </small>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-bolt me-2"></i>
                    Quick Actions
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <a href="/Restaurant_system/business_owner/users/manage.php" class="btn btn-outline-primary w-100">
                            <i class="fas fa-users me-2"></i>
                            Manage Users
                        </a>
                    </div>
                    <div class="col-md-4 mb-3">
                        <a href="/Restaurant_system/business_owner/financial/funds.php" class="btn btn-outline-success w-100">
                            <i class="fas fa-money-bill-wave me-2"></i>
                            Manage Funds
                        </a>
                    </div>
                    <div class="col-md-4 mb-3">
                        <a href="/Restaurant_system/business_owner/reports/sales.php" class="btn btn-outline-info w-100">
                            <i class="fas fa-chart-bar me-2"></i>
                            View Reports
                        </a>
                    </div>
                    <!-- <div class="col-md-3 mb-2">
                        <a href="/Restaurant_system/business_owner/settings.php" class="btn btn-outline-warning w-100">
                            <i class="fas fa-cog me-2"></i>
                            System Settings
                        </a>
                    </div> -->
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$additional_js = "
<script>
// Revenue Chart
const revenueCtx = document.getElementById('revenueChart').getContext('2d');
const revenueChart = new Chart(revenueCtx, {
    type: 'line',
    data: {
        labels: [" . implode(',', array_map(function($item) { return "'" . date('M Y', strtotime($item['month'] . '-01')) . "'"; }, $monthly_data)) . "],
        datasets: [{
            label: 'Revenue',
            data: [" . implode(',', array_column($monthly_data, 'revenue')) . "],
            borderColor: '#667eea',
            backgroundColor: 'rgba(102, 126, 234, 0.1)',
            borderWidth: 3,
            fill: true,
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return 'KES ' + value.toLocaleString();
                    }
                }
            }
        }
    }
});

// Users Chart
const usersCtx = document.getElementById('usersChart').getContext('2d');
const usersChart = new Chart(usersCtx, {
    type: 'doughnut',
    data: {
        labels: [" . implode(',', array_map(function($role) { return "'" . getRoleDisplayName($role['role']) . "'"; }, $user_roles)) . "],
        datasets: [{
            data: [" . implode(',', array_column($user_roles, 'count')) . "],
            backgroundColor: ['#667eea', '#28a745', '#ffc107'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            }
        }
    }
});
</script>
";

require_once '../common/footer.php';
?>