<?php
// Business Owner - Financial Management
$page_title = 'Financial Management';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/business_owner/'],
    ['title' => 'Financial Management', 'url' => '']
];

require_once '../../common/header.php';
requireRole('business_owner');

// Handle form submissions
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!validateCSRFToken($csrf_token)) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        try {
            $pdo = getPDO();
            
            switch ($action) {
                case 'update_funds':
                    $new_amount = floatval($_POST['available_funds']);
                    
                    if ($new_amount < 0) {
                        throw new Exception('Available funds cannot be negative.');
                    }
                    
                    // Get current funds for logging
                    $current_funds = getAvailableFunds();
                    
                    // Update funds
                    if (updateAvailableFunds($new_amount, $_SESSION['user_id'])) {
                        logActivity('Funds Updated', 'financial_settings', null, 
                            ['old_amount' => $current_funds], 
                            ['new_amount' => $new_amount]
                        );
                        
                        $success_message = 'Available funds updated successfully to ' . formatCurrency($new_amount);
                    } else {
                        throw new Exception('Failed to update funds. Please try again.');
                    }
                    break;
                    
                case 'approve_payment':
                    $invoice_id = intval($_POST['invoice_id']);
                    
                    // Get invoice details
                    $stmt = $pdo->prepare("SELECT * FROM invoices WHERE invoice_id = ? AND status = 'pending'");
                    $stmt->execute([$invoice_id]);
                    $invoice = $stmt->fetch();
                    
                    if (!$invoice) {
                        throw new Exception('Invoice not found or already processed.');
                    }
                    
                    $available_funds = getAvailableFunds();
                    
                    if ($available_funds < $invoice['total_amount']) {
                        throw new Exception('Insufficient funds to approve this payment. Available: ' . formatCurrency($available_funds) . ', Required: ' . formatCurrency($invoice['total_amount']));
                    }
                    
                    $pdo->beginTransaction();
                    
                    // Generate cheque number
                    $cheque_number = 'CHQ' . date('Ymd') . str_pad($invoice_id, 4, '0', STR_PAD_LEFT);
                    
                    // Update invoice status
                    $stmt = $pdo->prepare("
                        UPDATE invoices 
                        SET status = 'paid', payment_method = 'cheque', cheque_number = ?
                        WHERE invoice_id = ?
                    ");
                    $stmt->execute([$cheque_number, $invoice_id]);
                    
                    // Deduct from available funds
                    $new_funds = $available_funds - $invoice['total_amount'];
                    updateAvailableFunds($new_funds, $_SESSION['user_id']);
                    
                    $pdo->commit();
                    
                    logActivity('Payment Approved', 'invoices', $invoice_id, null, [
                        'cheque_number' => $cheque_number,
                        'amount' => $invoice['total_amount']
                    ]);
                    
                    $success_message = "Payment approved! Cheque #{$cheque_number} generated for " . formatCurrency($invoice['total_amount']);
                    break;
            }
            
        } catch (Exception $e) {
            if (isset($pdo) && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error_message = $e->getMessage();
            logError($error_message);
        }
    }
}

try {
    $pdo = getPDO();
    
    // Get current financial status
    $available_funds = getAvailableFunds();
    
    // Get pending payments
    $stmt = $pdo->prepare("
        SELECT i.*, po.po_number
        FROM invoices i
        LEFT JOIN purchase_orders po ON i.po_id = po.po_id
        WHERE i.status = 'pending'
        ORDER BY i.invoice_date ASC
    ");
    $stmt->execute();
    $pending_payments = $stmt->fetchAll();
    
    // Get recent transactions (fund updates)
    $stmt = $pdo->prepare("
        SELECT fs.*, u.full_name as updated_by_name
        FROM financial_settings fs
        JOIN users u ON fs.updated_by = u.user_id
        ORDER BY fs.updated_at DESC
        LIMIT 10
    ");
    $stmt->execute();
    $recent_transactions = $stmt->fetchAll();
    
    // Get monthly financial summary
    $stmt = $pdo->prepare("
        SELECT 
            YEAR(created_at) as year,
            MONTH(created_at) as month,
            SUM(total_amount) as revenue,
            COUNT(*) as orders
        FROM orders 
        WHERE status IN ('served', 'ready')
        AND created_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
        GROUP BY YEAR(created_at), MONTH(created_at)
        ORDER BY year DESC, month DESC
    ");
    $stmt->execute();
    $monthly_revenue = $stmt->fetchAll();
    
    // Get monthly expenses
    $stmt = $pdo->prepare("
        SELECT 
            YEAR(created_at) as year,
            MONTH(created_at) as month,
            SUM(total_amount) as expenses,
            COUNT(*) as invoices
        FROM invoices 
        WHERE status = 'paid'
        AND created_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
        GROUP BY YEAR(created_at), MONTH(created_at)
        ORDER BY year DESC, month DESC
    ");
    $stmt->execute();
    $monthly_expenses = $stmt->fetchAll();
    
    // Calculate totals
    $total_pending = array_sum(array_column($pending_payments, 'total_amount'));
    $this_month_revenue = 0;
    $this_month_expenses = 0;
    
    $current_month = date('n');
    $current_year = date('Y');
    
    foreach ($monthly_revenue as $revenue) {
        if ($revenue['year'] == $current_year && $revenue['month'] == $current_month) {
            $this_month_revenue = $revenue['revenue'];
            break;
        }
    }
    
    foreach ($monthly_expenses as $expense) {
        if ($expense['year'] == $current_year && $expense['month'] == $current_month) {
            $this_month_expenses = $expense['expenses'];
            break;
        }
    }
    
} catch (Exception $e) {
    $error_message = "Error loading financial data: " . $e->getMessage();
    logError($error_message);
}

$csrf_token = generateCSRFToken();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Financial Management</h1>
        <p class="text-muted">Manage funds, payments, and financial reports</p>
    </div>
    <div>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#updateFundsModal">
            <i class="fas fa-plus me-2"></i>Update Funds
        </button>
    </div>
</div>

<?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i>
        <?php echo htmlspecialchars($success_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error_message): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Financial Overview Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon primary me-3">
                    <i class="fas fa-wallet"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Available Funds</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($available_funds ?? 0); ?></h4>
                    <small class="text-muted">Current balance</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon success me-3">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">This Month Revenue</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($this_month_revenue); ?></h4>
                    <small class="text-muted">Sales income</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon warning me-3">
                    <i class="fas fa-file-invoice-dollar"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Pending Payments</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($total_pending); ?></h4>
                    <small class="text-muted"><?php echo count($pending_payments); ?> invoices</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon danger me-3">
                    <i class="fas fa-money-bill"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">This Month Expenses</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($this_month_expenses); ?></h4>
                    <small class="text-muted">Paid invoices</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Main Content -->
<div class="row">
    <!-- Pending Payments -->
    <div class="col-lg-8 mb-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="fas fa-clock me-2"></i>
                    Pending Payments
                </h5>
                <span class="badge bg-warning"><?php echo count($pending_payments); ?> pending</span>
            </div>
            <div class="card-body">
                <?php if (empty($pending_payments)): ?>
                    <div class="text-center py-4">
                        <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                        <h5 class="text-success">All payments are up to date!</h5>
                        <p class="text-muted">No pending invoices require approval.</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Invoice #</th>
                                    <th>Supplier</th>
                                    <th>PO #</th>
                                    <th>Date</th>
                                    <th>Amount</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($pending_payments as $payment): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($payment['invoice_number']); ?></strong>
                                        </td>
                                        <td><?php echo htmlspecialchars($payment['supplier_name']); ?></td>
                                        <td>
                                            <?php if ($payment['po_number']): ?>
                                                <span class="badge bg-info"><?php echo htmlspecialchars($payment['po_number']); ?></span>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo formatDisplayDate($payment['invoice_date']); ?></td>
                                        <td>
                                            <strong class="text-danger"><?php echo formatCurrency($payment['total_amount']); ?></strong>
                                        </td>
                                        <td>
                                            <?php if ($available_funds >= $payment['total_amount']): ?>
                                                <button type="button" class="btn btn-sm btn-success" 
                                                        onclick="approvePayment(<?php echo $payment['invoice_id']; ?>, '<?php echo htmlspecialchars($payment['invoice_number']); ?>', <?php echo $payment['total_amount']; ?>)">
                                                    <i class="fas fa-check me-1"></i>Approve
                                                </button>
                                            <?php else: ?>
                                                <span class="badge bg-danger">Insufficient Funds</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Recent Transactions -->
    <div class="col-lg-4 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-history me-2"></i>
                    Recent Fund Updates
                </h5>
            </div>
            <div class="card-body">
                <?php if (empty($recent_transactions)): ?>
                    <p class="text-center text-muted py-3 mb-0">No recent transactions</p>
                <?php else: ?>
                    <?php foreach ($recent_transactions as $transaction): ?>
                        <div class="d-flex justify-content-between align-items-center mb-3 p-2 bg-light rounded">
                            <div>
                                <strong><?php echo formatCurrency($transaction['available_funds']); ?></strong>
                                <br>
                                <small class="text-muted">
                                    by <?php echo htmlspecialchars($transaction['updated_by_name']); ?>
                                </small>
                            </div>
                            <div class="text-end">
                                <small class="text-muted">
                                    <?php echo formatDisplayDateTime($transaction['updated_at']); ?>
                                </small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Financial Chart -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-chart-area me-2"></i>
                    Revenue vs Expenses (Last 6 Months)
                </h5>
            </div>
            <div class="card-body">
                <canvas id="financialChart" height="100"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Update Funds Modal -->
<div class="modal fade" id="updateFundsModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-wallet me-2"></i>Update Available Funds
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="update_funds">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Current available funds: <strong><?php echo formatCurrency($available_funds); ?></strong>
                    </div>
                    
                    <div class="mb-3">
                        <label for="available_funds" class="form-label">New Amount (KES) *</label>
                        <input type="number" class="form-control currency-input" id="available_funds" 
                               name="available_funds" step="0.01" min="0" required
                               value="<?php echo $available_funds; ?>">
                        <div class="form-text">Enter the total amount of funds available for operations.</div>
                        <div class="invalid-feedback">Please enter a valid amount.</div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Update Funds
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Approve Payment Modal -->
<div class="modal fade" id="approvePaymentModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-check-circle me-2"></i>Approve Payment
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="approve_payment">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="invoice_id" id="approve_invoice_id">
                
                <div class="modal-body">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        You are about to approve payment for invoice <strong id="approve_invoice_number"></strong>
                    </div>
                    
                    <div class="row">
                        <div class="col-6">
                            <strong>Payment Amount:</strong><br>
                            <span class="text-danger" id="approve_amount"></span>
                        </div>
                        <div class="col-6">
                            <strong>Available Funds:</strong><br>
                            <span class="text-success"><?php echo formatCurrency($available_funds); ?></span>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <p class="mb-0">
                        <i class="fas fa-info-circle text-info me-2"></i>
                        A cheque will be generated automatically upon approval.
                    </p>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-check me-2"></i>Approve Payment
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
// Prepare data for chart
$chart_months = [];
$chart_revenue = [];
$chart_expenses = [];

// Create a complete 6-month array
for ($i = 5; $i >= 0; $i--) {
    $month = date('n', strtotime("-$i months"));
    $year = date('Y', strtotime("-$i months"));
    $month_key = $year . '-' . $month;
    
    $chart_months[] = date('M Y', strtotime("-$i months"));
    
    // Find revenue for this month
    $revenue = 0;
    foreach ($monthly_revenue as $rev) {
        if ($rev['year'] == $year && $rev['month'] == $month) {
            $revenue = $rev['revenue'];
            break;
        }
    }
    $chart_revenue[] = $revenue;
    
    // Find expenses for this month
    $expenses = 0;
    foreach ($monthly_expenses as $exp) {
        if ($exp['year'] == $year && $exp['month'] == $month) {
            $expenses = $exp['expenses'];
            break;
        }
    }
    $chart_expenses[] = $expenses;
}

$additional_js = "
<script>
function approvePayment(invoiceId, invoiceNumber, amount) {
    document.getElementById('approve_invoice_id').value = invoiceId;
    document.getElementById('approve_invoice_number').textContent = invoiceNumber;
    document.getElementById('approve_amount').textContent = 'KES ' + amount.toLocaleString();
    
    new bootstrap.Modal(document.getElementById('approvePaymentModal')).show();
}

// Financial Chart
const financialCtx = document.getElementById('financialChart').getContext('2d');
const financialChart = new Chart(financialCtx, {
    type: 'line',
    data: {
        labels: [" . implode(',', array_map(function($month) { return "'$month'"; }, $chart_months)) . "],
        datasets: [{
            label: 'Revenue',
            data: [" . implode(',', $chart_revenue) . "],
            borderColor: '#28a745',
            backgroundColor: 'rgba(40, 167, 69, 0.1)',
            borderWidth: 3,
            fill: true,
            tension: 0.4
        }, {
            label: 'Expenses',
            data: [" . implode(',', $chart_expenses) . "],
            borderColor: '#dc3545',
            backgroundColor: 'rgba(220, 53, 69, 0.1)',
            borderWidth: 3,
            fill: true,
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
            mode: 'index',
            intersect: false,
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return 'KES ' + value.toLocaleString();
                    }
                }
            }
        },
        plugins: {
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return context.dataset.label + ': KES ' + context.parsed.y.toLocaleString();
                    }
                }
            }
        }
    }
});
</script>
";

require_once '../../common/footer.php';
?>