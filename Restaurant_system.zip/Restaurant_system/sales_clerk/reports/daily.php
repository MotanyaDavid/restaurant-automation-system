<?php
// Sales Clerk - Daily Reports
$page_title = 'Daily Reports';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/sales_clerk/'],
    ['title' => 'Reports', 'url' => '']
];

require_once '../../common/header.php';
requireRole('sales_clerk');

// Get selected date
$selected_date = $_GET['date'] ?? date('Y-m-d');

try {
    $pdo = getPDO();
    
    // Daily sales summary for the clerk
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(o.order_id) as total_orders,
            SUM(o.total_amount) as total_sales,
            AVG(o.total_amount) as avg_order_value,
            MIN(o.total_amount) as min_order,
            MAX(o.total_amount) as max_order,
            SUM(CASE WHEN o.status = 'served' THEN 1 ELSE 0 END) as completed_orders,
            SUM(CASE WHEN o.status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_orders
        FROM orders o
        WHERE DATE(o.created_at) = ? 
        AND o.created_by = ?
    ");
    $stmt->execute([$selected_date, $_SESSION['user_id']]);
    $daily_summary = $stmt->fetch();
    
    // Hourly sales breakdown
    $stmt = $pdo->prepare("
        SELECT 
            HOUR(o.created_at) as hour,
            COUNT(o.order_id) as orders_count,
            SUM(o.total_amount) as hourly_sales
        FROM orders o
        WHERE DATE(o.created_at) = ? 
        AND o.created_by = ?
        AND o.status IN ('served', 'ready')
        GROUP BY HOUR(o.created_at)
        ORDER BY hour ASC
    ");
    $stmt->execute([$selected_date, $_SESSION['user_id']]);
    $hourly_sales = $stmt->fetchAll();
    
    // Top selling items by this clerk
    $stmt = $pdo->prepare("
        SELECT 
            mi.item_name,
            mi.item_code,
            mi.price,
            SUM(oi.quantity) as total_quantity,
            SUM(oi.subtotal) as total_revenue,
            COUNT(DISTINCT o.order_id) as order_count
        FROM order_items oi
        JOIN menu_items mi ON oi.item_id = mi.item_id
        JOIN orders o ON oi.order_id = o.order_id
        WHERE DATE(o.created_at) = ? 
        AND o.created_by = ?
        AND o.status IN ('served', 'ready')
        GROUP BY mi.item_id
        ORDER BY total_quantity DESC
        LIMIT 10
    ");
    $stmt->execute([$selected_date, $_SESSION['user_id']]);
    $top_items = $stmt->fetchAll();
    
    // Recent orders for the day
    $stmt = $pdo->prepare("
        SELECT o.*, 
               COUNT(oi.id) as items_count
        FROM orders o
        LEFT JOIN order_items oi ON o.order_id = oi.order_id
        WHERE DATE(o.created_at) = ? 
        AND o.created_by = ?
        GROUP BY o.order_id
        ORDER BY o.created_at DESC
        LIMIT 20
    ");
    $stmt->execute([$selected_date, $_SESSION['user_id']]);
    $recent_orders = $stmt->fetchAll();
    
    // Weekly comparison (last 7 days)
    $stmt = $pdo->prepare("
        SELECT 
            DATE(o.created_at) as order_date,
            COUNT(o.order_id) as daily_orders,
            SUM(o.total_amount) as daily_sales
        FROM orders o
        WHERE o.created_at >= DATE_SUB(?, INTERVAL 6 DAY)
        AND o.created_at <= DATE_ADD(?, INTERVAL 1 DAY)
        AND o.created_by = ?
        AND o.status IN ('served', 'ready')
        GROUP BY DATE(o.created_at)
        ORDER BY order_date ASC
    ");
    $stmt->execute([$selected_date, $selected_date, $_SESSION['user_id']]);
    $weekly_data = $stmt->fetchAll();
    
    // Performance metrics
    $completion_rate = $daily_summary['total_orders'] > 0 ? 
        ($daily_summary['completed_orders'] / $daily_summary['total_orders']) * 100 : 0;
    
    $cancellation_rate = $daily_summary['total_orders'] > 0 ? 
        ($daily_summary['cancelled_orders'] / $daily_summary['total_orders']) * 100 : 0;
    
} catch (Exception $e) {
    $error_message = "Error loading report data: " . $e->getMessage();
    logError($error_message);
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Daily Reports</h1>
        <p class="text-muted">Your performance report for <?php echo formatDisplayDate($selected_date); ?></p>
    </div>
    <div>
        <button type="button" class="btn btn-success me-2" onclick="exportReport()">
            <i class="fas fa-download me-2"></i>Export
        </button>
        <button type="button" class="btn btn-primary" onclick="window.print()">
            <i class="fas fa-print me-2"></i>Print
        </button>
    </div>
</div>

<!-- Date Selection -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-4">
                <label for="date" class="form-label">Select Date</label>
                <input type="date" class="form-control" id="date" name="date" 
                       value="<?php echo $selected_date; ?>" max="<?php echo date('Y-m-d'); ?>">
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search me-2"></i>Generate Report
                </button>
            </div>
            <div class="col-md-4 text-end">
                <small class="text-muted">
                    Report generated on <?php echo formatDisplayDateTime(date('Y-m-d H:i:s')); ?>
                </small>
            </div>
        </form>
    </div>
</div>

<?php if (isset($error_message)): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
    </div>
<?php endif; ?>

<!-- Summary Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon primary me-3">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Total Orders</h6>
                    <h4 class="mb-0"><?php echo $daily_summary['total_orders'] ?? 0; ?></h4>
                    <small class="text-muted">Orders taken</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon success me-3">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Total Sales</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($daily_summary['total_sales'] ?? 0); ?></h4>
                    <small class="text-muted">Revenue generated</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon info me-3">
                    <i class="fas fa-calculator"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Average Order</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($daily_summary['avg_order_value'] ?? 0); ?></h4>
                    <small class="text-muted">Per order</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon <?php echo $completion_rate >= 90 ? 'success' : ($completion_rate >= 70 ? 'warning' : 'danger'); ?> me-3">
                    <i class="fas fa-percentage"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Completion Rate</h6>
                    <h4 class="mb-0"><?php echo number_format($completion_rate, 1); ?>%</h4>
                    <small class="text-muted"><?php echo $daily_summary['completed_orders'] ?? 0; ?> completed</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Charts Row -->
<div class="row mb-4">
    <!-- <div class="col-lg-8 mb-3">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-chart-line me-2"></i>
                    Hourly Sales Performance
                </h5>
            </div>
            <div class="card-body">
                <canvas id="hourlySalesChart" height="100"></canvas>
            </div>
        </div>
    </div> -->
    
    <div class="col-lg-4 mb-3">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-chart-doughnut me-2"></i>
                    Order Status
                </h5>
            </div>
            <div class="card-body">
                <canvas id="statusChart" height="10"></canvas>
                
                <div class="mt-3">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted">Completed</span>
                        <span class="fw-bold text-success"><?php echo $daily_summary['completed_orders'] ?? 0; ?></span>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted">Cancelled</span>
                        <span class="fw-bold text-danger"><?php echo $daily_summary['cancelled_orders'] ?? 0; ?></span>
                    </div>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="text-muted">Other</span>
                        <span class="fw-bold text-info">
                            <?php echo ($daily_summary['total_orders'] ?? 0) - ($daily_summary['completed_orders'] ?? 0) - ($daily_summary['cancelled_orders'] ?? 0); ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Detailed Reports -->
<div class="row">
    <!-- Top Selling Items -->
    <div class="col-lg-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-trophy me-2"></i>
                    Top Selling Items
                </h5>
            </div>
            <div class="card-body">
                <?php if (empty($top_items)): ?>
                    <p class="text-center text-muted py-3 mb-0">No sales data for this date</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Rank</th>
                                    <th>Item</th>
                                    <th>Qty</th>
                                    <th>Revenue</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($top_items as $index => $item): ?>
                                    <tr>
                                        <td>
                                            <span class="badge bg-<?php echo $index < 3 ? 'warning' : 'secondary'; ?>">
                                                #<?php echo $index + 1; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($item['item_name']); ?></strong>
                                            <br>
                                            <small class="text-muted"><?php echo htmlspecialchars($item['item_code']); ?></small>
                                        </td>
                                        <td><?php echo $item['total_quantity']; ?></td>
                                        <td><?php echo formatCurrency($item['total_revenue']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<!-- Weekly Trend -->
<!-- <div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-chart-area me-2"></i>
                    Weekly Performance Trend
                </h5>
            </div>
            <div class="card-body">
                <canvas id="weeklyTrendChart" height="100"></canvas>
            </div>
        </div>
    </div>
</div> -->


    
    <!-- Performance Metrics -->
    <div class="col-lg-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-chart-bar me-2"></i>
                    Performance Metrics
                </h5>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <span>Completion Rate</span>
                        <span class="fw-bold"><?php echo number_format($completion_rate, 1); ?>%</span>
                    </div>
                    <div class="progress">
                        <div class="progress-bar bg-<?php echo $completion_rate >= 90 ? 'success' : ($completion_rate >= 70 ? 'warning' : 'danger'); ?>" 
                             style="width: <?php echo $completion_rate; ?>%"></div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <span>Cancellation Rate</span>
                        <span class="fw-bold"><?php echo number_format($cancellation_rate, 1); ?>%</span>
                    </div>
                    <div class="progress">
                        <div class="progress-bar bg-<?php echo $cancellation_rate <= 5 ? 'success' : ($cancellation_rate <= 10 ? 'warning' : 'danger'); ?>" 
                             style="width: <?php echo $cancellation_rate; ?>%"></div>
                    </div>
                </div>
                
                <hr>
                
                <div class="row text-center">
                    <div class="col-6">
                        <h5 class="text-success"><?php echo formatCurrency($daily_summary['max_order'] ?? 0); ?></h5>
                        <small class="text-muted">Highest Order</small>
                    </div>
                    <div class="col-6">
                        <h5 class="text-info"><?php echo formatCurrency($daily_summary['min_order'] ?? 0); ?></h5>
                        <small class="text-muted">Lowest Order</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Recent Orders -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-list me-2"></i>
            Recent Orders (<?php echo formatDisplayDate($selected_date); ?>)
        </h5>
    </div>
    <div class="card-body">
        <?php if (empty($recent_orders)): ?>
            <p class="text-center text-muted py-3 mb-0">No orders found for this date</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover table-sm">
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Customer</th>
                            <th>Items</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_orders as $order): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($order['order_number']); ?></td>
                                <td><?php echo htmlspecialchars($order['customer_name'] ?: 'Walk-in'); ?></td>
                                <td>
                                    <span class="badge bg-info"><?php echo $order['items_count']; ?> items</span>
                                </td>
                                <td><?php echo formatCurrency($order['total_amount']); ?></td>
                                <td>
                                    <?php
                                    $status_classes = [
                                        'pending' => 'warning',
                                        'preparing' => 'info',
                                        'ready' => 'primary',
                                        'served' => 'success',
                                        'cancelled' => 'danger'
                                    ];
                                    ?>
                                    <span class="badge bg-<?php echo $status_classes[$order['status']] ?? 'secondary'; ?>">
                                        <?php echo ucfirst($order['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('H:i', strtotime($order['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
// Prepare chart data
$hourly_chart_data = array_fill(0, 24, 0);
foreach ($hourly_sales as $hour_data) {
    $hourly_chart_data[$hour_data['hour']] = $hour_data['hourly_sales'];
}

$weekly_chart_dates = [];
$weekly_chart_sales = [];
$weekly_chart_orders = [];

// Fill in missing dates with zero values
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime($selected_date . " -$i days"));
    $weekly_chart_dates[] = date('M d', strtotime($date));
    
    $found = false;
    foreach ($weekly_data as $day_data) {
        if ($day_data['order_date'] === $date) {
            $weekly_chart_sales[] = $day_data['daily_sales'];
            $weekly_chart_orders[] = $day_data['daily_orders'];
            $found = true;
            break;
        }
    }
    
    if (!$found) {
        $weekly_chart_sales[] = 0;
        $weekly_chart_orders[] = 0;
    }
}

$additional_js = "
<script>
// Hourly Sales Chart
const hourlySalesCtx = document.getElementById('hourlySalesChart').getContext('2d');
const hourlySalesChart = new Chart(hourlySalesCtx, {
    type: 'bar',
    data: {
        labels: [" . implode(',', array_map(function($h) { return "'$h:00'"; }, range(0, 23))) . "],
        datasets: [{
            label: 'Sales',
            data: [" . implode(',', $hourly_chart_data) . "],
            backgroundColor: 'rgba(102, 126, 234, 0.8)',
            borderColor: '#667eea',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return 'KES ' + value.toLocaleString();
                    }
                }
            }
        }
    }
});

// Status Chart
const statusCtx = document.getElementById('statusChart').getContext('2d');
const statusChart = new Chart(statusCtx, {
    type: 'doughnut',
    data: {
        labels: ['Completed', 'Cancelled', 'Other'],
        datasets: [{
            data: [
                " . ($daily_summary['completed_orders'] ?? 0) . ",
                " . ($daily_summary['cancelled_orders'] ?? 0) . ",
                " . (($daily_summary['total_orders'] ?? 0) - ($daily_summary['completed_orders'] ?? 0) - ($daily_summary['cancelled_orders'] ?? 0)) . "
            ],
            backgroundColor: ['#28a745', '#dc3545', '#17a2b8']
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            }
        }
    }
});

// Weekly Trend Chart
const weeklyTrendCtx = document.getElementById('weeklyTrendChart').getContext('2d');
const weeklyTrendChart = new Chart(weeklyTrendCtx, {
    type: 'line',
    data: {
        labels: [" . implode(',', array_map(function($date) { return "'$date'"; }, $weekly_chart_dates)) . "],
        datasets: [{
            label: 'Sales',
            data: [" . implode(',', $weekly_chart_sales) . "],
            borderColor: '#28a745',
            backgroundColor: 'rgba(40, 167, 69, 0.1)',
            borderWidth: 3,
            fill: true,
            tension: 0.4,
            yAxisID: 'y'
        }, {
            label: 'Orders',
            data: [" . implode(',', $weekly_chart_orders) . "],
            borderColor: '#007bff',
            backgroundColor: 'rgba(0, 123, 255, 0.1)',
            borderWidth: 2,
            fill: false,
            yAxisID: 'y1'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
            mode: 'index',
            intersect: false,
        },
        scales: {
            y: {
                type: 'linear',
                display: true,
                position: 'left',
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Sales (KES)'
                }
            },
            y1: {
                type: 'linear',
                display: true,
                position: 'right',
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Orders'
                },
                grid: {
                    drawOnChartArea: false,
                }
            }
        }
    }
});

function exportReport() {
    window.print();
}
</script>
";

require_once '../../common/footer.php';
?>