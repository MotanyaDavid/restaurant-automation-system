<?php
// Sales Clerk - View Orders
$page_title = 'View Orders';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/sales_clerk/'],
    ['title' => 'View Orders', 'url' => '']
];

require_once '../../common/header.php';
requireRole('sales_clerk');

// Handle form submissions
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!validateCSRFToken($csrf_token)) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        try {
            $pdo = getPDO();
            
            switch ($action) {
                case 'update_status':
                    $order_id = intval($_POST['order_id']);
                    $new_status = $_POST['status'];
                    
                    if (!in_array($new_status, ['pending', 'preparing', 'ready', 'served', 'cancelled'])) {
                        throw new Exception('Invalid status selected.');
                    }
                    
                    // Get order details
                    $stmt = $pdo->prepare("SELECT * FROM orders WHERE order_id = ? AND created_by = ?");
                    $stmt->execute([$order_id, $_SESSION['user_id']]);
                    $order = $stmt->fetch();
                    
                    if (!$order) {
                        throw new Exception('Order not found or you do not have permission to modify it.');
                    }
                    
                    // Update order status
                    $stmt = $pdo->prepare("UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE order_id = ?");
                    $stmt->execute([$new_status, $order_id]);
                    
                    logActivity('Order Status Updated', 'orders', $order_id, 
                        ['status' => $order['status']], 
                        ['status' => $new_status]
                    );
                    
                    $success_message = "Order #{$order['order_number']} status updated to " . ucfirst($new_status);
                    break;
            }
            
        } catch (Exception $e) {
            $error_message = $e->getMessage();
            logError($error_message);
        }
    }
}

// Get filter parameters
$status_filter = $_GET['status'] ?? 'all';
$date_filter = $_GET['date'] ?? 'today';

try {
    $pdo = getPDO();
    
    // Build query based on filters
    $where_conditions = ["o.created_by = ?"];
    $params = [$_SESSION['user_id']];
    
    // Status filter
    if ($status_filter !== 'all') {
        $where_conditions[] = "o.status = ?";
        $params[] = $status_filter;
    }
    
    // Date filter
    switch ($date_filter) {
        case 'today':
            $where_conditions[] = "DATE(o.created_at) = CURDATE()";
            break;
        case 'yesterday':
            $where_conditions[] = "DATE(o.created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
            break;
        case 'week':
            $where_conditions[] = "o.created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
            break;
        case 'month':
            $where_conditions[] = "o.created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
            break;
    }
    
    $where_clause = implode(' AND ', $where_conditions);
    
    // Get orders with items
    $stmt = $pdo->prepare("
        SELECT o.*, 
               COUNT(oi.id) as items_count,
               GROUP_CONCAT(
                   CONCAT(mi.item_name, ' (', oi.quantity, ')')
                   SEPARATOR ', '
               ) as items_list
        FROM orders o
        LEFT JOIN order_items oi ON o.order_id = oi.order_id
        LEFT JOIN menu_items mi ON oi.item_id = mi.item_id
        WHERE $where_clause
        GROUP BY o.order_id
        ORDER BY o.created_at DESC
    ");
    $stmt->execute($params);
    $orders = $stmt->fetchAll();
    
    // Get statistics
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_orders,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_orders,
            SUM(CASE WHEN status = 'preparing' THEN 1 ELSE 0 END) as preparing_orders,
            SUM(CASE WHEN status = 'ready' THEN 1 ELSE 0 END) as ready_orders,
            SUM(CASE WHEN status = 'served' THEN 1 ELSE 0 END) as served_orders,
            SUM(CASE WHEN status IN ('served', 'ready') THEN total_amount ELSE 0 END) as total_revenue
        FROM orders 
        WHERE created_by = ? AND DATE(created_at) = CURDATE()
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $today_stats = $stmt->fetch();
    
} catch (Exception $e) {
    $error_message = "Error loading orders: " . $e->getMessage();
    $orders = [];
    $today_stats = [];
}

$csrf_token = generateCSRFToken();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">View Orders</h1>
        <p class="text-muted">Manage and track your orders</p>
    </div>
    <div>
        <a href="/Restaurant_system/sales_clerk/orders/take_order.php" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>Take New Order
        </a>
    </div>
</div>

<?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i>
        <?php echo htmlspecialchars($success_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error_message): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Today's Statistics -->
<div class="row mb-4">
    <div class="col-xl-2 col-md-4 col-6 mb-3">
        <div class="stats-card">
            <div class="text-center">
                <div class="stats-icon primary mb-2">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <h4 class="mb-0"><?php echo $today_stats['total_orders'] ?? 0; ?></h4>
                <small class="text-muted">Total Orders</small>
            </div>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 col-6 mb-3">
        <div class="stats-card">
            <div class="text-center">
                <div class="stats-icon warning mb-2">
                    <i class="fas fa-clock"></i>
                </div>
                <h4 class="mb-0"><?php echo $today_stats['pending_orders'] ?? 0; ?></h4>
                <small class="text-muted">Pending</small>
            </div>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 col-6 mb-3">
        <div class="stats-card">
            <div class="text-center">
                <div class="stats-icon info mb-2">
                    <i class="fas fa-utensils"></i>
                </div>
                <h4 class="mb-0"><?php echo $today_stats['preparing_orders'] ?? 0; ?></h4>
                <small class="text-muted">Preparing</small>
            </div>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 col-6 mb-3">
        <div class="stats-card">
            <div class="text-center">
                <div class="stats-icon primary mb-2">
                    <i class="fas fa-check"></i>
                </div>
                <h4 class="mb-0"><?php echo $today_stats['ready_orders'] ?? 0; ?></h4>
                <small class="text-muted">Ready</small>
            </div>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 col-6 mb-3">
        <div class="stats-card">
            <div class="text-center">
                <div class="stats-icon success mb-2">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h4 class="mb-0"><?php echo $today_stats['served_orders'] ?? 0; ?></h4>
                <small class="text-muted">Served</small>
            </div>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 col-6 mb-3">
        <div class="stats-card">
            <div class="text-center">
                <div class="stats-icon success mb-2">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <h4 class="mb-0"><?php echo formatCurrency($today_stats['total_revenue'] ?? 0); ?></h4>
                <small class="text-muted">Revenue</small>
            </div>
        </div>
    </div>
</div>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label for="status" class="form-label">Status Filter</label>
                <select class="form-select" id="status" name="status">
                    <option value="all" <?php echo $status_filter === 'all' ? 'selected' : ''; ?>>All Status</option>
                    <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                    <option value="preparing" <?php echo $status_filter === 'preparing' ? 'selected' : ''; ?>>Preparing</option>
                    <option value="ready" <?php echo $status_filter === 'ready' ? 'selected' : ''; ?>>Ready</option>
                    <option value="served" <?php echo $status_filter === 'served' ? 'selected' : ''; ?>>Served</option>
                    <option value="cancelled" <?php echo $status_filter === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                </select>
            </div>
            <div class="col-md-3">
                <label for="date" class="form-label">Date Filter</label>
                <select class="form-select" id="date" name="date">
                    <option value="today" <?php echo $date_filter === 'today' ? 'selected' : ''; ?>>Today</option>
                    <option value="yesterday" <?php echo $date_filter === 'yesterday' ? 'selected' : ''; ?>>Yesterday</option>
                    <option value="week" <?php echo $date_filter === 'week' ? 'selected' : ''; ?>>Last 7 Days</option>
                    <option value="month" <?php echo $date_filter === 'month' ? 'selected' : ''; ?>>Last 30 Days</option>
                    <option value="all" <?php echo $date_filter === 'all' ? 'selected' : ''; ?>>All Time</option>
                </select>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-filter me-2"></i>Apply Filters
                </button>
            </div>
            <div class="col-md-3 text-end">
                <span class="text-muted">Showing <?php echo count($orders); ?> orders</span>
            </div>
        </form>
    </div>
</div>

<!-- Orders Table -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-list me-2"></i>
            Orders
        </h5>
    </div>
    <div class="card-body">
        <?php if (empty($orders)): ?>
            <div class="text-center py-5">
                <i class="fas fa-shopping-cart fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">No orders found</h5>
                <p class="text-muted">No orders match your current filters.</p>
                <a href="/Restaurant_system/sales_clerk/orders/take_order.php" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Take Your First Order
                </a>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Customer</th>
                            <th>Items</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Time</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($order['order_number']); ?></strong>
                                    <?php if ($order['table_number']): ?>
                                        <br><small class="text-muted">Table: <?php echo htmlspecialchars($order['table_number']); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($order['customer_name'] ?: 'Walk-in Customer'); ?>
                                </td>
                                <td>
                                    <span class="badge bg-info"><?php echo $order['items_count']; ?> items</span>
                                    <?php if ($order['items_list']): ?>
                                        <br>
                                        <small class="text-muted" title="<?php echo htmlspecialchars($order['items_list']); ?>">
                                            <?php echo htmlspecialchars(substr($order['items_list'], 0, 30)) . (strlen($order['items_list']) > 30 ? '...' : ''); ?>
                                        </small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong class="text-success"><?php echo formatCurrency($order['total_amount']); ?></strong>
                                </td>
                                <td>
                                    <?php
                                    $status_classes = [
                                        'pending' => 'warning',
                                        'preparing' => 'info',
                                        'ready' => 'primary',
                                        'served' => 'success',
                                        'cancelled' => 'danger'
                                    ];
                                    ?>
                                    <span class="badge bg-<?php echo $status_classes[$order['status']] ?? 'secondary'; ?>">
                                        <?php echo ucfirst($order['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <div><?php echo formatDisplayDateTime($order['created_at']); ?></div>
                                    <?php if ($order['updated_at'] !== $order['created_at']): ?>
                                        <small class="text-muted">Updated: <?php echo formatDisplayDateTime($order['updated_at']); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <button type="button" class="btn btn-sm btn-outline-info" 
                                                onclick="viewOrderDetails(<?php echo $order['order_id']; ?>)">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <?php if (in_array($order['status'], ['pending', 'preparing', 'ready'])): ?>
                                            <button type="button" class="btn btn-sm btn-outline-primary" 
                                                    onclick="updateOrderStatus(<?php echo $order['order_id']; ?>, '<?php echo $order['status']; ?>', '<?php echo htmlspecialchars($order['order_number']); ?>')">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                        <?php endif; ?>
                                        <?php if ($order['status'] === 'ready'): ?>
                                            <button type="button" class="btn btn-sm btn-success" 
                                                    onclick="markAsServed(<?php echo $order['order_id']; ?>, '<?php echo htmlspecialchars($order['order_number']); ?>')">
                                                <i class="fas fa-check"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Update Status Modal -->
<div class="modal fade" id="updateStatusModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-edit me-2"></i>Update Order Status
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="update_status">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="order_id" id="status_order_id">
                
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Updating status for order <strong id="status_order_number"></strong>
                    </div>
                    
                    <div class="mb-3">
                        <label for="status" class="form-label">New Status</label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="pending">Pending</option>
                            <option value="preparing">Preparing</option>
                            <option value="ready">Ready</option>
                            <option value="served">Served</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Update Status
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Order Details Modal -->
<div class="modal fade" id="orderDetailsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-receipt me-2"></i>Order Details
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="orderDetailsContent">
                <div class="text-center py-3">
                    <i class="fas fa-spinner fa-spin fa-2x"></i>
                    <p class="mt-2">Loading order details...</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="printOrderDetails()">
                    <i class="fas fa-print me-2"></i>Print Receipt
                </button>
            </div>
        </div>
    </div>
</div>

<?php
$additional_js = "
<script>
function updateOrderStatus(orderId, currentStatus, orderNumber) {
    document.getElementById('status_order_id').value = orderId;
    document.getElementById('status_order_number').textContent = orderNumber;
    document.getElementById('status').value = currentStatus;
    
    new bootstrap.Modal(document.getElementById('updateStatusModal')).show();
}

function markAsServed(orderId, orderNumber) {
    if (confirm('Mark order ' + orderNumber + ' as served?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type='hidden' name='action' value='update_status'>
            <input type='hidden' name='csrf_token' value='" . $csrf_token . "'>
            <input type='hidden' name='order_id' value='\${orderId}'>
            <input type='hidden' name='status' value='served'>
        `;
        document.body.appendChild(form);
        form.submit();
    }
}

function viewOrderDetails(orderId) {
    const modal = new bootstrap.Modal(document.getElementById('orderDetailsModal'));
    modal.show();
    
    // Load order details via AJAX
    fetch('/Restaurant_system/api/order_details.php?order_id=' + orderId)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('orderDetailsContent').innerHTML = data.html;
            } else {
                document.getElementById('orderDetailsContent').innerHTML = 
                    '<div class=\"alert alert-danger\">Error loading order details: ' + data.message + '</div>';
            }
        })
        .catch(error => {
            document.getElementById('orderDetailsContent').innerHTML = 
                '<div class=\"alert alert-danger\">Error loading order details. Please try again.</div>';
        });
}

function printOrderDetails() {
    const content = document.getElementById('orderDetailsContent').innerHTML;
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <html>
            <head>
                <title>Order Receipt</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 20px; }
                    .receipt-header { text-align: center; margin-bottom: 20px; }
                    .receipt-details { margin-bottom: 15px; }
                    .receipt-items { width: 100%; border-collapse: collapse; }
                    .receipt-items th, .receipt-items td { 
                        border: 1px solid #ddd; padding: 8px; text-align: left; 
                    }
                    .receipt-total { font-weight: bold; font-size: 1.2em; }
                </style>
            </head>
            <body>
                \${content}
            </body>
        </html>
    `);
    printWindow.document.close();
    printWindow.print();
}

// Auto-refresh every 30 seconds for pending/preparing orders
setInterval(function() {
    const hasPendingOrders = document.querySelector('.badge.bg-warning, .badge.bg-info');
    if (hasPendingOrders) {
        location.reload();
    }
}, 30000);
</script>
";

require_once '../../common/footer.php';
?>