<?php
// Sales Clerk - Billing System
$page_title = 'Billing System';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/sales_clerk/'],
    ['title' => 'Billing', 'url' => '']
];

require_once '../../common/header.php';
requireRole('sales_clerk');

// Handle form submissions
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!validateCSRFToken($csrf_token)) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        try {
            $pdo = getPDO();
            
            switch ($action) {
                case 'generate_bill':
                    $order_id = intval($_POST['order_id']);
                    $payment_method = $_POST['payment_method'];
                    $amount_paid = floatval($_POST['amount_paid']);
                    
                    // Get order details
                    $stmt = $pdo->prepare("
                        SELECT o.*, u.full_name as clerk_name
                        FROM orders o
                        JOIN users u ON o.created_by = u.user_id
                        WHERE o.order_id = ? AND o.created_by = ?
                    ");
                    $stmt->execute([$order_id, $_SESSION['user_id']]);
                    $order = $stmt->fetch();
                    
                    if (!$order) {
                        throw new Exception('Order not found or you do not have permission to bill this order.');
                    }
                    
                    if ($order['status'] !== 'ready' && $order['status'] !== 'served') {
                        throw new Exception('Order must be ready or served before billing.');
                    }
                    
                    if ($amount_paid < $order['total_amount']) {
                        throw new Exception('Amount paid cannot be less than the total amount.');
                    }
                    
                    // Calculate change
                    $change_amount = $amount_paid - $order['total_amount'];
                    
                    // Start transaction
                    $pdo->beginTransaction();
                    
                    // Create bill record
                    $stmt = $pdo->prepare("
                        INSERT INTO bills (order_id, total_amount, amount_paid, change_amount, 
                                         payment_method, status, created_by)
                        VALUES (?, ?, ?, ?, ?, 'paid', ?)
                    ");
                    $stmt->execute([
                        $order_id, $order['total_amount'], $amount_paid, 
                        $change_amount, $payment_method, $_SESSION['user_id']
                    ]);
                    
                    $bill_id = $pdo->lastInsertId();
                    
                    // Update order status to served if not already
                    if ($order['status'] !== 'served') {
                        $stmt = $pdo->prepare("UPDATE orders SET status = 'served' WHERE order_id = ?");
                        $stmt->execute([$order_id]);
                    }
                    
                    // Log activity
                    logActivity('Bill Generated', 'bills', $bill_id, null, [
                        'order_number' => $order['order_number'],
                        'total_amount' => $order['total_amount'],
                        'payment_method' => $payment_method
                    ]);
                    
                    $pdo->commit();
                    
                    $success_message = 'Bill generated successfully! Bill ID: ' . $bill_id;
                    
                    // Redirect to print receipt
                    header("Location: /Restaurant_system/sales_clerk/billing/receipt.php?bill_id=" . $bill_id);
                    exit;
                    
                    break;
            }
            
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollback();
            }
            $error_message = $e->getMessage();
            logError($error_message);
        }
    }
}

// Get filter parameters
$status_filter = $_GET['status'] ?? 'ready';
$date_filter = $_GET['date'] ?? date('Y-m-d');

try {
    $pdo = getPDO();
    
    // Get orders ready for billing
    $where_conditions = ["o.created_by = ?"];
    $params = [$_SESSION['user_id']];
    
    if (!empty($status_filter)) {
        $where_conditions[] = "o.status = ?";
        $params[] = $status_filter;
    }
    
    if (!empty($date_filter)) {
        $where_conditions[] = "DATE(o.created_at) = ?";
        $params[] = $date_filter;
    }
    
    $where_clause = 'WHERE ' . implode(' AND ', $where_conditions);
    
    $stmt = $pdo->prepare("
        SELECT o.*, 
               COUNT(oi.id) as item_count,
               b.bill_id,
               b.status as bill_status
        FROM orders o
        LEFT JOIN order_items oi ON o.order_id = oi.order_id
        LEFT JOIN bills b ON o.order_id = b.order_id
        $where_clause
        GROUP BY o.order_id
        ORDER BY o.created_at DESC
    ");
    $stmt->execute($params);
    $orders = $stmt->fetchAll();
    
    // Get today's billing statistics
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(b.bill_id) as total_bills,
            COALESCE(SUM(b.total_amount), 0) as total_revenue,
            COALESCE(SUM(b.change_amount), 0) as total_change,
            COUNT(CASE WHEN b.payment_method = 'cash' THEN 1 END) as cash_payments,
            COUNT(CASE WHEN b.payment_method = 'card' THEN 1 END) as card_payments,
            COUNT(CASE WHEN b.payment_method = 'mobile' THEN 1 END) as mobile_payments
        FROM bills b
        JOIN orders o ON b.order_id = o.order_id
        WHERE o.created_by = ? AND DATE(b.created_at) = CURDATE()
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $billing_stats = $stmt->fetch();
    
} catch (Exception $e) {
    $error_message = "Error loading billing data: " . $e->getMessage();
    $orders = [];
    $billing_stats = [];
}

$csrf_token = generateCSRFToken();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Billing System</h1>
        <p class="text-muted">Generate bills and process payments for orders</p>
    </div>
    <div>
        <a href="/Restaurant_system/sales_clerk/orders/take_order.php" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>New Order
        </a>
    </div>
</div>

<?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i>
        <?php echo htmlspecialchars($success_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error_message): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Today's Billing Statistics -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon success me-3">
                    <i class="fas fa-receipt"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Bills Generated</h6>
                    <h4 class="mb-0"><?php echo $billing_stats['total_bills'] ?? 0; ?></h4>
                    <small class="text-muted">Today</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon primary me-3">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Total Revenue</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($billing_stats['total_revenue'] ?? 0); ?></h4>
                    <small class="text-muted">Today</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon warning me-3">
                    <i class="fas fa-coins"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Change Given</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($billing_stats['total_change'] ?? 0); ?></h4>
                    <small class="text-muted">Today</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="text-center">
                <h6 class="text-muted mb-2">Payment Methods</h6>
                <div class="row">
                    <div class="col-4">
                        <small class="text-muted">Cash</small>
                        <div class="fw-bold"><?php echo $billing_stats['cash_payments'] ?? 0; ?></div>
                    </div>
                    <div class="col-4">
                        <small class="text-muted">Card</small>
                        <div class="fw-bold"><?php echo $billing_stats['card_payments'] ?? 0; ?></div>
                    </div>
                    <div class="col-4">
                        <small class="text-muted">Mobile</small>
                        <div class="fw-bold"><?php echo $billing_stats['mobile_payments'] ?? 0; ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-filter me-2"></i>Filters
        </h5>
    </div>
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-6">
                <label for="status" class="form-label">Order Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="ready" <?php echo $status_filter === 'ready' ? 'selected' : ''; ?>>Ready for Billing</option>
                    <option value="served" <?php echo $status_filter === 'served' ? 'selected' : ''; ?>>Served</option>
                    <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                    <option value="preparing" <?php echo $status_filter === 'preparing' ? 'selected' : ''; ?>>Preparing</option>
                </select>
            </div>
            
            <div class="col-md-6">
                <label for="date" class="form-label">Date</label>
                <input type="date" class="form-control" id="date" name="date" value="<?php echo htmlspecialchars($date_filter); ?>">
            </div>
            
            <div class="col-12">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search me-2"></i>Apply Filters
                </button>
                <a href="/Restaurant_system/sales_clerk/orders/billing.php" class="btn btn-outline-secondary">
                    <i class="fas fa-times me-2"></i>Clear Filters
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Orders for Billing -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-list me-2"></i>
            Orders for Billing
        </h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover data-table">
                <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Customer</th>
                        <th>Items</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Bill Status</th>
                        <th>Time</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($order['order_number']); ?></strong>
                            </td>
                            <td>
                                <?php echo htmlspecialchars($order['customer_name'] ?: 'Walk-in'); ?>
                                <?php if ($order['customer_phone']): ?>
                                    <br><small class="text-muted"><?php echo htmlspecialchars($order['customer_phone']); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-info"><?php echo $order['item_count']; ?> items</span>
                            </td>
                            <td>
                                <strong><?php echo formatCurrency($order['total_amount']); ?></strong>
                            </td>
                            <td>
                                <?php
                                $status_classes = [
                                    'pending' => 'warning',
                                    'preparing' => 'info',
                                    'ready' => 'primary',
                                    'served' => 'success',
                                    'cancelled' => 'danger'
                                ];
                                ?>
                                <span class="badge bg-<?php echo $status_classes[$order['status']] ?? 'secondary'; ?>">
                                    <?php echo ucfirst($order['status']); ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($order['bill_id']): ?>
                                    <span class="badge bg-success">Billed</span>
                                <?php else: ?>
                                    <span class="badge bg-warning">Pending</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <small><?php echo formatDisplayDateTime($order['created_at']); ?></small>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <button type="button" class="btn btn-sm btn-outline-info" 
                                            onclick="viewOrderDetails(<?php echo $order['order_id']; ?>)">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <?php if (!$order['bill_id'] && in_array($order['status'], ['ready', 'served'])): ?>
                                        <button type="button" class="btn btn-sm btn-success" 
                                                onclick="generateBill(<?php echo htmlspecialchars(json_encode($order)); ?>)">
                                            <i class="fas fa-receipt"></i>
                                        </button>
                                    <?php elseif ($order['bill_id']): ?>
                                        <a href="/Restaurant_system/sales_clerk/billing/receipt.php?bill_id=<?php echo $order['bill_id']; ?>" 
                                           class="btn btn-sm btn-outline-secondary" target="_blank">
                                            <i class="fas fa-print"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Generate Bill Modal -->
<div class="modal fade" id="generateBillModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-receipt me-2"></i>Generate Bill
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="generate_bill">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="order_id" id="bill_order_id">
                
                <div class="modal-body">
                    <div class="alert alert-info">
                        <div class="row">
                            <div class="col-6">
                                <strong>Order #:</strong> <span id="bill_order_number"></span>
                            </div>
                            <div class="col-6">
                                <strong>Customer:</strong> <span id="bill_customer_name"></span>
                            </div>
                            <div class="col-6">
                                <strong>Total Amount:</strong> <span id="bill_total_amount"></span>
                            </div>
                            <div class="col-6">
                                <strong>Items:</strong> <span id="bill_item_count"></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="payment_method" class="form-label">Payment Method *</label>
                        <select class="form-select" id="payment_method" name="payment_method" required>
                            <option value="">Select Payment Method</option>
                            <option value="cash">Cash</option>
                            <option value="card">Credit/Debit Card</option>
                            <option value="mobile">Mobile Money</option>
                        </select>
                        <div class="invalid-feedback">Please select a payment method.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="amount_paid" class="form-label">Amount Paid *</label>
                        <input type="number" class="form-control currency-input" id="amount_paid" name="amount_paid" 
                               step="0.01" min="0" required>
                        <div class="invalid-feedback">Please enter the amount paid.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Change to Give</label>
                        <div class="form-control-plaintext fw-bold text-success" id="change_amount">KES 0.00</div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-receipt me-2"></i>Generate Bill
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Order Details Modal -->
<div class="modal fade" id="orderDetailsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-list me-2"></i>Order Details
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="orderDetailsContent">
                <div class="text-center">
                    <div class="spinner-border" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let currentOrderTotal = 0;

function generateBill(order) {
    document.getElementById('bill_order_id').value = order.order_id;
    document.getElementById('bill_order_number').textContent = order.order_number;
    document.getElementById('bill_customer_name').textContent = order.customer_name || 'Walk-in';
    document.getElementById('bill_total_amount').textContent = 'KES ' + parseFloat(order.total_amount).toLocaleString('en-KE', {minimumFractionDigits: 2});
    document.getElementById('bill_item_count').textContent = order.item_count + ' items';
    
    currentOrderTotal = parseFloat(order.total_amount);
    
    // Reset form
    document.getElementById('payment_method').value = '';
    document.getElementById('amount_paid').value = currentOrderTotal.toFixed(2);
    updateChange();
    
    new bootstrap.Modal(document.getElementById('generateBillModal')).show();
}

function updateChange() {
    const amountPaid = parseFloat(document.getElementById('amount_paid').value) || 0;
    const change = amountPaid - currentOrderTotal;
    
    document.getElementById('change_amount').textContent = 'KES ' + Math.max(0, change).toLocaleString('en-KE', {minimumFractionDigits: 2});
    
    if (change < 0) {
        document.getElementById('change_amount').className = 'form-control-plaintext fw-bold text-danger';
    } else {
        document.getElementById('change_amount').className = 'form-control-plaintext fw-bold text-success';
    }
}

function viewOrderDetails(orderId) {
    const modal = new bootstrap.Modal(document.getElementById('orderDetailsModal'));
    modal.show();
    
    // Load order details via AJAX
    fetch('/Restaurant_system/api/order_details.php?order_id=' + orderId)
        .then(response => response.text())
        .then(data => {
            document.getElementById('orderDetailsContent').innerHTML = data;
        })
        .catch(error => {
            document.getElementById('orderDetailsContent').innerHTML = 
                '<div class="alert alert-danger">Error loading order details.</div>';
        });
}

// Update change calculation when amount paid changes
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('amount_paid').addEventListener('input', updateChange);
    
    // Initialize DataTable
    if (typeof $ !== 'undefined' && $.fn.DataTable) {
        $('.data-table').DataTable({
            responsive: true,
            pageLength: 25,
            order: [[6, 'desc']], // Sort by time descending
            columnDefs: [
                { orderable: false, targets: [7] } // Actions column
            ]
        });
    }
});
</script>

<?php require_once '../../common/footer.php'; ?>