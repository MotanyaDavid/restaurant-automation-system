<?php
// Sales Clerk - Take Order
$page_title = 'Take New Order';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/sales_clerk/'],
    ['title' => 'Take Order', 'url' => '']
];

require_once '../../common/header.php';
requireRole('sales_clerk');

// Handle form submission
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!validateCSRFToken($csrf_token)) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        try {
            $pdo = getPDO();
            
            if ($action === 'place_order') {
                $customer_name = sanitizeInput($_POST['customer_name'] ?? '');
                $table_number = sanitizeInput($_POST['table_number'] ?? '');
                $order_items = $_POST['order_items'] ?? [];
                
                if (empty($order_items)) {
                    throw new Exception('Please add at least one item to the order.');
                }
                
                // Validate order items
                $validated_items = [];
                $total_amount = 0;
                
                foreach ($order_items as $item) {
                    $item_id = intval($item['item_id']);
                    $quantity = intval($item['quantity']);
                    
                    if ($quantity <= 0) continue;
                    
                    // Get item details
                    $stmt = $pdo->prepare("SELECT * FROM menu_items WHERE item_id = ? AND status = 'available'");
                    $stmt->execute([$item_id]);
                    $menu_item = $stmt->fetch();
                    
                    if (!$menu_item) {
                        throw new Exception('Invalid menu item selected.');
                    }
                    
                    $subtotal = $menu_item['price'] * $quantity;
                    $total_amount += $subtotal;
                    
                    $validated_items[] = [
                        'item_id' => $item_id,
                        'quantity' => $quantity,
                        'unit_price' => $menu_item['price'],
                        'subtotal' => $subtotal,
                        'item_name' => $menu_item['item_name']
                    ];
                }
                
                if (empty($validated_items)) {
                    throw new Exception('No valid items in the order.');
                }
                
                // Check if order can be fulfilled (enough ingredients)
                $fulfillment_check = canFulfillOrder($validated_items);
                if (!$fulfillment_check['can_fulfill']) {
                    if (isset($fulfillment_check['missing_ingredient'])) {
                        throw new Exception("Insufficient stock for {$fulfillment_check['missing_ingredient']}. Available: {$fulfillment_check['available']}, Required: {$fulfillment_check['required']}");
                    } else {
                        throw new Exception('Order cannot be fulfilled due to insufficient ingredients.');
                    }
                }
                
                $pdo->beginTransaction();
                
                // Generate order number
                $order_number = generateOrderNumber();
                
                // Insert order
                $stmt = $pdo->prepare("
                    INSERT INTO orders (order_number, customer_name, table_number, total_amount, created_by)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $order_number,
                    $customer_name ?: null,
                    $table_number ?: null,
                    $total_amount,
                    $_SESSION['user_id']
                ]);
                
                $order_id = $pdo->lastInsertId();
                
                // Insert order items
                $stmt = $pdo->prepare("
                    INSERT INTO order_items (order_id, item_id, quantity, unit_price, subtotal)
                    VALUES (?, ?, ?, ?, ?)
                ");
                
                foreach ($validated_items as $item) {
                    $stmt->execute([
                        $order_id,
                        $item['item_id'],
                        $item['quantity'],
                        $item['unit_price'],
                        $item['subtotal']
                    ]);
                }
                
                // Update ingredient stock using stored procedure
                $stmt = $pdo->prepare("CALL ProcessOrder(?)");
                $stmt->execute([$order_id]);
                
                $pdo->commit();
                
                logActivity('Order Created', 'orders', $order_id, null, [
                    'order_number' => $order_number,
                    'total_amount' => $total_amount,
                    'items_count' => count($validated_items)
                ]);
                
                $success_message = "Order #{$order_number} placed successfully! Total: " . formatCurrency($total_amount);
                
                // Clear form data
                $_POST = [];
                
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error_message = $e->getMessage();
            logError($error_message);
        }
    }
}

// Get available menu items
try {
    $pdo = getPDO();
    $stmt = $pdo->prepare("
        SELECT mi.*, 
               GROUP_CONCAT(
                   CONCAT(i.ingredient_name, ' (', mii.quantity_required, ' ', i.unit, ')')
                   SEPARATOR ', '
               ) as ingredients
        FROM menu_items mi
        LEFT JOIN menu_item_ingredients mii ON mi.item_id = mii.item_id
        LEFT JOIN ingredients i ON mii.ingredient_id = i.ingredient_id
        WHERE mi.status = 'available'
        GROUP BY mi.item_id
        ORDER BY mi.category, mi.item_name
    ");
    $stmt->execute();
    $menu_items = $stmt->fetchAll();
    
    // Group by category
    $menu_by_category = [];
    foreach ($menu_items as $item) {
        $category = $item['category'] ?: 'Other';
        $menu_by_category[$category][] = $item;
    }
    
} catch (Exception $e) {
    $error_message = "Error loading menu items: " . $e->getMessage();
    $menu_by_category = [];
}

$csrf_token = generateCSRFToken();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Take New Order</h1>
        <p class="text-muted">Create a new customer order</p>
    </div>
    <div>
        <a href="/Restaurant_system/sales_clerk/orders/view_orders.php" class="btn btn-outline-primary">
            <i class="fas fa-list me-2"></i>View Orders
        </a>
    </div>
</div>

<?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i>
        <?php echo htmlspecialchars($success_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error_message): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<form method="POST" id="orderForm" class="needs-validation" novalidate>
    <input type="hidden" name="action" value="place_order">
    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
    
    <div class="row">
        <!-- Order Details -->
        <div class="col-lg-4 mb-4">
            <div class="card sticky-top" style="top: 100px;">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-receipt me-2"></i>
                        Order Details
                    </h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="customer_name" class="form-label">Customer Name</label>
                        <input type="text" class="form-control" id="customer_name" name="customer_name" 
                               placeholder="Optional - Walk-in customer">
                    </div>
                    
                    <div class="mb-3">
                        <label for="table_number" class="form-label">Table Number</label>
                        <input type="text" class="form-control" id="table_number" name="table_number" 
                               placeholder="Optional">
                    </div>
                    
                    <hr>
                    
                    <!-- Order Summary -->
                    <div id="orderSummary">
                        <h6 class="text-muted mb-3">Order Summary</h6>
                        <div id="orderItems">
                            <p class="text-muted text-center py-3">No items added yet</p>
                        </div>
                        
                        <hr>
                        
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <strong>Total Amount:</strong>
                            <strong class="text-success" id="totalAmount">KES 0.00</strong>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100" id="placeOrderBtn" disabled>
                            <i class="fas fa-shopping-cart me-2"></i>
                            Place Order
                        </button>
                        
                        <button type="button" class="btn btn-outline-secondary w-100 mt-2" onclick="clearOrder()">
                            <i class="fas fa-trash me-2"></i>
                            Clear Order
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Menu Items -->
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-utensils me-2"></i>
                        Menu Items
                    </h5>
                </div>
                <div class="card-body">
                    <?php if (empty($menu_by_category)): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-utensils fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">No menu items available</h5>
                            <p class="text-muted">Please contact the manager to add menu items.</p>
                        </div>
                    <?php else: ?>
                        <!-- Category Tabs -->
                        <ul class="nav nav-tabs mb-4" id="categoryTabs" role="tablist">
                            <?php $first = true; foreach ($menu_by_category as $category => $items): ?>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link <?php echo $first ? 'active' : ''; ?>" 
                                            id="<?php echo strtolower(str_replace(' ', '-', $category)); ?>-tab" 
                                            data-bs-toggle="tab" 
                                            data-bs-target="#<?php echo strtolower(str_replace(' ', '-', $category)); ?>" 
                                            type="button" role="tab">
                                        <?php echo htmlspecialchars($category); ?>
                                        <span class="badge bg-secondary ms-1"><?php echo count($items); ?></span>
                                    </button>
                                </li>
                                <?php $first = false; ?>
                            <?php endforeach; ?>
                        </ul>
                        
                        <!-- Category Content -->
                        <div class="tab-content" id="categoryTabsContent">
                            <?php $first = true; foreach ($menu_by_category as $category => $items): ?>
                                <div class="tab-pane fade <?php echo $first ? 'show active' : ''; ?>" 
                                     id="<?php echo strtolower(str_replace(' ', '-', $category)); ?>" 
                                     role="tabpanel">
                                    <div class="row">
                                        <?php foreach ($items as $item): ?>
                                            <div class="col-md-6 col-lg-4 mb-3">
                                                <div class="card h-100 menu-item-card" data-item-id="<?php echo $item['item_id']; ?>">
                                                    <div class="card-body">
                                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                                            <h6 class="card-title mb-0"><?php echo htmlspecialchars($item['item_name']); ?></h6>
                                                            <span class="badge bg-primary"><?php echo htmlspecialchars($item['item_code']); ?></span>
                                                        </div>
                                                        
                                                        <?php if ($item['description']): ?>
                                                            <p class="card-text small text-muted mb-2">
                                                                <?php echo htmlspecialchars($item['description']); ?>
                                                            </p>
                                                        <?php endif; ?>
                                                        
                                                        <?php if ($item['ingredients']): ?>
                                                            <p class="card-text small text-muted mb-2">
                                                                <strong>Ingredients:</strong> <?php echo htmlspecialchars($item['ingredients']); ?>
                                                            </p>
                                                        <?php endif; ?>
                                                        
                                                        <div class="d-flex justify-content-between align-items-center">
                                                            <strong class="text-success"><?php echo formatCurrency($item['price']); ?></strong>
                                                            <div class="btn-group" role="group">
                                                                <button type="button" class="btn btn-outline-primary btn-sm" 
                                                                        onclick="addToOrder(<?php echo $item['item_id']; ?>, '<?php echo htmlspecialchars($item['item_name']); ?>', <?php echo $item['price']; ?>)">
                                                                    <i class="fas fa-plus"></i>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <?php $first = false; ?>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</form>

<?php
$additional_js = "
<script>
let orderItems = {};
let orderTotal = 0;

function addToOrder(itemId, itemName, price) {
    if (orderItems[itemId]) {
        orderItems[itemId].quantity++;
    } else {
        orderItems[itemId] = {
            name: itemName,
            price: price,
            quantity: 1
        };
    }
    updateOrderSummary();
}

function removeFromOrder(itemId) {
    if (orderItems[itemId]) {
        orderItems[itemId].quantity--;
        if (orderItems[itemId].quantity <= 0) {
            delete orderItems[itemId];
        }
    }
    updateOrderSummary();
}

function updateQuantity(itemId, quantity) {
    if (quantity <= 0) {
        delete orderItems[itemId];
    } else {
        orderItems[itemId].quantity = quantity;
    }
    updateOrderSummary();
}

function updateOrderSummary() {
    const orderItemsDiv = document.getElementById('orderItems');
    const totalAmountSpan = document.getElementById('totalAmount');
    const placeOrderBtn = document.getElementById('placeOrderBtn');
    
    if (Object.keys(orderItems).length === 0) {
        orderItemsDiv.innerHTML = '<p class=\"text-muted text-center py-3\">No items added yet</p>';
        orderTotal = 0;
        placeOrderBtn.disabled = true;
    } else {
        let html = '';
        orderTotal = 0;
        
        for (const [itemId, item] of Object.entries(orderItems)) {
            const subtotal = item.price * item.quantity;
            orderTotal += subtotal;
            
            html += `
                <div class=\"d-flex justify-content-between align-items-center mb-2 p-2 bg-light rounded\">
                    <div class=\"flex-grow-1\">
                        <strong>\${item.name}</strong><br>
                        <small class=\"text-muted\">KES \${item.price.toFixed(2)} each</small>
                    </div>
                    <div class=\"d-flex align-items-center\">
                        <button type=\"button\" class=\"btn btn-sm btn-outline-secondary me-1\" 
                                onclick=\"removeFromOrder(\${itemId})\">
                            <i class=\"fas fa-minus\"></i>
                        </button>
                        <input type=\"number\" class=\"form-control form-control-sm mx-1\" 
                               style=\"width: 60px;\" value=\"\${item.quantity}\" min=\"1\"
                               onchange=\"updateQuantity(\${itemId}, parseInt(this.value))\"
                               name=\"order_items[\${Object.keys(orderItems).indexOf(itemId)}][quantity]\">
                        <input type=\"hidden\" name=\"order_items[\${Object.keys(orderItems).indexOf(itemId)}][item_id]\" value=\"\${itemId}\">
                        <button type=\"button\" class=\"btn btn-sm btn-outline-primary ms-1\" 
                                onclick=\"addToOrder(\${itemId}, '\${item.name}', \${item.price})\">
                            <i class=\"fas fa-plus\"></i>
                        </button>
                    </div>
                </div>
                <div class=\"text-end mb-2\">
                    <small class=\"text-muted\">Subtotal: <strong>KES \${subtotal.toFixed(2)}</strong></small>
                </div>
            `;
        }
        
        orderItemsDiv.innerHTML = html;
        placeOrderBtn.disabled = false;
    }
    
    totalAmountSpan.textContent = 'KES ' + orderTotal.toFixed(2);
}

function clearOrder() {
    if (confirm('Are you sure you want to clear the entire order?')) {
        orderItems = {};
        updateOrderSummary();
    }
}

// Form submission
document.getElementById('orderForm').addEventListener('submit', function(e) {
    if (Object.keys(orderItems).length === 0) {
        e.preventDefault();
        alert('Please add at least one item to the order.');
        return false;
    }
    
    // Show loading state
    const submitBtn = document.getElementById('placeOrderBtn');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class=\"fas fa-spinner fa-spin me-2\"></i>Placing Order...';
    submitBtn.disabled = true;
    
    // Re-enable button after 10 seconds (in case of slow response)
    setTimeout(function() {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }, 10000);
});

// Menu item card hover effects
document.addEventListener('DOMContentLoaded', function() {
    const style = document.createElement('style');
    style.textContent = `
        .menu-item-card {
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .menu-item-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }
        .sticky-top {
            position: sticky !important;
        }
    `;
    document.head.appendChild(style);
});
</script>
";

require_once '../../common/footer.php';
?>