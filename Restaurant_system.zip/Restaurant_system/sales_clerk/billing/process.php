<?php
// Sales Clerk - Billing System
$page_title = 'Process Bill';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/sales_clerk/'],
    ['title' => 'Billing', 'url' => '']
];

require_once '../../common/header.php';
requireRole('sales_clerk');

// Handle form submissions
$success_message = '';
$error_message = '';
$bill_data = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!validateCSRFToken($csrf_token)) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        try {
            $pdo = getPDO();
            
            switch ($action) {
                case 'create_bill':
                    $order_id = intval($_POST['order_id']);
                    $payment_method = sanitizeInput($_POST['payment_method']);
                    $discount_percentage = floatval($_POST['discount_percentage'] ?? 0);
                    $tax_percentage = floatval($_POST['tax_percentage'] ?? 16); // Default VAT 16%
                    $customer_name = sanitizeInput($_POST['customer_name'] ?? '');
                    $customer_phone = sanitizeInput($_POST['customer_phone'] ?? '');
                    $notes = sanitizeInput($_POST['notes'] ?? '');
                    
                    if (empty($order_id) || empty($payment_method)) {
                        throw new Exception('Please fill in all required fields.');
                    }
                    
                    // Get order details
                    $stmt = $pdo->prepare("
                        SELECT o.*, u.full_name as clerk_name
                        FROM orders o
                        JOIN users u ON o.created_by = u.user_id
                        WHERE o.order_id = ? AND o.status = 'completed'
                    ");
                    $stmt->execute([$order_id]);
                    $order = $stmt->fetch();
                    
                    if (!$order) {
                        throw new Exception('Order not found or not completed.');
                    }
                    
                    // Check if bill already exists
                    $stmt = $pdo->prepare("SELECT bill_id FROM bills WHERE order_id = ?");
                    $stmt->execute([$order_id]);
                    if ($stmt->fetch()) {
                        throw new Exception('Bill already exists for this order.');
                    }
                    
                    // Get order items
                    $stmt = $pdo->prepare("
                        SELECT oi.*, mi.item_name, mi.price as unit_price
                        FROM order_items oi
                        JOIN menu_items mi ON oi.menu_item_id = mi.menu_item_id
                        WHERE oi.order_id = ?
                    ");
                    $stmt->execute([$order_id]);
                    $order_items = $stmt->fetchAll();
                    
                    if (empty($order_items)) {
                        throw new Exception('No items found for this order.');
                    }
                    
                    // Calculate totals
                    $subtotal = 0;
                    foreach ($order_items as $item) {
                        $subtotal += $item['quantity'] * $item['unit_price'];
                    }
                    
                    $discount_amount = ($subtotal * $discount_percentage) / 100;
                    $discounted_subtotal = $subtotal - $discount_amount;
                    $tax_amount = ($discounted_subtotal * $tax_percentage) / 100;
                    $total_amount = $discounted_subtotal + $tax_amount;
                    
                    // Generate bill number
                    $bill_number = 'BILL-' . date('Ymd') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
                    
                    // Start transaction
                    $pdo->beginTransaction();
                    
                    try {
                        // Create bill
                        $stmt = $pdo->prepare("
                            INSERT INTO bills (bill_number, order_id, subtotal, discount_percentage, 
                                             discount_amount, tax_percentage, tax_amount, total_amount,
                                             payment_method, customer_name, customer_phone, notes,
                                             created_by, created_at)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                        ");
                        $stmt->execute([
                            $bill_number, $order_id, $subtotal, $discount_percentage,
                            $discount_amount, $tax_percentage, $tax_amount, $total_amount,
                            $payment_method, $customer_name, $customer_phone, $notes,
                            $_SESSION['user_id']
                        ]);
                        
                        $bill_id = $pdo->lastInsertId();
                        
                        // Create bill items
                        foreach ($order_items as $item) {
                            $stmt = $pdo->prepare("
                                INSERT INTO bill_items (bill_id, menu_item_id, item_name, quantity, 
                                                      unit_price, total_price)
                                VALUES (?, ?, ?, ?, ?, ?)
                            ");
                            $stmt->execute([
                                $bill_id, $item['menu_item_id'], $item['item_name'],
                                $item['quantity'], $item['unit_price'],
                                $item['quantity'] * $item['unit_price']
                            ]);
                        }
                        
                        // Update order status to billed
                        $stmt = $pdo->prepare("UPDATE orders SET status = 'billed' WHERE order_id = ?");
                        $stmt->execute([$order_id]);
                        
                        // Record payment
                        $stmt = $pdo->prepare("
                            INSERT INTO payments (bill_id, amount, payment_method, payment_status,
                                                created_by, created_at)
                            VALUES (?, ?, ?, 'completed', ?, NOW())
                        ");
                        $stmt->execute([$bill_id, $total_amount, $payment_method, $_SESSION['user_id']]);
                        
                        // Update daily sales
                        $stmt = $pdo->prepare("
                            INSERT INTO daily_sales (sale_date, total_sales, total_orders, created_by)
                            VALUES (CURDATE(), ?, 1, ?)
                            ON DUPLICATE KEY UPDATE 
                            total_sales = total_sales + VALUES(total_sales),
                            total_orders = total_orders + VALUES(total_orders)
                        ");
                        $stmt->execute([$total_amount, $_SESSION['user_id']]);
                        
                        $pdo->commit();
                        
                        // Log activity
                        logActivity('Bill Created', 'bills', $bill_id, null, [
                            'bill_number' => $bill_number,
                            'order_id' => $order_id,
                            'total_amount' => $total_amount,
                            'payment_method' => $payment_method
                        ]);
                        
                        $success_message = "Bill {$bill_number} created successfully!";
                        
                        // Get bill data for display
                        $stmt = $pdo->prepare("
                            SELECT b.*, o.order_number, u.full_name as clerk_name
                            FROM bills b
                            JOIN orders o ON b.order_id = o.order_id
                            JOIN users u ON b.created_by = u.user_id
                            WHERE b.bill_id = ?
                        ");
                        $stmt->execute([$bill_id]);
                        $bill_data = $stmt->fetch();
                        
                        // Get bill items
                        $stmt = $pdo->prepare("SELECT * FROM bill_items WHERE bill_id = ?");
                        $stmt->execute([$bill_id]);
                        $bill_data['items'] = $stmt->fetchAll();
                        
                    } catch (Exception $e) {
                        $pdo->rollBack();
                        throw $e;
                    }
                    break;
                    
                case 'search_order':
                    $search_term = sanitizeInput($_POST['search_term']);
                    
                    if (empty($search_term)) {
                        throw new Exception('Please enter an order number or customer name.');
                    }
                    
                    // Search for completed orders
                    $stmt = $pdo->prepare("
                        SELECT o.*, u.full_name as clerk_name,
                               (SELECT COUNT(*) FROM bills WHERE order_id = o.order_id) as has_bill
                        FROM orders o
                        JOIN users u ON o.created_by = u.user_id
                        WHERE (o.order_number LIKE ? OR o.customer_name LIKE ?)
                        AND o.status = 'completed'
                        ORDER BY o.created_at DESC
                        LIMIT 10
                    ");
                    $search_pattern = '%' . $search_term . '%';
                    $stmt->execute([$search_pattern, $search_pattern]);
                    $search_results = $stmt->fetchAll();
                    break;
            }
            
        } catch (Exception $e) {
            $error_message = $e->getMessage();
            logError($error_message);
        }
    }
}

// Get recent bills
try {
    $pdo = getPDO();
    
    $stmt = $pdo->prepare("
        SELECT b.*, o.order_number, u.full_name as clerk_name
        FROM bills b
        JOIN orders o ON b.order_id = o.order_id
        JOIN users u ON b.created_by = u.user_id
        WHERE DATE(b.created_at) = CURDATE()
        ORDER BY b.created_at DESC
        LIMIT 20
    ");
    $stmt->execute();
    $recent_bills = $stmt->fetchAll();
    
    // Get today's billing summary
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_bills,
            SUM(total_amount) as total_revenue,
            AVG(total_amount) as average_bill,
            SUM(CASE WHEN payment_method = 'cash' THEN total_amount ELSE 0 END) as cash_sales,
            SUM(CASE WHEN payment_method = 'card' THEN total_amount ELSE 0 END) as card_sales,
            SUM(CASE WHEN payment_method = 'mobile' THEN total_amount ELSE 0 END) as mobile_sales
        FROM bills 
        WHERE DATE(created_at) = CURDATE()
    ");
    $stmt->execute();
    $billing_summary = $stmt->fetch();
    
} catch (Exception $e) {
    $error_message = "Error loading billing data: " . $e->getMessage();
    $recent_bills = [];
    $billing_summary = [
        'total_bills' => 0,
        'total_revenue' => 0,
        'average_bill' => 0,
        'cash_sales' => 0,
        'card_sales' => 0,
        'mobile_sales' => 0
    ];
}

$csrf_token = generateCSRFToken();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Billing System</h1>
        <p class="text-muted">Process customer bills and payments</p>
    </div>
    <div>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#searchOrderModal">
            <i class="fas fa-search me-2"></i>Find Order
        </button>
    </div>
</div>

<?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i>
        <?php echo htmlspecialchars($success_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error_message): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Billing Summary Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon primary me-3">
                    <i class="fas fa-receipt"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Today's Bills</h6>
                    <h4 class="mb-0"><?php echo $billing_summary['total_bills']; ?></h4>
                    <small class="text-muted">Total processed</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon success me-3">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Total Revenue</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($billing_summary['total_revenue']); ?></h4>
                    <small class="text-muted">Today's earnings</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon info me-3">
                    <i class="fas fa-calculator"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Average Bill</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($billing_summary['average_bill']); ?></h4>
                    <small class="text-muted">Per transaction</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon warning me-3">
                    <i class="fas fa-credit-card"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Payment Methods</h6>
                    <div class="small">
                        <div>Cash: <?php echo formatCurrency($billing_summary['cash_sales']); ?></div>
                        <div>Card: <?php echo formatCurrency($billing_summary['card_sales']); ?></div>
                        <div>Mobile: <?php echo formatCurrency($billing_summary['mobile_sales']); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bill Display -->
<?php if ($bill_data): ?>
    <div class="card mb-4" id="billDisplay">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">
                <i class="fas fa-receipt me-2"></i>
                Bill: <?php echo htmlspecialchars($bill_data['bill_number']); ?>
            </h5>
            <div>
                <button type="button" class="btn btn-sm btn-outline-primary" onclick="printBill()">
                    <i class="fas fa-print me-2"></i>Print
                </button>
                <button type="button" class="btn btn-sm btn-outline-secondary" onclick="emailBill()">
                    <i class="fas fa-envelope me-2"></i>Email
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <h6>Bill Details</h6>
                    <table class="table table-sm table-borderless">
                        <tr>
                            <td><strong>Bill Number:</strong></td>
                            <td><?php echo htmlspecialchars($bill_data['bill_number']); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Order Number:</strong></td>
                            <td><?php echo htmlspecialchars($bill_data['order_number']); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Date:</strong></td>
                            <td><?php echo formatDisplayDateTime($bill_data['created_at']); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Clerk:</strong></td>
                            <td><?php echo htmlspecialchars($bill_data['clerk_name']); ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <h6>Customer Details</h6>
                    <table class="table table-sm table-borderless">
                        <tr>
                            <td><strong>Name:</strong></td>
                            <td><?php echo htmlspecialchars($bill_data['customer_name'] ?: 'Walk-in Customer'); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Phone:</strong></td>
                            <td><?php echo htmlspecialchars($bill_data['customer_phone'] ?: 'N/A'); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Payment Method:</strong></td>
                            <td>
                                <span class="badge bg-info">
                                    <?php echo ucfirst($bill_data['payment_method']); ?>
                                </span>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <hr>
            
            <h6>Items</h6>
            <div class="table-responsive">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bill_data['items'] as $item): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['item_name']); ?></td>
                                <td><?php echo $item['quantity']; ?></td>
                                <td><?php echo formatCurrency($item['unit_price']); ?></td>
                                <td><?php echo formatCurrency($item['total_price']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="row">
                <div class="col-md-6 offset-md-6">
                    <table class="table table-sm">
                        <tr>
                            <td><strong>Subtotal:</strong></td>
                            <td class="text-end"><?php echo formatCurrency($bill_data['subtotal']); ?></td>
                        </tr>
                        <?php if ($bill_data['discount_percentage'] > 0): ?>
                            <tr>
                                <td><strong>Discount (<?php echo $bill_data['discount_percentage']; ?>%):</strong></td>
                                <td class="text-end text-success">-<?php echo formatCurrency($bill_data['discount_amount']); ?></td>
                            </tr>
                        <?php endif; ?>
                        <tr>
                            <td><strong>Tax (<?php echo $bill_data['tax_percentage']; ?>%):</strong></td>
                            <td class="text-end"><?php echo formatCurrency($bill_data['tax_amount']); ?></td>
                        </tr>
                        <tr class="table-primary">
                            <td><strong>Total Amount:</strong></td>
                            <td class="text-end"><strong><?php echo formatCurrency($bill_data['total_amount']); ?></strong></td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <?php if ($bill_data['notes']): ?>
                <div class="mt-3">
                    <h6>Notes</h6>
                    <p class="text-muted"><?php echo htmlspecialchars($bill_data['notes']); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<!-- Recent Bills -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-history me-2"></i>
            Today's Bills
        </h5>
    </div>
    <div class="card-body">
        <?php if (empty($recent_bills)): ?>
            <p class="text-center text-muted py-3 mb-0">No bills processed today</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Bill Number</th>
                            <th>Order Number</th>
                            <th>Customer</th>
                            <th>Amount</th>
                            <th>Payment Method</th>
                            <th>Time</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_bills as $bill): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($bill['bill_number']); ?></strong>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($bill['order_number']); ?>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($bill['customer_name'] ?: 'Walk-in'); ?>
                                </td>
                                <td>
                                    <strong><?php echo formatCurrency($bill['total_amount']); ?></strong>
                                </td>
                                <td>
                                    <span class="badge bg-info">
                                        <?php echo ucfirst($bill['payment_method']); ?>
                                    </span>
                                </td>
                                <td>
                                    <small><?php echo formatDisplayDateTime($bill['created_at']); ?></small>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <button type="button" class="btn btn-sm btn-outline-primary" 
                                                onclick="viewBill(<?php echo $bill['bill_id']; ?>)">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" 
                                                onclick="printBillById(<?php echo $bill['bill_id']; ?>)">
                                            <i class="fas fa-print"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Search Order Modal -->
<div class="modal fade" id="searchOrderModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-search me-2"></i>Find Order to Bill
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="search_order">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="search_term" class="form-label">Search by Order Number or Customer Name</label>
                        <input type="text" class="form-control" id="search_term" name="search_term" 
                               placeholder="Enter order number or customer name..." required>
                        <div class="invalid-feedback">Please enter search term.</div>
                    </div>
                    
                    <?php if (isset($search_results)): ?>
                        <div class="mt-4">
                            <h6>Search Results</h6>
                            <?php if (empty($search_results)): ?>
                                <p class="text-muted">No completed orders found.</p>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-sm table-hover">
                                        <thead>
                                            <tr>
                                                <th>Order Number</th>
                                                <th>Customer</th>
                                                <th>Total</th>
                                                <th>Date</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($search_results as $order): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($order['order_number']); ?></td>
                                                    <td><?php echo htmlspecialchars($order['customer_name'] ?: 'Walk-in'); ?></td>
                                                    <td><?php echo formatCurrency($order['total_amount']); ?></td>
                                                    <td><?php echo formatDisplayDateTime($order['created_at']); ?></td>
                                                    <td>
                                                        <?php if ($order['has_bill'] > 0): ?>
                                                            <span class="badge bg-success">Billed</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-warning">Pending Bill</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if ($order['has_bill'] == 0): ?>
                                                            <button type="button" class="btn btn-sm btn-primary" 
                                                                    onclick="createBillForOrder(<?php echo $order['order_id']; ?>, '<?php echo htmlspecialchars($order['order_number']); ?>', <?php echo $order['total_amount']; ?>)">
                                                                Create Bill
                                                            </button>
                                                        <?php else: ?>
                                                            <span class="text-muted">Already billed</span>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search me-2"></i>Search Orders
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Create Bill Modal -->
<div class="modal fade" id="createBillModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-receipt me-2"></i>Create Bill
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="create_bill">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="order_id" id="bill_order_id">
                
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Creating bill for Order: <strong id="bill_order_number"></strong>
                        <br>Order Total: <strong id="bill_order_total"></strong>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="payment_method" class="form-label">Payment Method *</label>
                            <select class="form-select" id="payment_method" name="payment_method" required>
                                <option value="">Select Method</option>
                                <option value="cash">Cash</option>
                                <option value="card">Credit/Debit Card</option>
                                <option value="mobile">Mobile Money</option>
                            </select>
                            <div class="invalid-feedback">Please select payment method.</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="discount_percentage" class="form-label">Discount (%)</label>
                            <input type="number" class="form-control" id="discount_percentage" name="discount_percentage" 
                                   step="0.01" min="0" max="100" value="0">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="tax_percentage" class="form-label">Tax (%)</label>
                            <input type="number" class="form-control" id="tax_percentage" name="tax_percentage" 
                                   step="0.01" min="0" value="16">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="customer_name" class="form-label">Customer Name</label>
                            <input type="text" class="form-control" id="customer_name" name="customer_name">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="customer_phone" class="form-label">Customer Phone</label>
                            <input type="tel" class="form-control" id="customer_phone" name="customer_phone">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="notes" class="form-label">Notes</label>
                        <textarea class="form-control" id="notes" name="notes" rows="2"
                                  placeholder="Additional notes or comments..."></textarea>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-receipt me-2"></i>Create Bill
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// JavaScript functions for billing system
function createBillForOrder(orderId, orderNumber, orderTotal) {
    document.getElementById('bill_order_id').value = orderId;
    document.getElementById('bill_order_number').textContent = orderNumber;
    document.getElementById('bill_order_total').textContent = formatCurrency(orderTotal);
    
    // Reset form
    document.getElementById('payment_method').value = '';
    document.getElementById('discount_percentage').value = '0';
    document.getElementById('tax_percentage').value = '16';
    document.getElementById('customer_name').value = '';
    document.getElementById('customer_phone').value = '';
    document.getElementById('notes').value = '';
    
    // Close search modal and open create bill modal
    bootstrap.Modal.getInstance(document.getElementById('searchOrderModal')).hide();
    new bootstrap.Modal(document.getElementById('createBillModal')).show();
}

function viewBill(billId) {
    // Redirect to bill view page
    window.location.href = `/Restaurant_system/sales_clerk/billing/view.php?bill_id=${billId}`;
}

function printBill() {
    const billContent = document.getElementById('billDisplay').innerHTML;
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <html>
        <head>
            <title>Bill Print</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                .card { border: 1px solid #ddd; padding: 20px; }
                .table { width: 100%; border-collapse: collapse; }
                .table th, .table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                .table th { background-color: #f2f2f2; }
                .text-end { text-align: right; }
                .badge { padding: 2px 6px; background-color: #007bff; color: white; border-radius: 3px; }
                @media print { .btn { display: none; } }
            </style>
        </head>
        <body>
            ${billContent}
        </body>
        </html>
    `);
    printWindow.document.close();
    printWindow.print();
}

function printBillById(billId) {
    // Open bill in new window for printing
    window.open(`/Restaurant_system/sales_clerk/billing/print.php?bill_id=${billId}`, '_blank');
}

function emailBill() {
    alert('Email functionality will be implemented in future version.');
}

function formatCurrency(amount) {
    return 'KES ' + parseFloat(amount).toLocaleString('en-KE', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

// Auto-refresh billing data every 2 minutes
setInterval(function() {
    if (!document.querySelector('.modal.show')) {
        location.reload();
    }
}, 120000);

// Calculate totals in real-time
document.addEventListener('DOMContentLoaded', function() {
    const discountInput = document.getElementById('discount_percentage');
    const taxInput = document.getElementById('tax_percentage');
    
    if (discountInput && taxInput) {
        [discountInput, taxInput].forEach(input => {
            input.addEventListener('input', function() {
                // Real-time calculation could be added here
                // For now, calculation happens on server side
            });
        });
    }
});
</script>

<?php require_once '../../common/footer.php'; ?>