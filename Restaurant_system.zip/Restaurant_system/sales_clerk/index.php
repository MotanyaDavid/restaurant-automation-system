<?php
// Sales Clerk Dashboard
$page_title = 'Sales Clerk Dashboard';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '']
];

require_once '../common/header.php';
requireRole('sales_clerk');

try {
    $pdo = getPDO();
    
    // Get dashboard statistics for current user
    // Today's orders by this clerk
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count, COALESCE(SUM(total_amount), 0) as revenue
        FROM orders 
        WHERE DATE(created_at) = CURDATE() 
        AND created_by = ?
        AND status IN ('served', 'ready')
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $today_stats = $stmt->fetch();
    
    // Pending orders by this clerk
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count
        FROM orders 
        WHERE created_by = ?
        AND status IN ('pending', 'preparing')
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $pending_orders = $stmt->fetch()['count'];
    
    // Total orders by this clerk
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count
        FROM orders 
        WHERE created_by = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $total_orders = $stmt->fetch()['count'];
    
    // Available menu items
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count
        FROM menu_items 
        WHERE status = 'available'
    ");
    $stmt->execute();
    $available_items = $stmt->fetch()['count'];
    
    // Recent orders by this clerk
    $stmt = $pdo->prepare("
        SELECT order_id, order_number, customer_name, total_amount, status, created_at
        FROM orders 
        WHERE created_by = ?
        ORDER BY created_at DESC
        LIMIT 10
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $recent_orders = $stmt->fetchAll();
    
    // Popular menu items (for quick reference)
    $stmt = $pdo->prepare("
        SELECT mi.item_id, mi.item_name, mi.item_code, mi.price, mi.category,
               COUNT(oi.id) as order_count
        FROM menu_items mi
        LEFT JOIN order_items oi ON mi.item_id = oi.item_id
        LEFT JOIN orders o ON oi.order_id = o.order_id
        WHERE mi.status = 'available'
        AND (o.created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) OR o.created_at IS NULL)
        GROUP BY mi.item_id
        ORDER BY order_count DESC, mi.item_name ASC
        LIMIT 8
    ");
    $stmt->execute();
    $popular_items = $stmt->fetchAll();
    
    // This week's performance
    $stmt = $pdo->prepare("
        SELECT 
            DATE(created_at) as order_date,
            COUNT(*) as orders,
            SUM(total_amount) as revenue
        FROM orders 
        WHERE created_by = ?
        AND created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        AND status IN ('served', 'ready')
        GROUP BY DATE(created_at)
        ORDER BY order_date ASC
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $weekly_performance = $stmt->fetchAll();
    
} catch (Exception $e) {
    $error_message = "Error loading dashboard data: " . $e->getMessage();
    logError($error_message);
}

$auto_refresh = true; // Enable auto-refresh for dashboard
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Sales Clerk Dashboard</h1>
        <p class="text-muted">Welcome back, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</p>
    </div>
    <div class="text-end">
        <div class="current-date text-muted small"></div>
        <div class="current-time fw-bold"></div>
    </div>
</div>

<?php if (isset($error_message)): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
    </div>
<?php endif; ?>

<!-- Key Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon success me-3">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Today's Sales</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($today_stats['revenue'] ?? 0); ?></h4>
                    <small class="text-muted"><?php echo $today_stats['count'] ?? 0; ?> orders</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon warning me-3">
                    <i class="fas fa-clock"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Pending Orders</h6>
                    <h4 class="mb-0"><?php echo $pending_orders ?? 0; ?></h4>
                    <small class="text-muted">In progress</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon primary me-3">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Total Orders</h6>
                    <h4 class="mb-0"><?php echo $total_orders ?? 0; ?></h4>
                    <small class="text-muted">All time</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon info me-3">
                    <i class="fas fa-utensils"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Available Items</h6>
                    <h4 class="mb-0"><?php echo $available_items ?? 0; ?></h4>
                    <small class="text-muted">Menu items</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-bolt me-2"></i>
                    Quick Actions
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 mb-2">
                        <a href="/Restaurant_system/sales_clerk/orders/take_order.php" class="btn btn-primary w-100">
                            <i class="fas fa-plus-circle me-2"></i>
                            Take New Order
                        </a>
                    </div>
                    <div class="col-md-3 mb-2">
                        <a href="/Restaurant_system/sales_clerk/orders/view_orders.php" class="btn btn-outline-info w-100">
                            <i class="fas fa-list me-2"></i>
                            View Orders
                        </a>
                    </div>
                    <div class="col-md-3 mb-2">
                        <a href="/Restaurant_system/sales_clerk/billing/process.php" class="btn btn-outline-success w-100">
                            <i class="fas fa-receipt me-2"></i>
                            Generate Bill
                        </a>
                    </div>
                    <div class="col-md-3 mb-2">
                        <a href="/Restaurant_system/common/menu_card.php" class="btn btn-outline-secondary w-100">
                            <i class="fas fa-print me-2"></i>
                            Print Menu
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Main Content Row -->
<div class="row">
    <!-- Recent Orders -->
    <div class="col-lg-6 mb-3">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="fas fa-history me-2"></i>
                    My Recent Orders
                </h5>
                <a href="/Restaurant_system/sales_clerk/orders/view_orders.php" class="btn btn-sm btn-outline-primary">
                    View All
                </a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Order #</th>
                                <th>Customer</th>
                                <th>Amount</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_orders)): ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted py-3">
                                        No orders found. <a href="/Restaurant_system/sales_clerk/orders/take_order.php">Take your first order!</a>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($recent_orders as $order): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($order['order_number']); ?></strong>
                                            <br>
                                            <small class="text-muted"><?php echo formatDisplayDateTime($order['created_at']); ?></small>
                                        </td>
                                        <td><?php echo htmlspecialchars($order['customer_name'] ?: 'Walk-in'); ?></td>
                                        <td><?php echo formatCurrency($order['total_amount']); ?></td>
                                        <td>
                                            <?php
                                            $status_class = [
                                                'pending' => 'warning',
                                                'preparing' => 'info',
                                                'ready' => 'primary',
                                                'served' => 'success',
                                                'cancelled' => 'danger'
                                            ];
                                            ?>
                                            <span class="badge bg-<?php echo $status_class[$order['status']] ?? 'secondary'; ?>">
                                                <?php echo ucfirst($order['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Popular Menu Items -->
    <div class="col-lg-6 mb-3">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-star me-2"></i>
                    Popular Menu Items
                </h5>
            </div>
            <div class="card-body">
                <?php if (empty($popular_items)): ?>
                    <p class="text-center text-muted py-3 mb-0">No menu items available</p>
                <?php else: ?>
                    <div class="row">
                        <?php foreach ($popular_items as $item): ?>
                            <div class="col-md-6 mb-3">
                                <div class="card border-0 bg-light">
                                    <div class="card-body p-3">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <h6 class="mb-0"><?php echo htmlspecialchars($item['item_name']); ?></h6>
                                            <span class="badge bg-primary"><?php echo htmlspecialchars($item['item_code']); ?></span>
                                        </div>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <small class="text-muted"><?php echo htmlspecialchars($item['category']); ?></small>
                                            <strong class="text-success"><?php echo formatCurrency($item['price']); ?></strong>
                                        </div>
                                        <?php if ($item['order_count'] > 0): ?>
                                            <small class="text-muted">
                                                <i class="fas fa-fire text-warning"></i>
                                                <?php echo $item['order_count']; ?> orders this week
                                            </small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Performance Chart -->
<!-- <div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-chart-bar me-2"></i>
                    My Performance This Week
                </h5>
            </div>
            <div class="card-body">
                <?php if (empty($weekly_performance)): ?>
                    <div class="text-center text-muted py-5">
                        <i class="fas fa-chart-bar fa-3x mb-3 opacity-50"></i>
                        <p class="mb-0">No sales data available for this week</p>
                        <small>Start taking orders to see your performance!</small>
                    </div>
                <?php else: ?>
                    <canvas id="performanceChart" height="100"></canvas> -->
                    
                    <!-- Summary Stats -->
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-chart-bar me-2"></i>
                                My Performance This Week
                        </h5>
                    </div>

                    <div class="row mt-4">
                        <?php
                        $week_total_orders = array_sum(array_column($weekly_performance, 'orders'));
                        $week_total_revenue = array_sum(array_column($weekly_performance, 'revenue'));
                        $avg_order_value = $week_total_orders > 0 ? $week_total_revenue / $week_total_orders : 0;
                        ?>
                        <div class="col-md-4 text-center">
                            <h4 class="text-primary"><?php echo $week_total_orders; ?></h4>
                            <small class="text-muted">Total Orders This Week</small>
                        </div>
                        <div class="col-md-4 text-center">
                            <h4 class="text-success"><?php echo formatCurrency($week_total_revenue); ?></h4>
                            <small class="text-muted">Total Revenue This Week</small>
                        </div>
                        <div class="col-md-4 text-center">
                            <h4 class="text-info"><?php echo formatCurrency($avg_order_value); ?></h4>
                            <small class="text-muted">Average Order Value</small>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php
$additional_js = "
<script>
// Performance Chart
" . (!empty($weekly_performance) ? "
const performanceCtx = document.getElementById('performanceChart').getContext('2d');
const performanceChart = new Chart(performanceCtx, {
    type: 'bar',
    data: {
        labels: [" . implode(',', array_map(function($item) { return "'" . date('M d', strtotime($item['order_date'])) . "'"; }, $weekly_performance)) . "],
        datasets: [{
            label: 'Orders',
            data: [" . implode(',', array_column($weekly_performance, 'orders')) . "],
            backgroundColor: 'rgba(102, 126, 234, 0.8)',
            borderColor: '#667eea',
            borderWidth: 1,
            yAxisID: 'y'
        }, {
            label: 'Revenue',
            data: [" . implode(',', array_column($weekly_performance, 'revenue')) . "],
            type: 'line',
            borderColor: '#28a745',
            backgroundColor: 'rgba(40, 167, 69, 0.1)',
            borderWidth: 3,
            fill: false,
            yAxisID: 'y1'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
            mode: 'index',
            intersect: false,
        },
        scales: {
            y: {
                type: 'linear',
                display: true,
                position: 'left',
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Orders'
                }
            },
            y1: {
                type: 'linear',
                display: true,
                position: 'right',
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Revenue (KES)'
                },
                grid: {
                    drawOnChartArea: false,
                },
                ticks: {
                    callback: function(value) {
                        return 'KES ' + value.toLocaleString();
                    }
                }
            }
        },
        plugins: {
            tooltip: {
                callbacks: {
                    label: function(context) {
                        if (context.dataset.label === 'Revenue') {
                            return 'Revenue: KES ' + context.parsed.y.toLocaleString();
                        }
                        return context.dataset.label + ': ' + context.parsed.y;
                    }
                }
            }
        }
    }
});
" : "") . "
</script>
";

require_once '../common/footer.php';
?>