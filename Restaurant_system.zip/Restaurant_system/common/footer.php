</main>
        </div>
    </div>
    
    <!-- Footer -->
    <footer class="bg-light text-center text-muted py-3 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-md-start">
                    <small>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. All rights reserved.</small>
                </div>
                <!-- <div class="col-md-6 text-md-end">
                    <small>
                        Version <?php echo APP_VERSION; ?> | 
                        <a href="/Restaurant_system/common/help.php" class="text-decoration-none">Help</a> | 
                        <a href="/Restaurant_system/common/support.php" class="text-decoration-none">Support</a>
                    </small>
                </div> -->
            </div>
        </div>
    </footer>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <!-- DataTables -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    
    <!-- Common JavaScript -->
    <script>
        // Initialize DataTables
        $(document).ready(function() {
            $('.data-table').DataTable({
                responsive: true,
                pageLength: <?php echo RECORDS_PER_PAGE; ?>,
                order: [[0, 'desc']],
                language: {
                    search: "Search:",
                    lengthMenu: "Show _MENU_ entries",
                    info: "Showing _START_ to _END_ of _TOTAL_ entries",
                    paginate: {
                        first: "First",
                        last: "Last",
                        next: "Next",
                        previous: "Previous"
                    }
                }
            });
        });
        
        // Auto-hide alerts after 5 seconds
        setTimeout(function() {
            $('.alert:not(.alert-permanent)').fadeOut('slow');
        }, 5000);
        
        // Confirm delete actions
        $('.delete-btn').on('click', function(e) {
            if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
                e.preventDefault();
                return false;
            }
        });
        
        // Format currency inputs
        $('.currency-input').on('input', function() {
            let value = this.value.replace(/[^\d.]/g, '');
            let parts = value.split('.');
            if (parts.length > 2) {
                value = parts[0] + '.' + parts.slice(1).join('');
            }
            if (parts[1] && parts[1].length > 2) {
                value = parts[0] + '.' + parts[1].substring(0, 2);
            }
            this.value = value;
        });
        
        // Auto-refresh page every 5 minutes for dashboard pages
        <?php if (isset($auto_refresh) && $auto_refresh): ?>
        setTimeout(function() {
            location.reload();
        }, 300000); // 5 minutes
        <?php endif; ?>
        
        // Mobile sidebar toggle
        $('.navbar-toggler').on('click', function() {
            $('#sidebar').toggleClass('show');
        });
        
        // Close mobile sidebar when clicking outside
        $(document).on('click', function(e) {
            if (!$(e.target).closest('#sidebar, .navbar-toggler').length) {
                $('#sidebar').removeClass('show');
            }
        });
        
        // Form validation
        $('.needs-validation').on('submit', function(e) {
            if (!this.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            this.classList.add('was-validated');
        });
        
        // Tooltip initialization
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
        
        // Popover initialization
        var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
        var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
            return new bootstrap.Popover(popoverTriggerEl);
        });
        
        // Print functionality
        $('.print-btn').on('click', function() {
            window.print();
        });
        
        // Export functionality
        $('.export-btn').on('click', function() {
            const format = $(this).data('format');
            const table = $(this).data('table');
            
            if (format === 'csv') {
                exportTableToCSV(table);
            } else if (format === 'pdf') {
                exportTableToPDF(table);
            }
        });
        
        // Export table to CSV
        function exportTableToCSV(tableId) {
            const table = document.getElementById(tableId);
            if (!table) return;
            
            let csv = [];
            const rows = table.querySelectorAll('tr');
            
            for (let i = 0; i < rows.length; i++) {
                const row = [];
                const cols = rows[i].querySelectorAll('td, th');
                
                for (let j = 0; j < cols.length; j++) {
                    row.push('"' + cols[j].innerText.replace(/"/g, '""') + '"');
                }
                
                csv.push(row.join(','));
            }
            
            downloadCSV(csv.join('\n'), 'export.csv');
        }
        
        // Download CSV file
        function downloadCSV(csv, filename) {
            const csvFile = new Blob([csv], { type: 'text/csv' });
            const downloadLink = document.createElement('a');
            
            downloadLink.download = filename;
            downloadLink.href = window.URL.createObjectURL(csvFile);
            downloadLink.style.display = 'none';
            
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
        }
        
        // Real-time clock
        function updateClock() {
            const now = new Date();
            const timeString = now.toLocaleTimeString();
            const dateString = now.toLocaleDateString();
            
            $('.current-time').text(timeString);
            $('.current-date').text(dateString);
        }
        
        // Update clock every second
        setInterval(updateClock, 1000);
        updateClock(); // Initial call
        
        // Session timeout warning
        let sessionTimeout = <?php echo SESSION_TIMEOUT; ?> * 1000; // Convert to milliseconds
        let warningTime = sessionTimeout - (5 * 60 * 1000); // 5 minutes before timeout
        
        setTimeout(function() {
            if (confirm('Your session will expire in 5 minutes. Do you want to extend your session?')) {
                // Make an AJAX call to extend session
                $.post('/Restaurant_system/auth/extend_session.php', function(data) {
                    if (data.success) {
                        console.log('Session extended');
                    }
                });
            }
        }, warningTime);
        
        // AJAX error handling
        $(document).ajaxError(function(event, xhr, settings, thrownError) {
            if (xhr.status === 401) {
                alert('Your session has expired. Please login again.');
                window.location.href = '/Restaurant_system/index.php';
            } else if (xhr.status === 403) {
                alert('Access denied. You do not have permission to perform this action.');
            } else if (xhr.status >= 500) {
                alert('Server error occurred. Please try again later.');
            }
        });
        
        // Loading overlay functions
        function showLoading() {
            $('body').append('<div id="loading-overlay" class="position-fixed top-0 start-0 w-100 h-100 d-flex justify-content-center align-items-center" style="background: rgba(0,0,0,0.5); z-index: 9999;"><div class="spinner-border text-light" role="status"><span class="visually-hidden">Loading...</span></div></div>');
        }
        
        function hideLoading() {
            $('#loading-overlay').remove();
        }
        
        // Show loading on form submissions
        $('form').on('submit', function() {
            showLoading();
        });
        
        // Hide loading when page loads
        $(window).on('load', function() {
            hideLoading();
        });
    </script>
    
    <?php if (isset($additional_js)): ?>
        <?php echo $additional_js; ?>
    <?php endif; ?>
</body>
</html>