<?php
// Public Menu Card - No login required
require_once '../dbconnect.php';

try {
    $pdo = getPDO();
    
    // Get restaurant settings
    $stmt = $pdo->prepare("
        SELECT setting_key, setting_value 
        FROM system_settings 
        WHERE setting_key IN ('restaurant_name', 'restaurant_tagline', 'restaurant_address', 
                              'restaurant_phone', 'restaurant_email', 'menu_footer_text')
    ");
    $stmt->execute();
    $settings_data = $stmt->fetchAll();
    
    $restaurant_settings = [
        'restaurant_name' => 'Fork & Spoon',
        'restaurant_tagline' => 'Delicious Food Awaits',
        'restaurant_address' => 'Haile Selassie Avenue, Nairobi, Kenya',
        'restaurant_phone' => '+254 790 070 069',
        'restaurant_email' => 'forkspoon@gmail.com',
        'menu_footer_text' => 'Thank you for choosing us!'
    ];
    
    foreach ($settings_data as $setting) {
        $restaurant_settings[$setting['setting_key']] = $setting['setting_value'];
    }
    
    // Get menu items grouped by category
    $stmt = $pdo->prepare("
        SELECT mi.*
        FROM menu_items mi
        WHERE mi.status = 'available'
        ORDER BY mi.category, mi.item_name ASC
    ");
    $stmt->execute();
    $menu_items = $stmt->fetchAll();
    
    // Group items by category
    $menu_by_category = [];
    foreach ($menu_items as $item) {
        $category = $item['category'] ?: 'Main Course';
        if (!isset($menu_by_category[$category])) {
            $menu_by_category[$category] = [];
        }
        $menu_by_category[$category][] = $item;
    }
    
} catch (Exception $e) {
    $menu_by_category = [];
    $restaurant_settings = [
        'restaurant_name' => 'Fork & Spoon',
        'restaurant_tagline' => 'Delicious Food Awaits',
        'restaurant_address' => 'Haile Selassie Avenue, Nairobi, Kenya',
        'restaurant_phone' => '+254 790 070 069',
        'restaurant_email' => 'forkspoon@gmail.com',
        'menu_footer_text' => 'Thank you for visiting!'
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($restaurant_settings['restaurant_name']); ?> - Menu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Georgia', serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px 0;
        }
        
        .menu-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
            max-width: 900px;
            margin: 0 auto;
        }
        
        .menu-header {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            text-align: center;
            padding: 40px 30px;
        }
        
        .menu-header h1 {
            font-size: 3rem;
            margin-bottom: 15px;
            font-weight: bold;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        .menu-header .tagline {
            font-size: 1.3rem;
            font-style: italic;
            opacity: 0.9;
            margin-bottom: 20px;
        }
        
        .contact-info {
            font-size: 0.95rem;
            opacity: 0.8;
        }
        
        .contact-info i {
            margin-right: 8px;
            width: 20px;
            text-align: center;
        }
        
        .menu-content {
            padding: 40px 30px;
        }
        
        .category-section {
            margin-bottom: 40px;
        }
        
        .category-title {
            font-size: 2rem;
            color: #2c3e50;
            border-bottom: 3px solid #e74c3c;
            padding-bottom: 10px;
            margin-bottom: 25px;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: bold;
        }
        
        .menu-item {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 20px;
            padding: 15px 0;
            border-bottom: 1px dotted #bdc3c7;
        }
        
        .menu-item:last-child {
            border-bottom: none;
        }
        
        .item-info {
            flex: 1;
            padding-right: 20px;
        }
        
        .item-name {
            font-size: 1.3rem;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 5px;
        }
        
        .item-description {
            color: #7f8c8d;
            font-style: italic;
            line-height: 1.4;
            font-size: 0.95rem;
        }
        
        .item-price {
            font-size: 1.4rem;
            font-weight: bold;
            color: #e74c3c;
            white-space: nowrap;
            min-width: 100px;
            text-align: right;
        }
        
        .menu-footer {
            background: #ecf0f1;
            text-align: center;
            padding: 30px;
            font-style: italic;
            color: #7f8c8d;
            border-top: 1px solid #bdc3c7;
        }
        
        .no-items {
            text-align: center;
            color: #7f8c8d;
            font-style: italic;
            padding: 40px;
        }
        
        @media (max-width: 768px) {
            .menu-header h1 {
                font-size: 2.2rem;
            }
            
            .menu-header .tagline {
                font-size: 1.1rem;
            }
            
            .menu-content {
                padding: 30px 20px;
            }
            
            .menu-item {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .item-info {
                padding-right: 0;
                margin-bottom: 10px;
            }
            
            .item-price {
                text-align: left;
                min-width: auto;
            }
        }
        
        @media print {
            body {
                background: white !important;
                padding: 0 !important;
            }
            
            .menu-container {
                box-shadow: none !important;
                border-radius: 0 !important;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="menu-container">
            <!-- Menu Header -->
            <div class="menu-header">
                <h1><?php echo htmlspecialchars($restaurant_settings['restaurant_name']); ?></h1>
                <?php if ($restaurant_settings['restaurant_tagline']): ?>
                    <div class="tagline"><?php echo htmlspecialchars($restaurant_settings['restaurant_tagline']); ?></div>
                <?php endif; ?>
                
                <div class="contact-info">
                    <?php if ($restaurant_settings['restaurant_address']): ?>
                        <div class="mb-2">
                            <i class="fas fa-map-marker-alt"></i>
                            <?php echo htmlspecialchars($restaurant_settings['restaurant_address']); ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="row">
                        <?php if ($restaurant_settings['restaurant_phone']): ?>
                            <div class="col-md-6">
                                <i class="fas fa-phone"></i>
                                <?php echo htmlspecialchars($restaurant_settings['restaurant_phone']); ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($restaurant_settings['restaurant_email']): ?>
                            <div class="col-md-6">
                                <i class="fas fa-envelope"></i>
                                <?php echo htmlspecialchars($restaurant_settings['restaurant_email']); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Menu Content -->
            <div class="menu-content">
                <?php if (empty($menu_by_category)): ?>
                    <div class="no-items">
                        <i class="fas fa-utensils fa-3x mb-3 text-muted"></i>
                        <h3>Menu Coming Soon</h3>
                        <p>We're preparing something delicious for you!</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($menu_by_category as $category => $items): ?>
                        <div class="category-section">
                            <h2 class="category-title">
                                <i class="fas fa-utensils me-3"></i>
                                <?php echo htmlspecialchars($category); ?>
                            </h2>
                            
                            <?php foreach ($items as $item): ?>
                                <div class="menu-item">
                                    <?php if (!empty($item['image_path'])): ?>
                                        <div class="item-image mb-2">
                                            <img src="../<?php echo htmlspecialchars($item['image_path']); ?>"
                                                 alt="<?php echo htmlspecialchars($item['item_name']); ?>"
                                                 class="img-fluid rounded"
                                                 style="max-height: 150px; object-fit: cover;">
                                        </div>
                                    <?php endif; ?>
                                    <div class="item-info">
                                        <div class="item-name"><?php echo htmlspecialchars($item['item_name']); ?></div>
                                        <?php if (!empty($item['description'])): ?>
                                            <div class="item-description"><?php echo htmlspecialchars($item['description']); ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="item-price">
                                        KES <?php echo number_format($item['price'], 2); ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <!-- Menu Footer -->
            <?php if ($restaurant_settings['menu_footer_text']): ?>
                <div class="menu-footer">
                    <i class="fas fa-heart text-danger me-2"></i>
                    <?php echo htmlspecialchars($restaurant_settings['menu_footer_text']); ?>
                    <i class="fas fa-heart text-danger ms-2"></i>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Print Button (hidden on print) -->
    <div class="text-center mt-4 d-print-none">
        <button class="btn btn-primary btn-lg" onclick="window.print()">
            <i class="fas fa-print me-2"></i>Print Menu
        </button>
        <a href="../index.php" class="btn btn-outline-light btn-lg ms-3">
            <i class="fas fa-home me-2"></i>Back to System
        </a>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>