<?php
// Dynamic sidebar based on user role
$current_page = basename($_SERVER['PHP_SELF']);
$current_dir = basename(dirname($_SERVER['PHP_SELF']));

// Define menu items for each role
$menu_items = [];

switch ($_SESSION['role']) {
    case 'business_owner':
        $menu_items = [
            [
                'title' => 'Dashboard',
                'icon' => 'fas fa-tachometer-alt',
                'url' => '/Restaurant_system/business_owner/',
                'active' => $current_page === 'index.php' && $current_dir === 'business_owner'
            ],
            [
                'title' => 'User Management',
                'icon' => 'fas fa-users',
                'url' => '/Restaurant_system/business_owner/users/manage.php',
                'active' => strpos($_SERVER['REQUEST_URI'], '/business_owner/users/') !== false
            ],
            [
                'title' => 'Financial Management',
                'icon' => 'fas fa-money-bill-wave',
                'url' => '/Restaurant_system/business_owner/financial/funds.php',
                'active' => strpos($_SERVER['REQUEST_URI'], '/business_owner/financial/') !== false
            ],
            // [
            //     'title' => 'Reports & Analytics',
            //     'icon' => 'fas fa-chart-bar',
            //     'url' => '/Restaurant_system/business_owner/reports/sales.php',
            //     'active' => strpos($_SERVER['REQUEST_URI'], '/business_owner/reports/') !== false
            // ],
            // [
            //     'title' => 'System Settings',
            //     'icon' => 'fas fa-cog',
            //     'url' => '/Restaurant_system/business_owner/settings.php',
            //     'active' => $current_page === 'settings.php'
            // ]
        ];
        break;
        
    case 'manager':
        $menu_items = [
            [
                'title' => 'Dashboard',
                'icon' => 'fas fa-tachometer-alt',
                'url' => '/Restaurant_system/manager/',
                'active' => $current_page === 'index.php' && $current_dir === 'manager'
            ],
            [
                'title' => 'Sales Clerks',
                'icon' => 'fas fa-user-friends',
                'url' => '/Restaurant_system/manager/users/clerks.php',
                'active' => strpos($_SERVER['REQUEST_URI'], '/manager/users/') !== false
            ],
            [
                'title' => 'Menu Management',
                'icon' => 'fas fa-utensils',
                'url' => '/Restaurant_system/manager/menu/manage.php',
                'active' => strpos($_SERVER['REQUEST_URI'], '/manager/menu/') !== false
            ],
            [
                'title' => 'Inventory',
                'icon' => 'fas fa-boxes',
                'url' => '/Restaurant_system/manager/inventory/stock.php',
                'active' => strpos($_SERVER['REQUEST_URI'], '/manager/inventory/') !== false
            ],
            [
                'title' => 'Purchase Orders',
                'icon' => 'fas fa-shopping-cart',
                'url' => '/Restaurant_system/manager/inventory/purchase_orders.php',
                'active' => strpos($_SERVER['REQUEST_URI'], '/manager/inventory/purchase_orders') !== false
            ],
            [
                'title' => 'Invoices',
                'icon' => 'fas fa-file-invoice',
                'url' => '/Restaurant_system/manager/invoices/process.php',
                'active' => strpos($_SERVER['REQUEST_URI'], '/manager/invoices/') !== false
            ],
            [
                'title' => 'Reports',
                'icon' => 'fas fa-chart-line',
                'url' => '/Restaurant_system/manager/reports/monthly.php',
                'active' => strpos($_SERVER['REQUEST_URI'], '/manager/reports/') !== false
            ]
        ];
        break;
        
    case 'sales_clerk':
        $menu_items = [
            [
                'title' => 'Dashboard',
                'icon' => 'fas fa-tachometer-alt',
                'url' => '/Restaurant_system/sales_clerk/',
                'active' => $current_page === 'index.php' && $current_dir === 'sales_clerk'
            ],
            [
                'title' => 'Take Order',
                'icon' => 'fas fa-plus-circle',
                'url' => '/Restaurant_system/sales_clerk/orders/take_order.php',
                'active' => $current_page === 'take_order.php'
            ],
            [
                'title' => 'View Orders',
                'icon' => 'fas fa-list',
                'url' => '/Restaurant_system/sales_clerk/orders/view_orders.php',
                'active' => $current_page === 'view_orders.php'
            ],
            [
                'title' => 'Billing',
                'icon' => 'fas fa-receipt',
                'url' => '/Restaurant_system/sales_clerk/orders/billing.php',
                'active' => $current_page === 'billing.php'
            ],
            [
                'title' => 'Reports',
                'icon' => 'fas fa-chart-pie',
                'url' => '/Restaurant_system/sales_clerk/reports/daily.php',
                'active' => strpos($_SERVER['REQUEST_URI'], '/sales_clerk/reports/') !== false
            ]
        ];
        break;
}
?>

<div class="nav flex-column">
    <?php foreach ($menu_items as $item): ?>
        <a class="nav-link <?php echo $item['active'] ? 'active' : ''; ?>" 
           href="<?php echo $item['url']; ?>">
            <i class="<?php echo $item['icon']; ?>"></i>
            <?php echo $item['title']; ?>
        </a>
    <?php endforeach; ?>
    
    <!-- Common menu items for all roles -->
    <hr class="my-3">
    
    <a class="nav-link" href="/Restaurant_system/common/menu_card.php">
        <i class="fas fa-print"></i>
        Print Menu
    </a>
    
    <!-- <?php if ($_SESSION['role'] !== 'sales_clerk'): ?>
        <a class="nav-link" href="/Restaurant_system/common/activity_log.php">
            <i class="fas fa-history"></i>
            Activity Log
        </a>
    <?php endif; ?> -->
    
    <!-- <a class="nav-link" href="/Restaurant_system/common/help.php">
        <i class="fas fa-question-circle"></i>
        Help & Support
    </a> -->
</div>

<!-- Quick Stats Section (for non-sales clerk roles) -->
<?php if ($_SESSION['role'] !== 'sales_clerk'): ?>
    <div class="mt-4 p-3 bg-light rounded">
        <h6 class="text-muted mb-3">
            <i class="fas fa-info-circle me-2"></i>Quick Stats
        </h6>
        
        <?php
        try {
            $pdo = getPDO();
            
            // Get today's orders count
            $stmt = $pdo->prepare("
                SELECT COUNT(*) as count 
                FROM orders 
                WHERE DATE(created_at) = CURDATE() 
                AND status IN ('pending', 'preparing', 'ready', 'served')
            ");
            $stmt->execute();
            $today_orders = $stmt->fetch()['count'];
            
            // Get low stock count
            $stmt = $pdo->prepare("
                SELECT COUNT(*) as count 
                FROM ingredients 
                WHERE current_stock <= threshold_quantity
            ");
            $stmt->execute();
            $low_stock_count = $stmt->fetch()['count'];
            
            // Get available funds (for business owner and manager)
            if ($_SESSION['role'] !== 'sales_clerk') {
                $available_funds = getAvailableFunds();
            }
        } catch (Exception $e) {
            $today_orders = 0;
            $low_stock_count = 0;
            $available_funds = 0;
        }
        ?>
        
        <div class="d-flex justify-content-between align-items-center mb-2">
            <small class="text-muted">Today's Orders</small>
            <span class="badge bg-primary"><?php echo $today_orders; ?></span>
        </div>
        
        <div class="d-flex justify-content-between align-items-center mb-2">
            <small class="text-muted">Low Stock Items</small>
            <span class="badge <?php echo $low_stock_count > 0 ? 'bg-warning' : 'bg-success'; ?>">
                <?php echo $low_stock_count; ?>
            </span>
        </div>
        
        <?php if ($_SESSION['role'] !== 'sales_clerk'): ?>
            <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">Available Funds</small>
                <small class="fw-bold text-success">
                    <?php echo formatCurrency($available_funds); ?>
                </small>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>

<!-- System Status -->
<div class="mt-3 p-3 bg-light rounded">
    <h6 class="text-muted mb-3">
        <i class="fas fa-server me-2"></i>System Status
    </h6>
    
    <div class="d-flex justify-content-between align-items-center mb-2">
        <small class="text-muted">Database</small>
        <span class="badge bg-success">
            <i class="fas fa-check-circle"></i> Online
        </span>
    </div>
    
    <div class="d-flex justify-content-between align-items-center mb-2">
        <small class="text-muted">Last Backup</small>
        <small class="text-muted"><?php echo date('M d, H:i'); ?></small>
    </div>
    
    <div class="d-flex justify-content-between align-items-center">
        <small class="text-muted">Version</small>
        <small class="text-muted"><?php echo APP_VERSION; ?></small>
    </div>
</div>