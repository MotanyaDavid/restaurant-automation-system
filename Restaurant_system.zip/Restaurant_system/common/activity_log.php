<?php
// Activity Log
$page_title = 'Activity Log';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/' . $_SESSION['role'] . '/'],
    ['title' => 'Activity Log', 'url' => '']
];

require_once '../common/header.php';
requireRole(['business_owner', 'manager']);

// Get filter parameters
$date_from = $_GET['date_from'] ?? date('Y-m-d', strtotime('-7 days'));
$date_to = $_GET['date_to'] ?? date('Y-m-d');
$user_filter = $_GET['user'] ?? '';
$action_filter = $_GET['action'] ?? '';

try {
    $pdo = getPDO();
    
    // Build query with filters
    $where_conditions = ["DATE(al.created_at) BETWEEN ? AND ?"];
    $params = [$date_from, $date_to];
    
    if (!empty($user_filter)) {
        $where_conditions[] = "al.user_id = ?";
        $params[] = $user_filter;
    }
    
    if (!empty($action_filter)) {
        $where_conditions[] = "al.action LIKE ?";
        $params[] = '%' . $action_filter . '%';
    }
    
    $where_clause = 'WHERE ' . implode(' AND ', $where_conditions);
    
    // Get activity logs with filters
    $stmt = $pdo->prepare("
        SELECT al.*, u.full_name, u.role
        FROM activity_logs al
        JOIN users u ON al.user_id = u.user_id
        $where_clause
        ORDER BY al.created_at DESC
        LIMIT 500
    ");
    $stmt->execute($params);
    $activities = $stmt->fetchAll();
    
    // Get summary statistics
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_activities,
            COUNT(DISTINCT al.user_id) as active_users,
            COUNT(DISTINCT DATE(al.created_at)) as active_days
        FROM activity_logs al
        $where_clause
    ");
    $stmt->execute($params);
    $summary = $stmt->fetch();
    
    // Get activity breakdown by action
    $stmt = $pdo->prepare("
        SELECT 
            al.action,
            COUNT(*) as count
        FROM activity_logs al
        $where_clause
        GROUP BY al.action
        ORDER BY count DESC
        LIMIT 10
    ");
    $stmt->execute($params);
    $action_breakdown = $stmt->fetchAll();
    
    // Get users for filter
    $stmt = $pdo->prepare("
        SELECT user_id, full_name, role
        FROM users 
        WHERE status = 'active'
        ORDER BY full_name
    ");
    $stmt->execute();
    $users = $stmt->fetchAll();
    
} catch (Exception $e) {
    $error_message = "Error loading activity log: " . $e->getMessage();
    $activities = [];
    $summary = [];
    $action_breakdown = [];
    $users = [];
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Activity Log</h1>
        <p class="text-muted">System activity monitoring and audit trail</p>
    </div>
    <div>
        <button type="button" class="btn btn-success" onclick="exportLog()">
            <i class="fas fa-download me-2"></i>Export Log
        </button>
    </div>
</div>

<?php if (isset($error_message)): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
    </div>
<?php endif; ?>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-filter me-2"></i>Activity Filters
        </h5>
    </div>
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-3">
                <label for="date_from" class="form-label">From Date</label>
                <input type="date" class="form-control" id="date_from" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>">
            </div>
            
            <div class="col-md-3">
                <label for="date_to" class="form-label">To Date</label>
                <input type="date" class="form-control" id="date_to" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>">
            </div>
            
            <div class="col-md-3">
                <label for="user" class="form-label">User</label>
                <select class="form-select" id="user" name="user">
                    <option value="">All Users</option>
                    <?php foreach ($users as $user): ?>
                        <option value="<?php echo $user['user_id']; ?>" <?php echo $user_filter == $user['user_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($user['full_name']); ?> (<?php echo getRoleDisplayName($user['role']); ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-3">
                <label for="action" class="form-label">Action</label>
                <input type="text" class="form-control" id="action" name="action" 
                       placeholder="Search actions..." value="<?php echo htmlspecialchars($action_filter); ?>">
            </div>
            
            <div class="col-12">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search me-2"></i>Filter Activities
                </button>
                <a href="/Restaurant_system/common/activity_log.php" class="btn btn-outline-secondary">
                    <i class="fas fa-times me-2"></i>Clear Filters
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Summary Statistics -->
<div class="row mb-4">
    <div class="col-md-4 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon primary me-3">
                    <i class="fas fa-list"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Total Activities</h6>
                    <h4 class="mb-0"><?php echo $summary['total_activities'] ?? 0; ?></h4>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-4 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon success me-3">
                    <i class="fas fa-users"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Active Users</h6>
                    <h4 class="mb-0"><?php echo $summary['active_users'] ?? 0; ?></h4>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-4 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon info me-3">
                    <i class="fas fa-calendar"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Active Days</h6>
                    <h4 class="mb-0"><?php echo $summary['active_days'] ?? 0; ?></h4>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Activity Breakdown and Log -->
<div class="row">
    <!-- Activity Breakdown -->
    <div class="col-lg-4 mb-3">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-chart-pie me-2"></i>Activity Breakdown
                </h5>
            </div>
            <div class="card-body">
                <?php if (!empty($action_breakdown)): ?>
                    <?php foreach ($action_breakdown as $action): ?>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-truncate"><?php echo htmlspecialchars($action['action']); ?></span>
                            <span class="badge bg-primary"><?php echo $action['count']; ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-center text-muted py-3 mb-0">No activity data available</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Activity Log -->
    <div class="col-lg-8 mb-3">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-history me-2"></i>
                    Activity Timeline (<?php echo count($activities); ?> activities)
                </h5>
            </div>
            <div class="card-body">
                <?php if (!empty($activities)): ?>
                    <div class="activity-timeline" style="max-height: 600px; overflow-y: auto;">
                        <?php foreach ($activities as $activity): ?>
                            <div class="activity-item d-flex mb-3 p-3 border rounded">
                                <div class="activity-icon me-3">
                                    <?php
                                    $icon_class = 'fas fa-circle text-primary';
                                    if (strpos($activity['action'], 'Login') !== false) {
                                        $icon_class = 'fas fa-sign-in-alt text-success';
                                    } elseif (strpos($activity['action'], 'Logout') !== false) {
                                        $icon_class = 'fas fa-sign-out-alt text-warning';
                                    } elseif (strpos($activity['action'], 'Created') !== false || strpos($activity['action'], 'Added') !== false) {
                                        $icon_class = 'fas fa-plus-circle text-success';
                                    } elseif (strpos($activity['action'], 'Updated') !== false || strpos($activity['action'], 'Modified') !== false) {
                                        $icon_class = 'fas fa-edit text-info';
                                    } elseif (strpos($activity['action'], 'Deleted') !== false || strpos($activity['action'], 'Removed') !== false) {
                                        $icon_class = 'fas fa-trash text-danger';
                                    } elseif (strpos($activity['action'], 'Order') !== false) {
                                        $icon_class = 'fas fa-shopping-cart text-primary';
                                    } elseif (strpos($activity['action'], 'Payment') !== false || strpos($activity['action'], 'Bill') !== false) {
                                        $icon_class = 'fas fa-money-bill text-success';
                                    }
                                    ?>
                                    <i class="<?php echo $icon_class; ?>"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <div class="activity-content">
                                        <div class="d-flex justify-content-between align-items-start">
                                            <div>
                                                <strong><?php echo htmlspecialchars($activity['full_name']); ?></strong>
                                                <span class="text-muted"><?php echo htmlspecialchars($activity['action']); ?></span>
                                                <?php if ($activity['table_name']): ?>
                                                    <span class="badge bg-secondary ms-2"><?php echo htmlspecialchars($activity['table_name']); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <small class="text-muted"><?php echo formatDisplayDateTime($activity['created_at']); ?></small>
                                        </div>
                                        
                                        <?php if ($activity['details']): ?>
                                            <div class="mt-2">
                                                <small class="text-muted">
                                                    <?php
                                                    $details = json_decode($activity['details'], true);
                                                    if (is_array($details)) {
                                                        foreach ($details as $key => $value) {
                                                            if (is_scalar($value)) {
                                                                echo "<strong>" . htmlspecialchars($key) . ":</strong> " . htmlspecialchars($value) . " ";
                                                            }
                                                        }
                                                    } else {
                                                        echo htmlspecialchars($activity['details']);
                                                    }
                                                    ?>
                                                </small>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <div class="mt-1">
                                            <small class="text-muted">
                                                <?php echo getRoleDisplayName($activity['role']); ?>
                                                <?php if ($activity['record_id']): ?>
                                                    • Record ID: <?php echo $activity['record_id']; ?>
                                                <?php endif; ?>
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center text-muted py-5">
                        <i class="fas fa-history fa-3x mb-3 opacity-50"></i>
                        <p class="mb-0">No activity found for the selected criteria</p>
                        <small>Try adjusting your filters to see more activities</small>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
function exportLog() {
    const params = new URLSearchParams(window.location.search);
    params.set('export', 'csv');
    window.location.href = window.location.pathname + '?' + params.toString();
}

// Auto-refresh every 30 seconds
setInterval(function() {
    if (!document.querySelector('.modal.show')) {
        location.reload();
    }
}, 30000);
</script>

<?php require_once '../common/footer.php'; ?>