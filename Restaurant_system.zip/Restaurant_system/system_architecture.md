# Restaurant Automation System (RAS) - Architecture Plan

## System Overview
A comprehensive restaurant management system with role-based access control for Business Owner, Manager, and Sales Clerk users.

## Database Schema Design

### Core Tables

#### 1. Users Table
```sql
users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(20),
    role ENUM('business_owner', 'manager', 'sales_clerk') NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(user_id)
)
```

#### 2. Menu Items Table
```sql
menu_items (
    item_id INT PRIMARY KEY AUTO_INCREMENT,
    item_name VARCHAR(100) NOT NULL,
    item_code VARCHAR(20) UNIQUE NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    category VARCHAR(50),
    status ENUM('available', 'unavailable') DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)
```

#### 3. Ingredients Table
```sql
ingredients (
    ingredient_id INT PRIMARY KEY AUTO_INCREMENT,
    ingredient_name VARCHAR(100) NOT NULL,
    ingredient_code VARCHAR(20) UNIQUE NOT NULL,
    unit VARCHAR(20) NOT NULL,
    current_stock DECIMAL(10,2) DEFAULT 0,
    threshold_quantity DECIMAL(10,2) NOT NULL,
    unit_price DECIMAL(10,2) DEFAULT 0,
    supplier_info TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)
```

#### 4. Menu Item Ingredients (Recipe)
```sql
menu_item_ingredients (
    id INT PRIMARY KEY AUTO_INCREMENT,
    item_id INT NOT NULL,
    ingredient_id INT NOT NULL,
    quantity_required DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (item_id) REFERENCES menu_items(item_id),
    FOREIGN KEY (ingredient_id) REFERENCES ingredients(ingredient_id)
)
```

#### 5. Orders Table
```sql
orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    order_number VARCHAR(20) UNIQUE NOT NULL,
    customer_name VARCHAR(100),
    table_number VARCHAR(10),
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'preparing', 'ready', 'served', 'cancelled') DEFAULT 'pending',
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(user_id)
)
```

#### 6. Order Items Table
```sql
order_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    item_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (item_id) REFERENCES menu_items(item_id)
)
```

#### 7. Purchase Orders Table
```sql
purchase_orders (
    po_id INT PRIMARY KEY AUTO_INCREMENT,
    po_number VARCHAR(20) UNIQUE NOT NULL,
    supplier_name VARCHAR(100),
    total_amount DECIMAL(10,2) DEFAULT 0,
    status ENUM('pending', 'ordered', 'received', 'paid') DEFAULT 'pending',
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(user_id)
)
```

#### 8. Purchase Order Items Table
```sql
purchase_order_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    po_id INT NOT NULL,
    ingredient_id INT NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (po_id) REFERENCES purchase_orders(po_id),
    FOREIGN KEY (ingredient_id) REFERENCES ingredients(ingredient_id)
)
```

#### 9. Invoices Table
```sql
invoices (
    invoice_id INT PRIMARY KEY AUTO_INCREMENT,
    invoice_number VARCHAR(20) UNIQUE NOT NULL,
    po_id INT,
    supplier_name VARCHAR(100) NOT NULL,
    invoice_date DATE NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'paid') DEFAULT 'pending',
    payment_method VARCHAR(50),
    cheque_number VARCHAR(20),
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (po_id) REFERENCES purchase_orders(po_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id)
)
```

#### 10. Financial Settings Table
```sql
financial_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    available_funds DECIMAL(15,2) DEFAULT 0,
    updated_by INT NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (updated_by) REFERENCES users(user_id)
)
```

#### 11. Stock Movements Table
```sql
stock_movements (
    id INT PRIMARY KEY AUTO_INCREMENT,
    ingredient_id INT NOT NULL,
    movement_type ENUM('in', 'out') NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    reference_type ENUM('purchase', 'usage', 'adjustment') NOT NULL,
    reference_id INT,
    notes TEXT,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ingredient_id) REFERENCES ingredients(ingredient_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id)
)
```

## User Role Permissions

### Business Owner
- **User Management**: Add, update, delete managers and sales clerks
- **Financial Management**: Set available funds, view budget reports, approve payments
- **System Overview**: Access to all reports and system data
- **Settings**: Configure system parameters

### Manager
- **User Management**: Add, update, delete sales clerks only
- **Menu Management**: Add, edit, delete menu items and prices
- **Purchase Orders**: Create purchase orders, manage suppliers
- **Invoice Processing**: Enter invoice data, generate cheques (if funds available)
- **Reports**: Monthly sales receipts and expenses data
- **Inventory**: Monitor stock levels and thresholds

### Sales Clerk
- **Order Processing**: Take customer orders, generate bills
- **Order Management**: View order list, update order status
- **Reports**: Basic sales reports and order summaries
- **Menu**: View current menu and prices

## System Features

### Authentication System
- Unified login page for all user types
- Session management with role-based redirects
- Password encryption and security measures

### Inventory Management
- Automatic threshold calculation based on 3-day average consumption
- Minimum 2-day stock maintenance
- Real-time stock updates when orders are processed

### Billing System
- Automatic bill generation for food sales
- Item code-based order entry
- Real-time price calculation

### Purchase Order System
- Daily automatic generation when stock falls below threshold
- Fund validation before order processing
- Supplier management

### Reporting System
- Monthly sales and expense reports
- Budget analysis and cash balance tracking
- Statistical reports on item sales

### Menu Card System
- Printable menu cards with current prices
- Category-based organization
- Real-time price updates

## File Structure
```
Restaurant_system/
├── index.php (Main login page)
├── config/
│   ├── dbconnect.php
│   └── session.php
├── auth/
│   ├── login.php
│   ├── logout.php
│   └── authenticate.php
├── business_owner/
│   ├── dashboard.php
│   ├── user_management.php
│   ├── financial_management.php
│   └── reports.php
├── manager/
│   ├── dashboard.php
│   ├── user_management.php
│   ├── menu_management.php
│   ├── purchase_orders.php
│   ├── invoices.php
│   └── reports.php
├── sales_clerk/
│   ├── dashboard.php
│   ├── orders.php
│   ├── billing.php
│   └── reports.php
├── common/
│   ├── header.php
│   ├── footer.php
│   ├── sidebar.php
│   └── functions.php
├── assets/
│   ├── css/
│   ├── js/
│   └── images/
└── database/
    └── restaurant_system.sql
```

## Security Considerations
- Password hashing using PHP's password_hash()
- SQL injection prevention using prepared statements
- Session security and timeout management
- Input validation and sanitization
- Role-based access control enforcement

## Technology Stack
- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap
- **Backend**: PHP 7.4+
- **Database**: MySQL 5.7+
- **Server**: Apache (XAMPP)
- **Additional**: jQuery for enhanced UI interactions