<?php
// Manager - Sales Clerks Management
$page_title = 'Sales Clerks Management';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/manager/'],
    ['title' => 'Sales Clerks', 'url' => '']
];

require_once '../../common/header.php';
requireRole('manager');

// Handle form submissions
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!validateCSRFToken($csrf_token)) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        try {
            $pdo = getPDO();
            
            switch ($action) {
                case 'add_clerk':
                    $full_name = sanitizeInput($_POST['full_name']);
                    $username = sanitizeInput($_POST['username']);
                    $email = sanitizeInput($_POST['email']);
                    $phone = sanitizeInput($_POST['phone']);
                    $password = $_POST['password'];
                    
                    if (empty($full_name) || empty($username) || empty($password)) {
                        throw new Exception('Please fill in all required fields.');
                    }
                    
                    if (strlen($password) < 6) {
                        throw new Exception('Password must be at least 6 characters long.');
                    }
                    
                    // Check if username already exists
                    $stmt = $pdo->prepare("SELECT user_id FROM users WHERE username = ?");
                    $stmt->execute([$username]);
                    if ($stmt->fetch()) {
                        throw new Exception('Username already exists. Please choose a different username.');
                    }
                    
                    // Check if email already exists (if provided)
                    if (!empty($email)) {
                        $stmt = $pdo->prepare("SELECT user_id FROM users WHERE email = ?");
                        $stmt->execute([$email]);
                        if ($stmt->fetch()) {
                            throw new Exception('Email already exists. Please use a different email.');
                        }
                    }
                    
                    // Create new sales clerk
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("
                        INSERT INTO users (full_name, username, email, phone, password, role, status, created_by)
                        VALUES (?, ?, ?, ?, ?, 'sales_clerk', 'active', ?)
                    ");
                    $stmt->execute([
                        $full_name, $username, $email, $phone, $hashed_password, $_SESSION['user_id']
                    ]);
                    
                    $user_id = $pdo->lastInsertId();
                    
                    logActivity('Sales Clerk Added', 'users', $user_id, null, [
                        'full_name' => $full_name,
                        'username' => $username
                    ]);
                    
                    $success_message = 'Sales clerk added successfully!';
                    break;
                    
                case 'update_clerk':
                    $user_id = intval($_POST['user_id']);
                    $full_name = sanitizeInput($_POST['full_name']);
                    $email = sanitizeInput($_POST['email']);
                    $phone = sanitizeInput($_POST['phone']);
                    $status = $_POST['status'];
                    
                    if (empty($full_name)) {
                        throw new Exception('Please fill in all required fields.');
                    }
                    
                    // Get old values for logging
                    $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ? AND role = 'sales_clerk'");
                    $stmt->execute([$user_id]);
                    $old_user = $stmt->fetch();
                    
                    if (!$old_user) {
                        throw new Exception('Sales clerk not found.');
                    }
                    
                    // Check if email already exists (if changed and provided)
                    if (!empty($email) && $email !== $old_user['email']) {
                        $stmt = $pdo->prepare("SELECT user_id FROM users WHERE email = ? AND user_id != ?");
                        $stmt->execute([$email, $user_id]);
                        if ($stmt->fetch()) {
                            throw new Exception('Email already exists. Please use a different email.');
                        }
                    }
                    
                    // Update sales clerk
                    $stmt = $pdo->prepare("
                        UPDATE users 
                        SET full_name = ?, email = ?, phone = ?, status = ?
                        WHERE user_id = ? AND role = 'sales_clerk'
                    ");
                    $stmt->execute([$full_name, $email, $phone, $status, $user_id]);
                    
                    logActivity('Sales Clerk Updated', 'users', $user_id, $old_user, [
                        'full_name' => $full_name,
                        'status' => $status
                    ]);
                    
                    $success_message = 'Sales clerk updated successfully!';
                    break;
                    
                case 'reset_password':
                    $user_id = intval($_POST['user_id']);
                    $new_password = $_POST['new_password'];
                    
                    if (empty($new_password) || strlen($new_password) < 6) {
                        throw new Exception('Password must be at least 6 characters long.');
                    }
                    
                    // Verify user exists and is a sales clerk
                    $stmt = $pdo->prepare("SELECT username FROM users WHERE user_id = ? AND role = 'sales_clerk'");
                    $stmt->execute([$user_id]);
                    $user = $stmt->fetch();
                    
                    if (!$user) {
                        throw new Exception('Sales clerk not found.');
                    }
                    
                    // Update password
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE user_id = ?");
                    $stmt->execute([$hashed_password, $user_id]);
                    
                    logActivity('Password Reset', 'users', $user_id, null, [
                        'username' => $user['username']
                    ]);
                    
                    $success_message = 'Password reset successfully!';
                    break;
                    
                case 'delete_clerk':
                    $user_id = intval($_POST['user_id']);
                    
                    // Verify user exists and is a sales clerk
                    $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ? AND role = 'sales_clerk'");
                    $stmt->execute([$user_id]);
                    $user_to_delete = $stmt->fetch();
                    
                    if (!$user_to_delete) {
                        throw new Exception('Sales clerk not found.');
                    }
                    
                    // Prevent self-deletion
                    if ($user_id == $_SESSION['user_id']) {
                        throw new Exception('You cannot delete your own account.');
                    }
                    
                    $pdo->beginTransaction();
                    
                    try {
                        // Check if user has any orders
                        $stmt = $pdo->prepare("SELECT COUNT(*) as order_count FROM orders WHERE created_by = ?");
                        $stmt->execute([$user_id]);
                        $order_count = $stmt->fetch()['order_count'];
                        
                        if ($order_count > 0) {
                            // Instead of deleting, deactivate the user to preserve data integrity
                            $stmt = $pdo->prepare("UPDATE users SET status = 'inactive' WHERE user_id = ? AND role = 'sales_clerk'");
                            $stmt->execute([$user_id]);
                            
                            logActivity('Sales Clerk Deactivated', 'users', $user_id, $user_to_delete, [
                                'reason' => 'Has existing orders - deactivated instead of deleted',
                                'order_count' => $order_count
                            ]);
                            
                            $success_message = "Sales clerk deactivated instead of deleted due to existing orders ({$order_count} orders).";
                        } else {
                            // Safe to delete - no orders associated
                            $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = ? AND role = 'sales_clerk'");
                            $stmt->execute([$user_id]);
                            
                            logActivity('Sales Clerk Deleted', 'users', $user_id, $user_to_delete, [
                                'full_name' => $user_to_delete['full_name'],
                                'username' => $user_to_delete['username']
                            ]);
                            
                            $success_message = 'Sales clerk deleted successfully!';
                        }
                        
                        $pdo->commit();
                    } catch (Exception $e) {
                        $pdo->rollBack();
                        throw $e;
                    }
                    break;
            }
            
        } catch (Exception $e) {
            $error_message = $e->getMessage();
            logError($error_message);
        }
    }
}

try {
    $pdo = getPDO();
    
    // Get all sales clerks
    $stmt = $pdo->prepare("
        SELECT u.*, 
               COUNT(o.order_id) as total_orders,
               COALESCE(SUM(CASE WHEN DATE(o.created_at) = CURDATE() THEN 1 ELSE 0 END), 0) as today_orders,
               COALESCE(SUM(CASE WHEN DATE(o.created_at) = CURDATE() AND o.status IN ('served', 'ready') THEN o.total_amount ELSE 0 END), 0) as today_sales
        FROM users u
        LEFT JOIN orders o ON u.user_id = o.created_by
        WHERE u.role = 'sales_clerk'
        GROUP BY u.user_id
        ORDER BY u.status ASC, u.full_name ASC
    ");
    $stmt->execute();
    $sales_clerks = $stmt->fetchAll();
    
    // Get statistics
    $total_clerks = count($sales_clerks);
    $active_clerks = count(array_filter($sales_clerks, function($clerk) { return $clerk['status'] === 'active'; }));
    $inactive_clerks = $total_clerks - $active_clerks;
    
} catch (Exception $e) {
    $error_message = "Error loading sales clerks data: " . $e->getMessage();
    $sales_clerks = [];
}

$csrf_token = generateCSRFToken();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Sales Clerks Management</h1>
        <p class="text-muted">Manage sales clerk accounts and permissions</p>
    </div>
    <div>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addClerkModal">
            <i class="fas fa-plus me-2"></i>Add Sales Clerk
        </button>
    </div>
</div>

<?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i>
        <?php echo htmlspecialchars($success_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error_message): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-md-4 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon primary me-3">
                    <i class="fas fa-users"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Total Sales Clerks</h6>
                    <h4 class="mb-0"><?php echo $total_clerks; ?></h4>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-4 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon success me-3">
                    <i class="fas fa-user-check"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Active Clerks</h6>
                    <h4 class="mb-0"><?php echo $active_clerks; ?></h4>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-4 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon warning me-3">
                    <i class="fas fa-user-times"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Inactive Clerks</h6>
                    <h4 class="mb-0"><?php echo $inactive_clerks; ?></h4>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Sales Clerks Table -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-list me-2"></i>
            Sales Clerks List
        </h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover data-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Username</th>
                        <th>Contact</th>
                        <th>Performance</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($sales_clerks as $clerk): ?>
                        <tr>
                            <td>
                                <div>
                                    <strong><?php echo htmlspecialchars($clerk['full_name']); ?></strong>
                                    <br>
                                    <small class="text-muted">
                                        Joined: <?php echo formatDisplayDate($clerk['created_at']); ?>
                                    </small>
                                </div>
                            </td>
                            <td>
                                <span class="badge bg-secondary"><?php echo htmlspecialchars($clerk['username']); ?></span>
                            </td>
                            <td>
                                <?php if ($clerk['email']): ?>
                                    <div><i class="fas fa-envelope me-1"></i><?php echo htmlspecialchars($clerk['email']); ?></div>
                                <?php endif; ?>
                                <?php if ($clerk['phone']): ?>
                                    <div><i class="fas fa-phone me-1"></i><?php echo htmlspecialchars($clerk['phone']); ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="small">
                                    <div><strong><?php echo $clerk['total_orders']; ?></strong> total orders</div>
                                    <div><strong><?php echo $clerk['today_orders']; ?></strong> today</div>
                                    <div class="text-success"><strong><?php echo formatCurrency($clerk['today_sales']); ?></strong> today's sales</div>
                                </div>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo $clerk['status'] === 'active' ? 'success' : 'warning'; ?>">
                                    <?php echo ucfirst($clerk['status']); ?>
                                </span>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <button type="button" class="btn btn-sm btn-outline-primary"
                                            onclick="editClerk(<?php echo htmlspecialchars(json_encode($clerk)); ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-warning"
                                            onclick="resetPassword(<?php echo $clerk['user_id']; ?>, '<?php echo htmlspecialchars($clerk['username']); ?>')">
                                        <i class="fas fa-key"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-danger"
                                            onclick="deleteClerk(<?php echo $clerk['user_id']; ?>, '<?php echo htmlspecialchars($clerk['full_name']); ?>', '<?php echo htmlspecialchars($clerk['username']); ?>')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Sales Clerk Modal -->
<div class="modal fade" id="addClerkModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-plus me-2"></i>Add New Sales Clerk
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="add_clerk">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="full_name" class="form-label">Full Name *</label>
                        <input type="text" class="form-control" id="full_name" name="full_name" required>
                        <div class="invalid-feedback">Please enter full name.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="username" class="form-label">Username *</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                        <div class="invalid-feedback">Please enter username.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email">
                    </div>
                    
                    <div class="mb-3">
                        <label for="phone" class="form-label">Phone</label>
                        <input type="text" class="form-control" id="phone" name="phone">
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">Password *</label>
                        <input type="password" class="form-control" id="password" name="password" required minlength="6">
                        <div class="invalid-feedback">Password must be at least 6 characters long.</div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Add Sales Clerk
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Sales Clerk Modal -->
<div class="modal fade" id="editClerkModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-edit me-2"></i>Edit Sales Clerk
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="update_clerk">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="user_id" id="edit_user_id">
                
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="edit_full_name" class="form-label">Full Name *</label>
                        <input type="text" class="form-control" id="edit_full_name" name="full_name" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="edit_email" name="email">
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_phone" class="form-label">Phone</label>
                        <input type="text" class="form-control" id="edit_phone" name="phone">
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_status" class="form-label">Status</label>
                        <select class="form-select" id="edit_status" name="status">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Update Sales Clerk
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Reset Password Modal -->
<div class="modal fade" id="resetPasswordModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-key me-2"></i>Reset Password
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="reset_password">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="user_id" id="reset_user_id">
                
                <div class="modal-body">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Resetting password for <strong id="reset_username"></strong>
                    </div>
                    
                    <div class="mb-3">
                        <label for="new_password" class="form-label">New Password *</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" required minlength="6">
                        <div class="invalid-feedback">Password must be at least 6 characters long.</div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning">
                        <i class="fas fa-key me-2"></i>Reset Password
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function editClerk(clerk) {
    document.getElementById('edit_user_id').value = clerk.user_id;
    document.getElementById('edit_full_name').value = clerk.full_name;
    document.getElementById('edit_email').value = clerk.email || '';
    document.getElementById('edit_phone').value = clerk.phone || '';
    document.getElementById('edit_status').value = clerk.status;
    
    new bootstrap.Modal(document.getElementById('editClerkModal')).show();
}

function resetPassword(userId, username) {
    document.getElementById('reset_user_id').value = userId;
    document.getElementById('reset_username').textContent = username;
    document.getElementById('new_password').value = '';
    
    new bootstrap.Modal(document.getElementById('resetPasswordModal')).show();
}

function deleteClerk(userId, userName, username) {
    document.getElementById('delete_user_id').value = userId;
    document.getElementById('delete_user_name').textContent = userName;
    document.getElementById('delete_user_username').textContent = username;
    
    new bootstrap.Modal(document.getElementById('deleteClerkModal')).show();
}

// Initialize DataTable
document.addEventListener('DOMContentLoaded', function() {
    if (typeof $ !== 'undefined' && $.fn.DataTable) {
        $('.data-table').DataTable({
            responsive: true,
            pageLength: 25,
            order: [[4, 'asc'], [0, 'asc']], // Sort by status, then name
            columnDefs: [
                { orderable: false, targets: [5] } // Actions column
            ]
        });
    }
});
</script>

<!-- Delete Clerk Modal -->
<div class="modal fade" id="deleteClerkModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-trash me-2"></i>Delete Sales Clerk
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="delete_clerk">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="user_id" id="delete_user_id">
                
                <div class="modal-body">
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <strong>Warning!</strong> This action cannot be undone.
                    </div>
                    
                    <p>You are about to delete the following sales clerk:</p>
                    <ul class="list-unstyled">
                        <li><strong>Name:</strong> <span id="delete_user_name"></span></li>
                        <li><strong>Username:</strong> <span id="delete_user_username"></span></li>
                    </ul>
                    
                    <p>Are you sure you want to proceed with this deletion?</p>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-trash me-2"></i>Delete Sales Clerk
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once '../../common/footer.php'; ?>