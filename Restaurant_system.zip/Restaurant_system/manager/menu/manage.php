<?php
// Manager - Menu Management
$page_title = 'Menu Management';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/manager/'],
    ['title' => 'Menu Management', 'url' => '']
];

require_once '../../common/header.php';
requireRole('manager');

// Handle form submissions
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!validateCSRFToken($csrf_token)) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        try {
            $pdo = getPDO();
            
            switch ($action) {
                case 'add_item':
                    $item_name = sanitizeInput($_POST['item_name']);
                    $item_code = sanitizeInput($_POST['item_code']);
                    $description = sanitizeInput($_POST['description']);
                    $price = floatval($_POST['price']);
                    $category = sanitizeInput($_POST['category']);
                    $image_path = null;
                    $ingredients = $_POST['ingredients'] ?? [];
                    
                    // Handle image upload
                    if (isset($_FILES['item_image']) && $_FILES['item_image']['error'] == 0) {
                        $upload_dir = '../uploads/menu/';
                        if (!is_dir($upload_dir)) {
                            mkdir($upload_dir, 0755, true);
                        }
                        
                        $file_extension = strtolower(pathinfo($_FILES['item_image']['name'], PATHINFO_EXTENSION));
                        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
                        
                        if (in_array($file_extension, $allowed_extensions)) {
                            $new_filename = uniqid() . '_' . time() . '.' . $file_extension;
                            $upload_path = $upload_dir . $new_filename;
                            
                            if (move_uploaded_file($_FILES['item_image']['tmp_name'], $upload_path)) {
                                $image_path = 'uploads/menu/' . $new_filename;
                            }
                        }
                    }
                    
                    if (empty($item_name) || empty($item_code) || $price <= 0) {
                        throw new Exception('Please fill in all required fields with valid values.');
                    }
                    
                    // Check if item code already exists
                    $stmt = $pdo->prepare("SELECT item_id FROM menu_items WHERE item_code = ?");
                    $stmt->execute([$item_code]);
                    if ($stmt->fetch()) {
                        throw new Exception('Item code already exists. Please choose a different code.');
                    }
                    
                    $pdo->beginTransaction();
                    
                    // Insert menu item
                    $stmt = $pdo->prepare("
                        INSERT INTO menu_items (item_name, item_code, description, price, category, image_path)
                        VALUES (?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([$item_name, $item_code, $description, $price, $category, $image_path]);
                    $item_id = $pdo->lastInsertId();
                    
                    // Insert ingredients
                    if (!empty($ingredients)) {
                        $stmt = $pdo->prepare("
                            INSERT INTO menu_item_ingredients (item_id, ingredient_id, quantity_required)
                            VALUES (?, ?, ?)
                        ");
                        
                        foreach ($ingredients as $ingredient) {
                            if (!empty($ingredient['ingredient_id']) && !empty($ingredient['quantity'])) {
                                $stmt->execute([
                                    $item_id,
                                    intval($ingredient['ingredient_id']),
                                    floatval($ingredient['quantity'])
                                ]);
                            }
                        }
                    }
                    
                    $pdo->commit();
                    
                    logActivity('Menu Item Added', 'menu_items', $item_id, null, [
                        'item_name' => $item_name,
                        'item_code' => $item_code,
                        'price' => $price
                    ]);
                    
                    $success_message = 'Menu item added successfully!';
                    break;
                    
                case 'update_item':
                    $item_id = intval($_POST['item_id']);
                    $item_name = sanitizeInput($_POST['item_name']);
                    $description = sanitizeInput($_POST['description']);
                    $price = floatval($_POST['price']);
                    $category = sanitizeInput($_POST['category']);
                    $status = $_POST['status'];
                    
                    // Handle image upload
                    $image_path = null;
                    if (isset($_FILES['item_image']) && $_FILES['item_image']['error'] == 0) {
                        $upload_dir = '../uploads/menu/';
                        if (!is_dir($upload_dir)) {
                            mkdir($upload_dir, 0755, true);
                        }
                        
                        $file_extension = strtolower(pathinfo($_FILES['item_image']['name'], PATHINFO_EXTENSION));
                        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
                        
                        if (in_array($file_extension, $allowed_extensions)) {
                            $new_filename = uniqid() . '_' . time() . '.' . $file_extension;
                            $upload_path = $upload_dir . $new_filename;
                            
                            if (move_uploaded_file($_FILES['item_image']['tmp_name'], $upload_path)) {
                                $image_path = 'uploads/menu/' . $new_filename;
                            }
                        }
                    }
                    
                    if (empty($item_name) || $price <= 0) {
                        throw new Exception('Please fill in all required fields with valid values.');
                    }
                    
                    if (!in_array($status, ['available', 'unavailable'])) {
                        throw new Exception('Invalid status selected.');
                    }
                    
                    // Get old values for logging
                    $stmt = $pdo->prepare("SELECT * FROM menu_items WHERE item_id = ?");
                    $stmt->execute([$item_id]);
                    $old_item = $stmt->fetch();
                    
                    if (!$old_item) {
                        throw new Exception('Menu item not found.');
                    }
                    
                    // Update menu item
                    if ($image_path !== null) {
                        // Update with new image
                        $stmt = $pdo->prepare("
                            UPDATE menu_items
                            SET item_name = ?, description = ?, price = ?, category = ?, image_path = ?, status = ?
                            WHERE item_id = ?
                        ");
                        $stmt->execute([$item_name, $description, $price, $category, $image_path, $status, $item_id]);
                    } else {
                        // Update without changing image
                        $stmt = $pdo->prepare("
                            UPDATE menu_items
                            SET item_name = ?, description = ?, price = ?, category = ?, status = ?
                            WHERE item_id = ?
                        ");
                        $stmt->execute([$item_name, $description, $price, $category, $status, $item_id]);
                    }
                    
                    logActivity('Menu Item Updated', 'menu_items', $item_id, $old_item, [
                        'item_name' => $item_name,
                        'price' => $price,
                        'status' => $status
                    ]);
                    
                    $success_message = 'Menu item updated successfully!';
                    break;
                    
                case 'delete_item':
                    $item_id = intval($_POST['item_id']);
                    
                    // Get item details for logging
                    $stmt = $pdo->prepare("SELECT * FROM menu_items WHERE item_id = ?");
                    $stmt->execute([$item_id]);
                    $item = $stmt->fetch();
                    
                    if (!$item) {
                        throw new Exception('Menu item not found.');
                    }
                    
                    $pdo->beginTransaction();
                    
                    // Delete ingredients first (foreign key constraint)
                    $stmt = $pdo->prepare("DELETE FROM menu_item_ingredients WHERE item_id = ?");
                    $stmt->execute([$item_id]);
                    
                    // Delete menu item
                    $stmt = $pdo->prepare("DELETE FROM menu_items WHERE item_id = ?");
                    $stmt->execute([$item_id]);
                    
                    $pdo->commit();
                    
                    logActivity('Menu Item Deleted', 'menu_items', $item_id, $item);
                    
                    $success_message = 'Menu item deleted successfully!';
                    break;
            }
            
        } catch (Exception $e) {
            if (isset($pdo) && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error_message = $e->getMessage();
            logError($error_message);
        }
    }
}

// Get all menu items with ingredient count
try {
    $pdo = getPDO();
    $stmt = $pdo->prepare("
        SELECT mi.*, 
               COUNT(mii.ingredient_id) as ingredient_count,
               GROUP_CONCAT(
                   CONCAT(i.ingredient_name, ' (', mii.quantity_required, ' ', i.unit, ')')
                   SEPARATOR ', '
               ) as ingredients_list
        FROM menu_items mi
        LEFT JOIN menu_item_ingredients mii ON mi.item_id = mii.item_id
        LEFT JOIN ingredients i ON mii.ingredient_id = i.ingredient_id
        GROUP BY mi.item_id
        ORDER BY mi.category, mi.item_name
    ");
    $stmt->execute();
    $menu_items = $stmt->fetchAll();
    
    // Get all ingredients for the form
    $stmt = $pdo->prepare("
        SELECT ingredient_id, ingredient_name, ingredient_code, unit
        FROM ingredients
        ORDER BY ingredient_name
    ");
    $stmt->execute();
    $all_ingredients = $stmt->fetchAll();
    
    // Get categories
    $categories = array_unique(array_column($menu_items, 'category'));
    sort($categories);
    
} catch (Exception $e) {
    $error_message = "Error loading menu data: " . $e->getMessage();
    $menu_items = [];
    $all_ingredients = [];
    $categories = [];
}

$csrf_token = generateCSRFToken();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Menu Management</h1>
        <p class="text-muted">Manage menu items, prices, and ingredients</p>
    </div>
    <div>
        <button type="button" class="btn btn-success me-2" onclick="printMenu()">
            <i class="fas fa-print me-2"></i>Print Menu
        </button>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addItemModal">
            <i class="fas fa-plus me-2"></i>Add Menu Item
        </button>
    </div>
</div>

<?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i>
        <?php echo htmlspecialchars($success_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error_message): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Menu Statistics -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon primary me-3">
                    <i class="fas fa-utensils"></i>
                </div>
                <div>
                    <h4 class="mb-0"><?php echo count($menu_items); ?></h4>
                    <small class="text-muted">Total Items</small>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon success me-3">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div>
                    <h4 class="mb-0"><?php echo count(array_filter($menu_items, function($item) { return $item['status'] === 'available'; })); ?></h4>
                    <small class="text-muted">Available</small>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon warning me-3">
                    <i class="fas fa-pause-circle"></i>
                </div>
                <div>
                    <h4 class="mb-0"><?php echo count(array_filter($menu_items, function($item) { return $item['status'] === 'unavailable'; })); ?></h4>
                    <small class="text-muted">Unavailable</small>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon info me-3">
                    <i class="fas fa-tags"></i>
                </div>
                <div>
                    <h4 class="mb-0"><?php echo count($categories); ?></h4>
                    <small class="text-muted">Categories</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Menu Items Table -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-list me-2"></i>
            Menu Items
        </h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover data-table">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Ingredients</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($menu_items as $item): ?>
                        <tr>
                            <td>
                                <div>
                                    <strong><?php echo htmlspecialchars($item['item_name']); ?></strong>
                                    <br>
                                    <small class="text-muted">
                                        <span class="badge bg-secondary"><?php echo htmlspecialchars($item['item_code']); ?></span>
                                    </small>
                                    <?php if ($item['description']): ?>
                                        <br>
                                        <small class="text-muted"><?php echo htmlspecialchars($item['description']); ?></small>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <span class="badge bg-info"><?php echo htmlspecialchars($item['category'] ?: 'Uncategorized'); ?></span>
                            </td>
                            <td>
                                <strong class="text-success"><?php echo formatCurrency($item['price']); ?></strong>
                            </td>
                            <td>
                                <?php if ($item['ingredient_count'] > 0): ?>
                                    <span class="badge bg-primary"><?php echo $item['ingredient_count']; ?> ingredients</span>
                                    <?php if ($item['ingredients_list']): ?>
                                        <br>
                                        <small class="text-muted" title="<?php echo htmlspecialchars($item['ingredients_list']); ?>">
                                            <?php echo htmlspecialchars(substr($item['ingredients_list'], 0, 50)) . (strlen($item['ingredients_list']) > 50 ? '...' : ''); ?>
                                        </small>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-muted">No ingredients</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo $item['status'] === 'available' ? 'success' : 'danger'; ?>">
                                    <?php echo ucfirst($item['status']); ?>
                                </span>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <button type="button" class="btn btn-sm btn-outline-primary" 
                                            onclick="editItem(<?php echo htmlspecialchars(json_encode($item)); ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-danger delete-btn" 
                                            onclick="deleteItem(<?php echo $item['item_id']; ?>, '<?php echo htmlspecialchars($item['item_name']); ?>')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Item Modal -->
<div class="modal fade" id="addItemModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-plus me-2"></i>Add Menu Item
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate enctype="multipart/form-data">
                <input type="hidden" name="action" value="add_item">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="item_name" class="form-label">Item Name *</label>
                            <input type="text" class="form-control" id="item_name" name="item_name" required>
                            <div class="invalid-feedback">Please enter the item name.</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="item_code" class="form-label">Item Code *</label>
                            <input type="text" class="form-control" id="item_code" name="item_code" required>
                            <div class="form-text">Unique identifier for the item</div>
                            <div class="invalid-feedback">Please enter the item code.</div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="price" class="form-label">Price (KES) *</label>
                            <input type="number" class="form-control currency-input" id="price" name="price" 
                                   step="0.01" min="0.01" required>
                            <div class="invalid-feedback">Please enter a valid price.</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="category" class="form-label">Category</label>
                            <input type="text" class="form-control" id="category" name="category" 
                                   list="categoryList" placeholder="e.g., Main Course, Appetizers">
                            <datalist id="categoryList">
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo htmlspecialchars($cat); ?>">
                                <?php endforeach; ?>
                            </datalist>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="2" 
                                  placeholder="Optional description of the item"></textarea>
                    </div>
                    
                    <hr>
                    
                    <div class="mb-3">
                        <label for="item_image" class="form-label">Item Image</label>
                        <input type="file" class="form-control" id="item_image" name="item_image" accept="image/*">
                        <div class="form-text">Optional: Upload an image for this menu item (JPG, PNG, GIF)</div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Required Ingredients</label>
                        <div id="ingredientsList">
                            <div class="ingredient-row row mb-2">
                                <div class="col-md-6">
                                    <select class="form-select" name="ingredients[0][ingredient_id]">
                                        <option value="">Select Ingredient</option>
                                        <?php foreach ($all_ingredients as $ingredient): ?>
                                            <option value="<?php echo $ingredient['ingredient_id']; ?>">
                                                <?php echo htmlspecialchars($ingredient['ingredient_name']); ?> 
                                                (<?php echo htmlspecialchars($ingredient['unit']); ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <input type="number" class="form-control" name="ingredients[0][quantity]" 
                                           placeholder="Quantity" step="0.01" min="0">
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-outline-danger" onclick="removeIngredient(this)">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-outline-primary btn-sm" onclick="addIngredient()">
                            <i class="fas fa-plus me-1"></i>Add Ingredient
                        </button>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Add Item
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Item Modal -->
<div class="modal fade" id="editItemModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-edit me-2"></i>Edit Menu Item
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate enctype="multipart/form-data">
                <input type="hidden" name="action" value="update_item">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="item_id" id="edit_item_id">
                
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="edit_item_name" class="form-label">Item Name *</label>
                        <input type="text" class="form-control" id="edit_item_name" name="item_name" required>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="edit_price" class="form-label">Price (KES) *</label>
                            <input type="number" class="form-control currency-input" id="edit_price" name="price" 
                                   step="0.01" min="0.01" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="edit_status" class="form-label">Status *</label>
                            <select class="form-select" id="edit_status" name="status" required>
                                <option value="available">Available</option>
                                <option value="unavailable">Unavailable</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_category" class="form-label">Category</label>
                        <input type="text" class="form-control" id="edit_category" name="category" 
                               list="categoryList">
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_description" class="form-label">Description</label>
                        <textarea class="form-control" id="edit_description" name="description" rows="2"></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_item_image" class="form-label">Item Image</label>
                        <input type="file" class="form-control" id="edit_item_image" name="item_image" accept="image/*">
                        <div class="form-text">Optional: Upload a new image for this menu item (JPG, PNG, GIF)</div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Update Item
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Item Modal -->
<div class="modal fade" id="deleteItemModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-trash me-2"></i>Delete Menu Item
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="delete_item">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="item_id" id="delete_item_id">
                
                <div class="modal-body">
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Are you sure you want to delete <strong id="delete_item_name"></strong>?
                    </div>
                    <p class="mb-0">This action cannot be undone. All associated ingredient relationships will also be removed.</p>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-trash me-2"></i>Delete Item
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$additional_js = "
<script>
let ingredientCount = 1;

function addIngredient() {
    const ingredientsList = document.getElementById('ingredientsList');
    const newRow = document.createElement('div');
    newRow.className = 'ingredient-row row mb-2';
    newRow.innerHTML = `
        <div class='col-md-6'>
            <select class='form-select' name='ingredients[\${ingredientCount}][ingredient_id]'>
                <option value=''>Select Ingredient</option>
                " . implode('', array_map(function($ingredient) {
                    return "<option value='{$ingredient['ingredient_id']}'>" . 
                           htmlspecialchars($ingredient['ingredient_name']) . " (" . 
                           htmlspecialchars($ingredient['unit']) . ")</option>";
                }, $all_ingredients)) . "
            </select>
        </div>
        <div class='col-md-4'>
            <input type='number' class='form-control' name='ingredients[\${ingredientCount}][quantity]' 
                   placeholder='Quantity' step='0.01' min='0'>
        </div>
        <div class='col-md-2'>
            <button type='button' class='btn btn-outline-danger' onclick='removeIngredient(this)'>
                <i class='fas fa-minus'></i>
            </button>
        </div>
    `;
    ingredientsList.appendChild(newRow);
    ingredientCount++;
}

function removeIngredient(button) {
    const row = button.closest('.ingredient-row');
    if (document.querySelectorAll('.ingredient-row').length > 1) {
        row.remove();
    }
}

function editItem(item) {
    document.getElementById('edit_item_id').value = item.item_id;
    document.getElementById('edit_item_name').value = item.item_name;
    document.getElementById('edit_price').value = item.price;
    document.getElementById('edit_category').value = item.category || '';
    document.getElementById('edit_description').value = item.description || '';
    document.getElementById('edit_status').value = item.status;
    
    new bootstrap.Modal(document.getElementById('editItemModal')).show();
}

function deleteItem(itemId, itemName) {
    document.getElementById('delete_item_id').value = itemId;
    document.getElementById('delete_item_name').textContent = itemName;
    
    new bootstrap.Modal(document.getElementById('deleteItemModal')).show();
}

function printMenu() {
    window.open('/Restaurant_system/common/menu_card.php?print=1', '_blank');
}
</script>
";

require_once '../../common/footer.php';
?>