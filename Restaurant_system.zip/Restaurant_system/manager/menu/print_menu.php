<?php
// Manager - Menu Card Printing
$page_title = 'Print Menu Cards';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/manager/'],
    ['title' => 'Menu', 'url' => '/Restaurant_system/manager/menu/manage.php'],
    ['title' => 'Print Menu', 'url' => '']
];

require_once '../../common/header.php';
requireRole('manager');

// Handle form submissions
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!validateCSRFToken($csrf_token)) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        try {
            $pdo = getPDO();
            
            switch ($action) {
                case 'update_menu_settings':
                    $restaurant_name = sanitizeInput($_POST['restaurant_name']);
                    $restaurant_tagline = sanitizeInput($_POST['restaurant_tagline']);
                    $restaurant_address = sanitizeInput($_POST['restaurant_address']);
                    $restaurant_phone = sanitizeInput($_POST['restaurant_phone']);
                    $restaurant_email = sanitizeInput($_POST['restaurant_email']);
                    $menu_footer_text = sanitizeInput($_POST['menu_footer_text']);
                    
                    // Update or insert menu settings
                    $settings = [
                        'restaurant_name' => $restaurant_name,
                        'restaurant_tagline' => $restaurant_tagline,
                        'restaurant_address' => $restaurant_address,
                        'restaurant_phone' => $restaurant_phone,
                        'restaurant_email' => $restaurant_email,
                        'menu_footer_text' => $menu_footer_text
                    ];
                    
                    foreach ($settings as $key => $value) {
                        $stmt = $pdo->prepare("
                            INSERT INTO system_settings (setting_key, setting_value, updated_by, updated_at)
                            VALUES (?, ?, ?, NOW())
                            ON DUPLICATE KEY UPDATE
                                setting_value = VALUES(setting_value),
                                updated_by = VALUES(updated_by),
                                updated_at = VALUES(updated_at)
                        ");
                        $stmt->execute([$key, $value, $_SESSION['user_id']]);
                    }
                    
                    logActivity('Menu Settings Updated', 'system_settings', null, null, [
                        'restaurant_name' => $restaurant_name
                    ]);
                    
                    $success_message = 'Menu settings updated successfully!';
                    break;
                    
                case 'update_menu_layout':
                    $layout_style = sanitizeInput($_POST['layout_style']);
                    $show_prices = isset($_POST['show_prices']) ? 1 : 0;
                    $show_descriptions = isset($_POST['show_descriptions']) ? 1 : 0;
                    $show_categories = isset($_POST['show_categories']) ? 1 : 0;
                    $items_per_column = intval($_POST['items_per_column'] ?? 10);
                    $font_size = sanitizeInput($_POST['font_size']);
                    
                    $layout_settings = [
                        'menu_layout_style' => $layout_style,
                        'menu_show_prices' => $show_prices,
                        'menu_show_descriptions' => $show_descriptions,
                        'menu_show_categories' => $show_categories,
                        'menu_items_per_column' => $items_per_column,
                        'menu_font_size' => $font_size
                    ];
                    
                    foreach ($layout_settings as $key => $value) {
                        $stmt = $pdo->prepare("
                            INSERT INTO system_settings (setting_key, setting_value, updated_by, updated_at)
                            VALUES (?, ?, ?, NOW())
                            ON DUPLICATE KEY UPDATE
                                setting_value = VALUES(setting_value),
                                updated_by = VALUES(updated_by),
                                updated_at = VALUES(updated_at)
                        ");
                        $stmt->execute([$key, $value, $_SESSION['user_id']]);
                    }
                    
                    logActivity('Menu Layout Updated', 'system_settings', null, null, [
                        'layout_style' => $layout_style,
                        'show_prices' => $show_prices
                    ]);
                    
                    $success_message = 'Menu layout settings updated successfully!';
                    break;
            }
            
        } catch (Exception $e) {
            $error_message = $e->getMessage();
            logError($error_message);
        }
    }
}

try {
    $pdo = getPDO();
    
    // Get current menu settings
    $stmt = $pdo->prepare("
        SELECT setting_key, setting_value 
        FROM system_settings 
        WHERE setting_key IN ('restaurant_name', 'restaurant_tagline', 'restaurant_address', 
                              'restaurant_phone', 'restaurant_email', 'menu_footer_text',
                              'menu_layout_style', 'menu_show_prices', 'menu_show_descriptions',
                              'menu_show_categories', 'menu_items_per_column', 'menu_font_size')
    ");
    $stmt->execute();
    $settings_data = $stmt->fetchAll();
    
    $menu_settings = [
        'restaurant_name' => 'Restaurant Name',
        'restaurant_tagline' => 'Delicious Food, Great Service',
        'restaurant_address' => '123 Main Street, City, Country',
        'restaurant_phone' => '+1 234 567 8900',
        'restaurant_email' => 'info@restaurant.com',
        'menu_footer_text' => 'Thank you for dining with us!',
        'menu_layout_style' => 'classic',
        'menu_show_prices' => 1,
        'menu_show_descriptions' => 1,
        'menu_show_categories' => 1,
        'menu_items_per_column' => 10,
        'menu_font_size' => 'medium'
    ];
    
    foreach ($settings_data as $setting) {
        $menu_settings[$setting['setting_key']] = $setting['setting_value'];
    }
    
    // Get menu items grouped by category
    $stmt = $pdo->prepare("
        SELECT mi.*, mc.category_name, mc.display_order as category_order
        FROM menu_items mi
        LEFT JOIN menu_categories mc ON mi.category_id = mc.category_id
        WHERE mi.is_available = 1
        ORDER BY mc.display_order ASC, mi.display_order ASC, mi.item_name ASC
    ");
    $stmt->execute();
    $menu_items = $stmt->fetchAll();
    
    // Group items by category
    $menu_by_category = [];
    foreach ($menu_items as $item) {
        $category = $item['category_name'] ?: 'Uncategorized';
        if (!isset($menu_by_category[$category])) {
            $menu_by_category[$category] = [];
        }
        $menu_by_category[$category][] = $item;
    }
    
    // Get menu statistics
    $total_items = count($menu_items);
    $total_categories = count($menu_by_category);
    $avg_price = 0;
    if ($total_items > 0) {
        $avg_price = array_sum(array_column($menu_items, 'price')) / $total_items;
    }
    
} catch (Exception $e) {
    $error_message = "Error loading menu data: " . $e->getMessage();
    $menu_items = [];
    $menu_by_category = [];
    $menu_settings = [];
}

$csrf_token = generateCSRFToken();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Print Menu Cards</h1>
        <p class="text-muted">Design and print professional menu cards</p>
    </div>
    <div>
        <button type="button" class="btn btn-success me-2" onclick="printMenu()">
            <i class="fas fa-print me-2"></i>Print Menu
        </button>
        <button type="button" class="btn btn-primary" onclick="previewMenu()">
            <i class="fas fa-eye me-2"></i>Preview
        </button>
    </div>
</div>

<?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i>
        <?php echo htmlspecialchars($success_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error_message): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Menu Statistics -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon primary me-3">
                    <i class="fas fa-utensils"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Total Items</h6>
                    <h4 class="mb-0"><?php echo $total_items; ?></h4>
                    <small class="text-muted">Available items</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon info me-3">
                    <i class="fas fa-list"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Categories</h6>
                    <h4 class="mb-0"><?php echo $total_categories; ?></h4>
                    <small class="text-muted">Menu sections</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon success me-3">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Average Price</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($avg_price); ?></h4>
                    <small class="text-muted">Per item</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon warning me-3">
                    <i class="fas fa-cog"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Layout Style</h6>
                    <h4 class="mb-0"><?php echo ucfirst($menu_settings['menu_layout_style']); ?></h4>
                    <small class="text-muted">Current design</small>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Menu Settings -->
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-info-circle me-2"></i>
                    Restaurant Information
                </h5>
            </div>
            <div class="card-body">
                <form method="POST" class="needs-validation" novalidate>
                    <input type="hidden" name="action" value="update_menu_settings">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    
                    <div class="mb-3">
                        <label for="restaurant_name" class="form-label">Restaurant Name *</label>
                        <input type="text" class="form-control" id="restaurant_name" name="restaurant_name" 
                               value="<?php echo htmlspecialchars($menu_settings['restaurant_name']); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="restaurant_tagline" class="form-label">Tagline</label>
                        <input type="text" class="form-control" id="restaurant_tagline" name="restaurant_tagline" 
                               value="<?php echo htmlspecialchars($menu_settings['restaurant_tagline']); ?>"
                               placeholder="e.g., Delicious Food, Great Service">
                    </div>
                    
                    <div class="mb-3">
                        <label for="restaurant_address" class="form-label">Address</label>
                        <textarea class="form-control" id="restaurant_address" name="restaurant_address" rows="2"><?php echo htmlspecialchars($menu_settings['restaurant_address']); ?></textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="restaurant_phone" class="form-label">Phone</label>
                            <input type="tel" class="form-control" id="restaurant_phone" name="restaurant_phone" 
                                   value="<?php echo htmlspecialchars($menu_settings['restaurant_phone']); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="restaurant_email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="restaurant_email" name="restaurant_email" 
                                   value="<?php echo htmlspecialchars($menu_settings['restaurant_email']); ?>">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="menu_footer_text" class="form-label">Footer Text</label>
                        <textarea class="form-control" id="menu_footer_text" name="menu_footer_text" rows="2"><?php echo htmlspecialchars($menu_settings['menu_footer_text']); ?></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Save Information
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Layout Settings -->
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-palette me-2"></i>
                    Layout Settings
                </h5>
            </div>
            <div class="card-body">
                <form method="POST" class="needs-validation" novalidate>
                    <input type="hidden" name="action" value="update_menu_layout">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    
                    <div class="mb-3">
                        <label for="layout_style" class="form-label">Layout Style</label>
                        <select class="form-select" id="layout_style" name="layout_style">
                            <option value="classic" <?php echo $menu_settings['menu_layout_style'] === 'classic' ? 'selected' : ''; ?>>Classic</option>
                            <option value="modern" <?php echo $menu_settings['menu_layout_style'] === 'modern' ? 'selected' : ''; ?>>Modern</option>
                            <option value="elegant" <?php echo $menu_settings['menu_layout_style'] === 'elegant' ? 'selected' : ''; ?>>Elegant</option>
                            <option value="minimal" <?php echo $menu_settings['menu_layout_style'] === 'minimal' ? 'selected' : ''; ?>>Minimal</option>
                        </select>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="font_size" class="form-label">Font Size</label>
                            <select class="form-select" id="font_size" name="font_size">
                                <option value="small" <?php echo $menu_settings['menu_font_size'] === 'small' ? 'selected' : ''; ?>>Small</option>
                                <option value="medium" <?php echo $menu_settings['menu_font_size'] === 'medium' ? 'selected' : ''; ?>>Medium</option>
                                <option value="large" <?php echo $menu_settings['menu_font_size'] === 'large' ? 'selected' : ''; ?>>Large</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="items_per_column" class="form-label">Items per Column</label>
                            <input type="number" class="form-control" id="items_per_column" name="items_per_column" 
                                   min="5" max="20" value="<?php echo $menu_settings['menu_items_per_column']; ?>">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Display Options</label>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="show_prices" name="show_prices" 
                                   <?php echo $menu_settings['menu_show_prices'] ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="show_prices">Show Prices</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="show_descriptions" name="show_descriptions" 
                                   <?php echo $menu_settings['menu_show_descriptions'] ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="show_descriptions">Show Descriptions</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="show_categories" name="show_categories" 
                                   <?php echo $menu_settings['menu_show_categories'] ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="show_categories">Show Categories</label>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Save Layout
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Menu Preview -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">
            <i class="fas fa-eye me-2"></i>
            Menu Preview
        </h5>
        <div>
            <button type="button" class="btn btn-sm btn-outline-primary" onclick="refreshPreview()">
                <i class="fas fa-sync me-2"></i>Refresh
            </button>
            <button type="button" class="btn btn-sm btn-success" onclick="printMenu()">
                <i class="fas fa-print me-2"></i>Print
            </button>
        </div>
    </div>
    <div class="card-body">
        <div id="menuPreview" class="menu-preview <?php echo $menu_settings['menu_layout_style']; ?> font-<?php echo $menu_settings['menu_font_size']; ?>">
            <!-- Menu content will be generated here -->
        </div>
    </div>
</div>

<!-- Hidden menu data for JavaScript -->
<script type="application/json" id="menuData">
<?php echo json_encode([
    'settings' => $menu_settings,
    'menu_by_category' => $menu_by_category,
    'total_items' => $total_items
]); ?>
</script>

<style>
.menu-preview {
    background: white;
    padding: 30px;
    border: 1px solid #ddd;
    font-family: 'Times New Roman', serif;
    max-width: 800px;
    margin: 0 auto;
}

.menu-preview.classic {
    font-family: 'Times New Roman', serif;
}

.menu-preview.modern {
    font-family: 'Arial', sans-serif;
}

.menu-preview.elegant {
    font-family: 'Georgia', serif;
}

.menu-preview.minimal {
    font-family: 'Helvetica', sans-serif;
}

.menu-preview.font-small {
    font-size: 12px;
}

.menu-preview.font-medium {
    font-size: 14px;
}

.menu-preview.font-large {
    font-size: 16px;
}

.menu-header {
    text-align: center;
    margin-bottom: 30px;
    border-bottom: 2px solid #333;
    padding-bottom: 20px;
}

.menu-header h1 {
    font-size: 2.5em;
    margin-bottom: 10px;
    color: #333;
}

.menu-header .tagline {
    font-style: italic;
    font-size: 1.2em;
    color: #666;
    margin-bottom: 15px;
}

.menu-header .contact-info {
    font-size: 0.9em;
    color: #666;
}

.menu-category {
    margin-bottom: 25px;
}

.menu-category h2 {
    font-size: 1.5em;
    color: #333;
    border-bottom: 1px solid #ccc;
    padding-bottom: 5px;
    margin-bottom: 15px;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.menu-item {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 12px;
    padding-bottom: 8px;
    border-bottom: 1px dotted #ddd;
}

.menu-item:last-child {
    border-bottom: none;
}

.menu-item-info {
    flex: 1;
}

.menu-item-name {
    font-weight: bold;
    color: #333;
    margin-bottom: 3px;
}

.menu-item-description {
    font-size: 0.9em;
    color: #666;
    font-style: italic;
    line-height: 1.3;
}

.menu-item-price {
    font-weight: bold;
    color: #333;
    margin-left: 15px;
    white-space: nowrap;
}

.menu-footer {
    text-align: center;
    margin-top: 30px;
    padding-top: 20px;
    border-top: 2px solid #333;
    font-style: italic;
    color: #666;
}

@media print {
    .menu-preview {
        border: none;
        box-shadow: none;
        padding: 20px;
    }
    
    .card, .btn, .alert {
        display: none !important;
    }
    
    body {
        background: white !important;
    }
}
</style>

<script>
// JavaScript functions for menu printing
let menuData = {};

document.addEventListener('DOMContentLoaded', function() {
    // Load menu data
    const menuDataElement = document.getElementById('menuData');
    if (menuDataElement) {
        menuData = JSON.parse(menuDataElement.textContent);
        generateMenuPreview();
    }
});

function generateMenuPreview() {
    const preview = document.getElementById('menuPreview');
    const settings = menuData.settings;
    const menuByCategory = menuData.menu_by_category;
    
    let html = '';
    
    // Menu Header
    html += '<div class="menu-header">';
    html += `<h1>${settings.restaurant_name}</h1>`;
    if (settings.restaurant_tagline) {
        html += `<div class="tagline">${settings.restaurant_tagline}</div>`;
    }
    html += '<div class="contact-info">';
    if (settings.restaurant_address) {
        html += `<div>${settings.restaurant_address}</div>`;
    }
    if (settings.restaurant_phone || settings.restaurant_email) {
        html += '<div>';
        if (settings.restaurant_phone) {
            html += `Tel: ${settings.restaurant_phone}`;
        }
        if (settings.restaurant_phone && settings.restaurant_email) {
            html += ' | ';
        }
        if (settings.restaurant_email) {
            html += `Email: ${settings.restaurant_email}`;
        }
        html += '</div>';
    }
    html += '</div>';
    html += '</div>';
    
    // Menu Items by Category
    for (const [categoryName, items] of Object.entries(menuByCategory)) {
        if (settings.menu_show_categories == 1) {
            html += `<div class="menu-category">`;
            html += `<h2>${categoryName}</h2>`;
        } else {
            html += `<div class="menu-category">`;
        }
        
        items.forEach(item => {
            html += '<div class="menu-item">';
            html += '<div class="menu-item-info">';
            html += `<div class="menu-item-name">${item.item_name}</div>`;
            if (settings.menu_show_descriptions == 1 && item.description) {
                html += `<div class="menu-item-description">${item.description}</div>`;
            }
            html += '</div>';
            if (settings.menu_show_prices == 1) {
                html += `<div class="menu-item-price">KES ${parseFloat(item.price).toLocaleString('en-KE', {minimumFractionDigits: 2})}</div>`;
            }
            html += '</div>';
        });
        
        html += '</div>';
    }
    
    // Menu Footer
    if (settings.menu_footer_text) {
        html += `<div class="menu-footer">${settings.menu_footer_text}</div>`;
    }
    
    preview.innerHTML = html;
}

function refreshPreview() {
    generateMenuPreview();
}

function previewMenu() {
    const preview = document.getElementById('menuPreview');
    const newWindow = window.open('', '_blank');
    newWindow.document.write(`
        <html>
        <head>
            <title>Menu Preview - ${menuData.settings.restaurant_name}</title>
            <style>
                body { 
                    margin: 0; 
                    padding: 20px; 
                    font-family: 'Times New Roman', serif;
                    background: white;
                }
                ${document.querySelector('style').textContent}
                .menu-preview {
                    border: none;
                    box-shadow: none;
                    max-width: none;
                }
            </style>
        </head>
        <body>
            <div class="menu-preview ${menuData.settings.menu_layout_style} font-${menuData.settings.menu_font_size}">
                ${preview.innerHTML}
            </div>
        </body>
        </html>
    `);
    newWindow.document.close();
}

function printMenu() {
    const preview = document.getElementById('menuPreview');
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <html>
        <head>
            <title>Menu - ${menuData.settings.restaurant_name}</title>
            <style>
                body { 
                    margin: 0; 
                    padding: 20px; 
                    font-family: 'Times New Roman', serif;
                    background: white;
                }
                ${document.querySelector('style').textContent}
                .menu-preview {
                    border: none;
                    box-shadow: none;
                    max-width: none;
                }
                @page {
                    margin: 1in;
                    size: A4;
                }
            </style>
        </head>
        <body>
            <div class="menu-preview ${menuData.settings.menu_layout_style} font-${menuData.settings.menu_font_size}">
                ${preview.innerHTML}
            </div>
        </body>
        </html>
    `);
    printWindow.document.close();
    printWindow.print();
}

// Auto-refresh preview when settings change
document.querySelectorAll('input, select, textarea').forEach(element => {
    element.addEventListener('change', function() {
        // Update menuData with new values
        const formData = new FormData(this.closest('form'));
        for (const [key, value] of formData.entries()) {
            if (menuData.settings.hasOwnProperty(key)) {
                menuData.settings[key] = value;
            }
        }
        
        // Refresh preview after a short delay
        setTimeout(generateMenuPreview, 100);
    });
});
</script>

<?php require_once '../../common/footer.php'; ?>