<?php
// Manager - Invoice Processing
$page_title = 'Invoice Processing';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/manager/'],
    ['title' => 'Invoice Processing', 'url' => '']
];

require_once '../../common/header.php';
requireRole('manager');

// Handle form submissions
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!validateCSRFToken($csrf_token)) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        try {
            $pdo = getPDO();
            
            switch ($action) {
                case 'create_invoice':
                    $invoice_number = sanitizeInput($_POST['invoice_number']);
                    $po_id = !empty($_POST['po_id']) ? intval($_POST['po_id']) : null;
                    $supplier_name = sanitizeInput($_POST['supplier_name']);
                    $invoice_date = $_POST['invoice_date'];
                    $total_amount = floatval($_POST['total_amount']);
                    
                    if (empty($invoice_number) || empty($supplier_name) || empty($invoice_date) || $total_amount <= 0) {
                        throw new Exception('Please fill in all required fields with valid values.');
                    }
                    
                    // Check if invoice number already exists
                    $stmt = $pdo->prepare("SELECT invoice_id FROM invoices WHERE invoice_number = ?");
                    $stmt->execute([$invoice_number]);
                    if ($stmt->fetch()) {
                        throw new Exception('Invoice number already exists. Please use a different number.');
                    }
                    
                    // Validate PO if provided
                    if ($po_id) {
                        $stmt = $pdo->prepare("SELECT * FROM purchase_orders WHERE po_id = ?");
                        $stmt->execute([$po_id]);
                        $po = $stmt->fetch();
                        
                        if (!$po) {
                            throw new Exception('Selected purchase order not found.');
                        }
                    }
                    
                    // Check available funds
                    $available_funds = getAvailableFunds();
                    
                    // Insert invoice
                    $stmt = $pdo->prepare("
                        INSERT INTO invoices (invoice_number, po_id, supplier_name, invoice_date, total_amount, created_by)
                        VALUES (?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $invoice_number,
                        $po_id,
                        $supplier_name,
                        $invoice_date,
                        $total_amount,
                        $_SESSION['user_id']
                    ]);
                    
                    $invoice_id = $pdo->lastInsertId();
                    
                    // Check if funds are sufficient for automatic cheque generation
                    $cheque_generated = false;
                    if ($available_funds >= $total_amount) {
                        $pdo->beginTransaction();
                        
                        // Generate cheque number
                        $cheque_number = 'CHQ' . date('Ymd') . str_pad($invoice_id, 4, '0', STR_PAD_LEFT);
                        
                        // Update invoice with cheque details
                        $stmt = $pdo->prepare("
                            UPDATE invoices 
                            SET status = 'paid', payment_method = 'cheque', cheque_number = ?
                            WHERE invoice_id = ?
                        ");
                        $stmt->execute([$cheque_number, $invoice_id]);
                        
                        // Deduct from available funds
                        $new_funds = $available_funds - $total_amount;
                        updateAvailableFunds($new_funds, $_SESSION['user_id']);
                        
                        $pdo->commit();
                        $cheque_generated = true;
                        
                        $success_message = "Invoice created and cheque #{$cheque_number} generated automatically! Amount: " . formatCurrency($total_amount);
                    } else {
                        $success_message = "Invoice created successfully! Awaiting business owner approval for payment. Required: " . formatCurrency($total_amount) . ", Available: " . formatCurrency($available_funds);
                    }
                    
                    logActivity('Invoice Created', 'invoices', $invoice_id, null, [
                        'invoice_number' => $invoice_number,
                        'supplier_name' => $supplier_name,
                        'total_amount' => $total_amount,
                        'cheque_generated' => $cheque_generated
                    ]);
                    
                    break;
                    
                case 'update_invoice':
                    $invoice_id = intval($_POST['invoice_id']);
                    $supplier_name = sanitizeInput($_POST['supplier_name']);
                    $invoice_date = $_POST['invoice_date'];
                    $total_amount = floatval($_POST['total_amount']);
                    
                    if (empty($supplier_name) || empty($invoice_date) || $total_amount <= 0) {
                        throw new Exception('Please fill in all required fields with valid values.');
                    }
                    
                    // Get current invoice
                    $stmt = $pdo->prepare("SELECT * FROM invoices WHERE invoice_id = ?");
                    $stmt->execute([$invoice_id]);
                    $old_invoice = $stmt->fetch();
                    
                    if (!$old_invoice) {
                        throw new Exception('Invoice not found.');
                    }
                    
                    if ($old_invoice['status'] === 'paid') {
                        throw new Exception('Cannot update a paid invoice.');
                    }
                    
                    // Update invoice
                    $stmt = $pdo->prepare("
                        UPDATE invoices 
                        SET supplier_name = ?, invoice_date = ?, total_amount = ?
                        WHERE invoice_id = ?
                    ");
                    $stmt->execute([$supplier_name, $invoice_date, $total_amount, $invoice_id]);
                    
                    logActivity('Invoice Updated', 'invoices', $invoice_id, $old_invoice, [
                        'supplier_name' => $supplier_name,
                        'invoice_date' => $invoice_date,
                        'total_amount' => $total_amount
                    ]);
                    
                    $success_message = 'Invoice updated successfully!';
                    break;
            }
            
        } catch (Exception $e) {
            if (isset($pdo) && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error_message = $e->getMessage();
            logError($error_message);
        }
    }
}

try {
    $pdo = getPDO();
    
    // Get all invoices
    $stmt = $pdo->prepare("
        SELECT i.*, po.po_number, u.full_name as created_by_name
        FROM invoices i
        LEFT JOIN purchase_orders po ON i.po_id = po.po_id
        JOIN users u ON i.created_by = u.user_id
        ORDER BY i.created_at DESC
    ");
    $stmt->execute();
    $invoices = $stmt->fetchAll();
    
    // Get purchase orders for dropdown
    $stmt = $pdo->prepare("
        SELECT po_id, po_number, supplier_name, total_amount, status
        FROM purchase_orders
        WHERE status IN ('ordered', 'received')
        ORDER BY created_at DESC
    ");
    $stmt->execute();
    $purchase_orders = $stmt->fetchAll();
    
    // Get available funds
    $available_funds = getAvailableFunds();
    
    // Calculate statistics
    $total_invoices = count($invoices);
    $pending_invoices = count(array_filter($invoices, function($inv) { return $inv['status'] === 'pending'; }));
    $paid_invoices = count(array_filter($invoices, function($inv) { return $inv['status'] === 'paid'; }));
    $total_pending_amount = array_sum(array_map(function($inv) { 
        return $inv['status'] === 'pending' ? $inv['total_amount'] : 0; 
    }, $invoices));
    
} catch (Exception $e) {
    $error_message = "Error loading invoice data: " . $e->getMessage();
    $invoices = [];
    $purchase_orders = [];
}

$csrf_token = generateCSRFToken();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Invoice Processing</h1>
        <p class="text-muted">Process supplier invoices and generate cheques</p>
    </div>
    <div>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createInvoiceModal">
            <i class="fas fa-plus me-2"></i>Create Invoice
        </button>
    </div>
</div>

<?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i>
        <?php echo htmlspecialchars($success_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error_message): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon primary me-3">
                    <i class="fas fa-file-invoice"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Total Invoices</h6>
                    <h4 class="mb-0"><?php echo $total_invoices; ?></h4>
                    <small class="text-muted">All time</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon warning me-3">
                    <i class="fas fa-clock"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Pending Payment</h6>
                    <h4 class="mb-0"><?php echo $pending_invoices; ?></h4>
                    <small class="text-muted"><?php echo formatCurrency($total_pending_amount); ?></small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon success me-3">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Paid Invoices</h6>
                    <h4 class="mb-0"><?php echo $paid_invoices; ?></h4>
                    <small class="text-muted">Completed</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon info me-3">
                    <i class="fas fa-wallet"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Available Funds</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($available_funds); ?></h4>
                    <small class="text-muted">For payments</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Invoices Table -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-list me-2"></i>
            Invoices
        </h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover data-table">
                <thead>
                    <tr>
                        <th>Invoice #</th>
                        <th>Supplier</th>
                        <th>PO #</th>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Cheque #</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($invoices as $invoice): ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($invoice['invoice_number']); ?></strong>
                            </td>
                            <td><?php echo htmlspecialchars($invoice['supplier_name']); ?></td>
                            <td>
                                <?php if ($invoice['po_number']): ?>
                                    <button type="button" class="btn btn-sm btn-outline-info"
                                            onclick="viewRelatedPO(<?php echo $invoice['po_id']; ?>)"
                                            title="View Related Purchase Order">
                                        <?php echo htmlspecialchars($invoice['po_number']); ?>
                                    </button>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo formatDisplayDate($invoice['invoice_date']); ?></td>
                            <td>
                                <strong class="text-success"><?php echo formatCurrency($invoice['total_amount']); ?></strong>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo $invoice['status'] === 'paid' ? 'success' : 'warning'; ?>">
                                    <?php echo ucfirst($invoice['status']); ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($invoice['cheque_number']): ?>
                                    <span class="badge bg-primary"><?php echo htmlspecialchars($invoice['cheque_number']); ?></span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <?php if ($invoice['status'] === 'pending'): ?>
                                        <button type="button" class="btn btn-sm btn-outline-primary" 
                                                onclick="editInvoice(<?php echo htmlspecialchars(json_encode($invoice)); ?>)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                    <?php endif; ?>
                                    <?php if ($invoice['cheque_number']): ?>
                                        <button type="button" class="btn btn-sm btn-outline-success" 
                                                onclick="printCheque('<?php echo htmlspecialchars($invoice['cheque_number']); ?>', '<?php echo htmlspecialchars($invoice['supplier_name']); ?>', <?php echo $invoice['total_amount']; ?>)">
                                            <i class="fas fa-print"></i>
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Create Invoice Modal -->
<div class="modal fade" id="createInvoiceModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-plus me-2"></i>Create Invoice
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="create_invoice">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="invoice_number" class="form-label">Invoice Number *</label>
                            <input type="text" class="form-control" id="invoice_number" name="invoice_number" required>
                            <div class="invalid-feedback">Please enter invoice number.</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="invoice_date" class="form-label">Invoice Date *</label>
                            <input type="date" class="form-control" id="invoice_date" name="invoice_date" 
                                   value="<?php echo date('Y-m-d'); ?>" required>
                            <div class="invalid-feedback">Please select invoice date.</div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="supplier_name" class="form-label">Supplier Name *</label>
                            <input type="text" class="form-control" id="supplier_name" name="supplier_name" required>
                            <div class="invalid-feedback">Please enter supplier name.</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="po_id" class="form-label">Related Purchase Order</label>
                            <select class="form-select" id="po_id" name="po_id">
                                <option value="">Select PO (Optional)</option>
                                <?php foreach ($purchase_orders as $po): ?>
                                    <option value="<?php echo $po['po_id']; ?>" 
                                            data-supplier="<?php echo htmlspecialchars($po['supplier_name']); ?>"
                                            data-amount="<?php echo $po['total_amount']; ?>">
                                        <?php echo htmlspecialchars($po['po_number']); ?> - 
                                        <?php echo htmlspecialchars($po['supplier_name']); ?> 
                                        (<?php echo formatCurrency($po['total_amount']); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="total_amount" class="form-label">Total Amount (KES) *</label>
                        <input type="number" class="form-control currency-input" id="total_amount" 
                               name="total_amount" step="0.01" min="0.01" required>
                        <div class="invalid-feedback">Please enter a valid amount.</div>
                    </div>
                    
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>Available Funds:</strong> <?php echo formatCurrency($available_funds); ?>
                        <br>
                        <small>If sufficient funds are available, a cheque will be generated automatically.</small>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Create Invoice
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Invoice Modal -->
<div class="modal fade" id="editInvoiceModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-edit me-2"></i>Edit Invoice
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="update_invoice">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="invoice_id" id="edit_invoice_id">
                
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="edit_supplier_name" class="form-label">Supplier Name *</label>
                        <input type="text" class="form-control" id="edit_supplier_name" name="supplier_name" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_invoice_date" class="form-label">Invoice Date *</label>
                        <input type="date" class="form-control" id="edit_invoice_date" name="invoice_date" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_total_amount" class="form-label">Total Amount (KES) *</label>
                        <input type="number" class="form-control currency-input" id="edit_total_amount" 
                               name="total_amount" step="0.01" min="0.01" required>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Update Invoice
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Cheque Print Modal -->
<div class="modal fade" id="chequeModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-print me-2"></i>Print Cheque
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="chequeContent" class="p-4 border" style="background: #f8f9fa;">
                    <div class="row mb-4">
                        <div class="col-6">
                            <h4><?php echo getSystemSetting('restaurant_name', 'Restaurant Name'); ?></h4>
                            <p class="mb-0">Restaurant Management System</p>
                        </div>
                        <div class="col-6 text-end">
                            <h5>CHEQUE</h5>
                            <p class="mb-0">Date: <span id="cheque_date"><?php echo date('M d, Y'); ?></span></p>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-12">
                            <p class="mb-1"><strong>Pay to the order of:</strong></p>
                            <h5 class="border-bottom pb-2" id="cheque_payee">Supplier Name</h5>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-8">
                            <p class="mb-1"><strong>Amount in words:</strong></p>
                            <p class="border-bottom pb-2" id="cheque_amount_words">Amount in words</p>
                        </div>
                        <div class="col-4 text-end">
                            <p class="mb-1"><strong>KES</strong></p>
                            <h4 class="border-bottom pb-2" id="cheque_amount">0.00</h4>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-6">
                            <p class="mb-1"><strong>Cheque Number:</strong></p>
                            <p id="cheque_number">CHQ000000</p>
                        </div>
                        <div class="col-6 text-end">
                            <p class="mb-1"><strong>Authorized Signature:</strong></p>
                            <div class="border-bottom" style="height: 40px;"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="window.print()">
                    <i class="fas fa-print me-2"></i>Print Cheque
                </button>
            </div>
        </div>
    </div>
</div>

<?php
$additional_js = "
<script>
function editInvoice(invoice) {
    document.getElementById('edit_invoice_id').value = invoice.invoice_id;
    document.getElementById('edit_supplier_name').value = invoice.supplier_name;
    document.getElementById('edit_invoice_date').value = invoice.invoice_date;
    document.getElementById('edit_total_amount').value = invoice.total_amount;
    
    new bootstrap.Modal(document.getElementById('editInvoiceModal')).show();
}

function printCheque(chequeNumber, supplierName, amount) {
    document.getElementById('cheque_number').textContent = chequeNumber;
    document.getElementById('cheque_payee').textContent = supplierName;
    document.getElementById('cheque_amount').textContent = amount.toFixed(2);
    document.getElementById('cheque_amount_words').textContent = numberToWords(amount) + ' only';
    
    new bootstrap.Modal(document.getElementById('chequeModal')).show();
}

function numberToWords(amount) {
    // Simple number to words conversion for demonstration
    const ones = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine'];
    const teens = ['ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
    const tens = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
    
    if (amount === 0) return 'zero';
    
    let words = '';
    const integerPart = Math.floor(amount);
    const decimalPart = Math.round((amount - integerPart) * 100);
    
    if (integerPart >= 1000) {
        const thousands = Math.floor(integerPart / 1000);
        words += convertHundreds(thousands) + ' thousand ';
    }
    
    words += convertHundreds(integerPart % 1000);
    
    if (decimalPart > 0) {
        words += ' and ' + decimalPart + '/100';
    }
    
    return words.trim();
    
    function convertHundreds(num) {
        let result = '';
        
        if (num >= 100) {
            result += ones[Math.floor(num / 100)] + ' hundred ';
            num %= 100;
        }
        
        if (num >= 20) {
            result += tens[Math.floor(num / 10)] + ' ';
            num %= 10;
        } else if (num >= 10) {
            result += teens[num - 10] + ' ';
            return result;
        }
        
        if (num > 0) {
            result += ones[num] + ' ';
        }
        
        return result;
    }
}

// Auto-fill supplier and amount when PO is selected
document.getElementById('po_id').addEventListener('change', function() {
    const option = this.options[this.selectedIndex];
    if (option.value) {
        document.getElementById('supplier_name').value = option.dataset.supplier || '';
        document.getElementById('total_amount').value = option.dataset.amount || '';
    }
});

function viewRelatedPO(poId) {
    // Open purchase order details in a new window
    window.open('/Restaurant_system/manager/inventory/purchase_orders.php?view_po=' + poId, '_blank');
}
</script>
";

require_once '../../common/footer.php';
?>