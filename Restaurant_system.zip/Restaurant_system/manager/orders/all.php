<?php
// Manager - All Orders View
$page_title = 'All Orders';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/manager/'],
    ['title' => 'All Orders', 'url' => '']
];

require_once '../../common/header.php';
requireRole('manager');

// Handle form submissions
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!validateCSRFToken($csrf_token)) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        try {
            $pdo = getPDO();
            
            switch ($action) {
                case 'update_status':
                    $order_id = intval($_POST['order_id']);
                    $new_status = $_POST['new_status'];
                    
                    // Validate status
                    $valid_statuses = ['pending', 'preparing', 'ready', 'served', 'cancelled'];
                    if (!in_array($new_status, $valid_statuses)) {
                        throw new Exception('Invalid order status.');
                    }
                    
                    // Get order details
                    $stmt = $pdo->prepare("SELECT * FROM orders WHERE order_id = ?");
                    $stmt->execute([$order_id]);
                    $order = $stmt->fetch();
                    
                    if (!$order) {
                        throw new Exception('Order not found.');
                    }
                    
                    // Update order status
                    $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
                    $stmt->execute([$new_status, $order_id]);
                    
                    logActivity('Order Status Updated', 'orders', $order_id, $order, [
                        'old_status' => $order['status'],
                        'new_status' => $new_status,
                        'order_number' => $order['order_number']
                    ]);
                    
                    $success_message = 'Order status updated successfully!';
                    break;
            }
            
        } catch (Exception $e) {
            $error_message = $e->getMessage();
            logError($error_message);
        }
    }
}

// Get filter parameters
$status_filter = $_GET['status'] ?? '';
$date_filter = $_GET['date'] ?? '';
$clerk_filter = $_GET['clerk'] ?? '';
$search = $_GET['search'] ?? '';

try {
    $pdo = getPDO();
    
    // Build query with filters
    $where_conditions = [];
    $params = [];
    
    if (!empty($status_filter)) {
        $where_conditions[] = "o.status = ?";
        $params[] = $status_filter;
    }
    
    if (!empty($date_filter)) {
        $where_conditions[] = "DATE(o.created_at) = ?";
        $params[] = $date_filter;
    }
    
    if (!empty($clerk_filter)) {
        $where_conditions[] = "o.created_by = ?";
        $params[] = $clerk_filter;
    }
    
    if (!empty($search)) {
        $where_conditions[] = "(o.order_number LIKE ? OR o.customer_name LIKE ? OR u.full_name LIKE ?)";
        $search_param = '%' . $search . '%';
        $params[] = $search_param;
        $params[] = $search_param;
        $params[] = $search_param;
    }
    
    $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
    
    // Get orders with filters
    $stmt = $pdo->prepare("
        SELECT o.*, u.full_name as clerk_name,
               COUNT(oi.id) as item_count
        FROM orders o
        JOIN users u ON o.created_by = u.user_id
        LEFT JOIN order_items oi ON o.order_id = oi.order_id
        $where_clause
        GROUP BY o.order_id
        ORDER BY o.created_at DESC
        LIMIT 100
    ");
    $stmt->execute($params);
    $orders = $stmt->fetchAll();
    
    // Get statistics
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_orders,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_orders,
            SUM(CASE WHEN status = 'preparing' THEN 1 ELSE 0 END) as preparing_orders,
            SUM(CASE WHEN status = 'ready' THEN 1 ELSE 0 END) as ready_orders,
            SUM(CASE WHEN status = 'served' THEN 1 ELSE 0 END) as served_orders,
            SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_orders,
            COALESCE(SUM(CASE WHEN status IN ('served', 'ready') THEN total_amount ELSE 0 END), 0) as total_revenue
        FROM orders o
        $where_clause
    ");
    $stmt->execute($params);
    $stats = $stmt->fetch();
    
    // Get sales clerks for filter
    $stmt = $pdo->prepare("
        SELECT user_id, full_name 
        FROM users 
        WHERE role = 'sales_clerk' AND status = 'active'
        ORDER BY full_name
    ");
    $stmt->execute();
    $sales_clerks = $stmt->fetchAll();
    
} catch (Exception $e) {
    $error_message = "Error loading orders data: " . $e->getMessage();
    $orders = [];
    $stats = [];
}

$csrf_token = generateCSRFToken();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">All Orders</h1>
        <p class="text-muted">View and manage all restaurant orders</p>
    </div>
    <div>
        <a href="/Restaurant_system/sales_clerk/orders/take_order.php" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>New Order
        </a>
    </div>
</div>

<?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i>
        <?php echo htmlspecialchars($success_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error_message): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-2 col-md-4 mb-3">
        <div class="stats-card">
            <div class="text-center">
                <h4 class="text-primary mb-1"><?php echo $stats['total_orders'] ?? 0; ?></h4>
                <small class="text-muted">Total Orders</small>
            </div>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 mb-3">
        <div class="stats-card">
            <div class="text-center">
                <h4 class="text-warning mb-1"><?php echo $stats['pending_orders'] ?? 0; ?></h4>
                <small class="text-muted">Pending</small>
            </div>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 mb-3">
        <div class="stats-card">
            <div class="text-center">
                <h4 class="text-info mb-1"><?php echo $stats['preparing_orders'] ?? 0; ?></h4>
                <small class="text-muted">Preparing</small>
            </div>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 mb-3">
        <div class="stats-card">
            <div class="text-center">
                <h4 class="text-primary mb-1"><?php echo $stats['ready_orders'] ?? 0; ?></h4>
                <small class="text-muted">Ready</small>
            </div>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 mb-3">
        <div class="stats-card">
            <div class="text-center">
                <h4 class="text-success mb-1"><?php echo $stats['served_orders'] ?? 0; ?></h4>
                <small class="text-muted">Served</small>
            </div>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 mb-3">
        <div class="stats-card">
            <div class="text-center">
                <h4 class="text-success mb-1"><?php echo formatCurrency($stats['total_revenue'] ?? 0); ?></h4>
                <small class="text-muted">Revenue</small>
            </div>
        </div>
    </div>
</div>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-filter me-2"></i>Filters
        </h5>
    </div>
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="">All Statuses</option>
                    <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                    <option value="preparing" <?php echo $status_filter === 'preparing' ? 'selected' : ''; ?>>Preparing</option>
                    <option value="ready" <?php echo $status_filter === 'ready' ? 'selected' : ''; ?>>Ready</option>
                    <option value="served" <?php echo $status_filter === 'served' ? 'selected' : ''; ?>>Served</option>
                    <option value="cancelled" <?php echo $status_filter === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                </select>
            </div>
            
            <div class="col-md-3">
                <label for="date" class="form-label">Date</label>
                <input type="date" class="form-control" id="date" name="date" value="<?php echo htmlspecialchars($date_filter); ?>">
            </div>
            
            <div class="col-md-3">
                <label for="clerk" class="form-label">Sales Clerk</label>
                <select class="form-select" id="clerk" name="clerk">
                    <option value="">All Clerks</option>
                    <?php foreach ($sales_clerks as $clerk): ?>
                        <option value="<?php echo $clerk['user_id']; ?>" <?php echo $clerk_filter == $clerk['user_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($clerk['full_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-3">
                <label for="search" class="form-label">Search</label>
                <input type="text" class="form-control" id="search" name="search" 
                       placeholder="Order #, Customer, Clerk..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
            
            <div class="col-12">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search me-2"></i>Apply Filters
                </button>
                <a href="/Restaurant_system/manager/orders/all.php" class="btn btn-outline-secondary">
                    <i class="fas fa-times me-2"></i>Clear Filters
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Orders Table -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-list me-2"></i>
            Orders List
        </h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover data-table">
                <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Customer</th>
                        <th>Items</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Sales Clerk</th>
                        <th>Date/Time</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($order['order_number']); ?></strong>
                            </td>
                            <td>
                                <?php echo htmlspecialchars($order['customer_name'] ?: 'Walk-in'); ?>
                                <?php if ($order['customer_phone']): ?>
                                    <br><small class="text-muted"><?php echo htmlspecialchars($order['customer_phone']); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-info"><?php echo $order['item_count']; ?> items</span>
                            </td>
                            <td>
                                <strong><?php echo formatCurrency($order['total_amount']); ?></strong>
                            </td>
                            <td>
                                <?php
                                $status_classes = [
                                    'pending' => 'warning',
                                    'preparing' => 'info',
                                    'ready' => 'primary',
                                    'served' => 'success',
                                    'cancelled' => 'danger'
                                ];
                                ?>
                                <span class="badge bg-<?php echo $status_classes[$order['status']] ?? 'secondary'; ?>">
                                    <?php echo ucfirst($order['status']); ?>
                                </span>
                            </td>
                            <td>
                                <?php echo htmlspecialchars($order['clerk_name']); ?>
                            </td>
                            <td>
                                <small><?php echo formatDisplayDateTime($order['created_at']); ?></small>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <button type="button" class="btn btn-sm btn-outline-info" 
                                            onclick="viewOrderDetails(<?php echo $order['order_id']; ?>)">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <?php if (in_array($order['status'], ['pending', 'preparing', 'ready'])): ?>
                                        <button type="button" class="btn btn-sm btn-outline-primary" 
                                                onclick="updateOrderStatus(<?php echo $order['order_id']; ?>, '<?php echo $order['status']; ?>')">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Update Status Modal -->
<div class="modal fade" id="updateStatusModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-edit me-2"></i>Update Order Status
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="update_status">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="order_id" id="update_order_id">
                
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="new_status" class="form-label">New Status</label>
                        <select class="form-select" id="new_status" name="new_status" required>
                            <option value="pending">Pending</option>
                            <option value="preparing">Preparing</option>
                            <option value="ready">Ready</option>
                            <option value="served">Served</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Update Status
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Order Details Modal -->
<div class="modal fade" id="orderDetailsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-receipt me-2"></i>Order Details
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="orderDetailsContent">
                <div class="text-center">
                    <div class="spinner-border" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function updateOrderStatus(orderId, currentStatus) {
    document.getElementById('update_order_id').value = orderId;
    document.getElementById('new_status').value = currentStatus;
    
    new bootstrap.Modal(document.getElementById('updateStatusModal')).show();
}

function viewOrderDetails(orderId) {
    const modal = new bootstrap.Modal(document.getElementById('orderDetailsModal'));
    modal.show();
    
    // Load order details via AJAX
    fetch('/Restaurant_system/api/order_details.php?order_id=' + orderId)
        .then(response => response.text())
        .then(data => {
            document.getElementById('orderDetailsContent').innerHTML = data;
        })
        .catch(error => {
            document.getElementById('orderDetailsContent').innerHTML = 
                '<div class="alert alert-danger">Error loading order details.</div>';
        });
}

// Initialize DataTable
document.addEventListener('DOMContentLoaded', function() {
    if (typeof $ !== 'undefined' && $.fn.DataTable) {
        $('.data-table').DataTable({
            responsive: true,
            pageLength: 25,
            order: [[6, 'desc']], // Sort by date/time descending
            columnDefs: [
                { orderable: false, targets: [7] } // Actions column
            ]
        });
    }
});

// Auto-refresh every 30 seconds
setInterval(function() {
    if (!document.querySelector('.modal.show')) {
        location.reload();
    }
}, 30000);
</script>

<?php require_once '../../common/footer.php'; ?>