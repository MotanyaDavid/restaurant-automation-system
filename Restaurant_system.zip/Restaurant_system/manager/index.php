<?php
// Manager Dashboard
$page_title = 'Manager Dashboard';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '']
];

require_once '../common/header.php';
requireRole('manager');

try {
    $pdo = getPDO();
    
    // Get dashboard statistics
    // Today's orders
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count, COALESCE(SUM(total_amount), 0) as revenue
        FROM orders 
        WHERE DATE(created_at) = CURDATE() 
        AND status IN ('served', 'ready')
    ");
    $stmt->execute();
    $today_stats = $stmt->fetch();
    
    // Pending orders
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count
        FROM orders 
        WHERE status IN ('pending', 'preparing')
    ");
    $stmt->execute();
    $pending_orders = $stmt->fetch()['count'];
    
    // Low stock items
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count 
        FROM ingredients 
        WHERE current_stock <= threshold_quantity
    ");
    $stmt->execute();
    $low_stock_count = $stmt->fetch()['count'];
    
    // Sales clerks count
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count 
        FROM users 
        WHERE role = 'sales_clerk' AND status = 'active'
    ");
    $stmt->execute();
    $sales_clerks_count = $stmt->fetch()['count'];
    
    // Menu items count
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total, 
               SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) as available
        FROM menu_items
    ");
    $stmt->execute();
    $menu_stats = $stmt->fetch();
    
    // Recent orders
    $stmt = $pdo->prepare("
        SELECT o.order_id, o.order_number, o.customer_name, o.total_amount, 
               o.status, o.created_at, u.full_name as clerk_name
        FROM orders o
        JOIN users u ON o.created_by = u.user_id
        ORDER BY o.created_at DESC
        LIMIT 8
    ");
    $stmt->execute();
    $recent_orders = $stmt->fetchAll();
    
    // Low stock ingredients
    $stmt = $pdo->prepare("
        SELECT ingredient_name, ingredient_code, current_stock, threshold_quantity, unit
        FROM ingredients 
        WHERE current_stock <= threshold_quantity
        ORDER BY (current_stock / threshold_quantity) ASC
        LIMIT 5
    ");
    $stmt->execute();
    $low_stock_items = $stmt->fetchAll();
    
    // Top selling items today
    $stmt = $pdo->prepare("
        SELECT mi.item_name, SUM(oi.quantity) as total_sold, SUM(oi.subtotal) as revenue
        FROM order_items oi
        JOIN menu_items mi ON oi.item_id = mi.item_id
        JOIN orders o ON oi.order_id = o.order_id
        WHERE DATE(o.created_at) = CURDATE() AND o.status IN ('served', 'ready')
        GROUP BY mi.item_id
        ORDER BY total_sold DESC
        LIMIT 5
    ");
    $stmt->execute();
    $top_items = $stmt->fetchAll();
    
    // Available funds
    $available_funds = getAvailableFunds();
    
} catch (Exception $e) {
    $error_message = "Error loading dashboard data: " . $e->getMessage();
    logError($error_message);
}

$auto_refresh = true; // Enable auto-refresh for dashboard
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Manager Dashboard</h1>
        <p class="text-muted">Welcome back, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</p>
    </div>
    <div class="text-end">
        <div class="current-date text-muted small"></div>
        <div class="current-time fw-bold"></div>
    </div>
</div>

<?php if (isset($error_message)): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
    </div>
<?php endif; ?>

<!-- Key Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon success me-3">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Today's Revenue</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($today_stats['revenue'] ?? 0); ?></h4>
                    <small class="text-muted"><?php echo $today_stats['count'] ?? 0; ?> orders</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon warning me-3">
                    <i class="fas fa-clock"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Pending Orders</h6>
                    <h4 class="mb-0"><?php echo $pending_orders ?? 0; ?></h4>
                    <small class="text-muted">Need attention</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon danger me-3">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Low Stock Items</h6>
                    <h4 class="mb-0"><?php echo $low_stock_count ?? 0; ?></h4>
                    <small class="text-muted">Need restocking</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon primary me-3">
                    <i class="fas fa-users"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Active Sales Clerks</h6>
                    <h4 class="mb-0"><?php echo $sales_clerks_count ?? 0; ?></h4>
                    <small class="text-muted">Staff members</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-bolt me-2"></i>
                    Quick Actions
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-2 mb-2">
                        <a href="/Restaurant_system/manager/menu/manage.php" class="btn btn-outline-primary w-100">
                            <i class="fas fa-utensils me-2"></i>
                            Menu
                        </a>
                    </div>
                    <div class="col-md-2 mb-2">
                        <a href="/Restaurant_system/manager/inventory/stock.php" class="btn btn-outline-warning w-100">
                            <i class="fas fa-boxes me-2"></i>
                            Inventory
                        </a>
                    </div>
                    <div class="col-md-2 mb-2">
                        <a href="/Restaurant_system/manager/inventory/purchase_orders.php" class="btn btn-outline-info w-100">
                            <i class="fas fa-shopping-cart me-2"></i>
                            Purchase Orders
                        </a>
                    </div>
                    <div class="col-md-2 mb-2">
                        <a href="/Restaurant_system/manager/users/clerks.php" class="btn btn-outline-success w-100">
                            <i class="fas fa-user-friends me-2"></i>
                            Staff
                        </a>
                    </div>
                    <div class="col-md-2 mb-2">
                        <a href="/Restaurant_system/manager/invoices/process.php" class="btn btn-outline-secondary w-100">
                            <i class="fas fa-file-invoice me-2"></i>
                            Invoices
                        </a>
                    </div>
                    <div class="col-md-2 mb-2">
                        <a href="/Restaurant_system/manager/reports/monthly.php" class="btn btn-outline-dark w-100">
                            <i class="fas fa-chart-bar me-2"></i>
                            Reports
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Main Content Row -->
<div class="row">
    <!-- Recent Orders -->
    <div class="col-lg-6 mb-3">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="fas fa-shopping-cart me-2"></i>
                    Recent Orders
                </h5>
                <a href="/Restaurant_system/manager/orders/all.php" class="btn btn-sm btn-outline-primary">
                    View All
                </a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Order #</th>
                                <th>Customer</th>
                                <th>Amount</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_orders)): ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted py-3">
                                        No recent orders found
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($recent_orders as $order): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($order['order_number']); ?></strong>
                                            <br>
                                            <small class="text-muted">by <?php echo htmlspecialchars($order['clerk_name']); ?></small>
                                        </td>
                                        <td><?php echo htmlspecialchars($order['customer_name'] ?: 'Walk-in'); ?></td>
                                        <td><?php echo formatCurrency($order['total_amount']); ?></td>
                                        <td>
                                            <?php
                                            $status_class = [
                                                'pending' => 'warning',
                                                'preparing' => 'info',
                                                'ready' => 'primary',
                                                'served' => 'success',
                                                'cancelled' => 'danger'
                                            ];
                                            ?>
                                            <span class="badge bg-<?php echo $status_class[$order['status']] ?? 'secondary'; ?>">
                                                <?php echo ucfirst($order['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Low Stock Alert -->
    <div class="col-lg-6 mb-3">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="fas fa-exclamation-triangle me-2 text-warning"></i>
                    Low Stock Alert
                </h5>
                <a href="/Restaurant_system/manager/inventory/stock.php" class="btn btn-sm btn-outline-warning">
                    View All
                </a>
            </div>
            <div class="card-body">
                <?php if (empty($low_stock_items)): ?>
                    <div class="text-center text-success py-3">
                        <i class="fas fa-check-circle fa-2x mb-2"></i>
                        <p class="mb-0">All items are well stocked!</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($low_stock_items as $item): ?>
                        <div class="d-flex justify-content-between align-items-center mb-2 p-2 bg-light rounded">
                            <div>
                                <strong><?php echo htmlspecialchars($item['ingredient_name']); ?></strong>
                                <br>
                                <small class="text-muted"><?php echo htmlspecialchars($item['ingredient_code']); ?></small>
                            </div>
                            <div class="text-end">
                                <span class="badge bg-danger">
                                    <?php echo $item['current_stock']; ?> <?php echo $item['unit']; ?>
                                </span>
                                <br>
                                <small class="text-muted">Min: <?php echo $item['threshold_quantity']; ?></small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Additional Info Row -->
<div class="row">
    <!-- Top Selling Items -->
    <div class="col-lg-6 mb-3">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-trophy me-2"></i>
                    Top Selling Items Today
                </h5>
            </div>
            <div class="card-body">
                <?php if (empty($top_items)): ?>
                    <p class="text-center text-muted py-3 mb-0">No sales data for today</p>
                <?php else: ?>
                    <?php foreach ($top_items as $index => $item): ?>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div class="d-flex align-items-center">
                                <span class="badge bg-primary me-2"><?php echo $index + 1; ?></span>
                                <span><?php echo htmlspecialchars($item['item_name']); ?></span>
                            </div>
                            <div class="text-end">
                                <strong><?php echo $item['total_sold']; ?> sold</strong>
                                <br>
                                <small class="text-muted"><?php echo formatCurrency($item['revenue']); ?></small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- System Info -->
    <div class="col-lg-6 mb-3">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-info-circle me-2"></i>
                    System Information
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-6">
                        <div class="text-center p-3 bg-light rounded mb-3">
                            <h4 class="text-primary mb-1"><?php echo $menu_stats['total'] ?? 0; ?></h4>
                            <small class="text-muted">Total Menu Items</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="text-center p-3 bg-light rounded mb-3">
                            <h4 class="text-success mb-1"><?php echo $menu_stats['available'] ?? 0; ?></h4>
                            <small class="text-muted">Available Items</small>
                        </div>
                    </div>
                </div>
                
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted">Available Funds</span>
                    <strong class="text-success"><?php echo formatCurrency($available_funds); ?></strong>
                </div>
                
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted">Active Staff</span>
                    <strong><?php echo $sales_clerks_count; ?> Sales Clerks</strong>
                </div>
                
                <div class="d-flex justify-content-between align-items-center">
                    <span class="text-muted">System Status</span>
                    <span class="badge bg-success">Online</span>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../common/footer.php'; ?>