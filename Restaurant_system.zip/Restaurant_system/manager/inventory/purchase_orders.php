<?php
// Manager - Purchase Orders Management
$page_title = 'Purchase Orders';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/manager/'],
    ['title' => 'Purchase Orders', 'url' => '']
];

require_once '../../common/header.php';
requireRole('manager');

// Handle form submissions
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!validateCSRFToken($csrf_token)) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        try {
            $pdo = getPDO();
            
            switch ($action) {
                case 'create_po':
                    $supplier_name = sanitizeInput($_POST['supplier_name']);
                    $po_items = $_POST['po_items'] ?? [];
                    
                    if (empty($supplier_name)) {
                        throw new Exception('Please enter supplier name.');
                    }
                    
                    if (empty($po_items)) {
                        throw new Exception('Please add at least one item to the purchase order.');
                    }
                    
                    // Validate and calculate total
                    $validated_items = [];
                    $total_amount = 0;
                    
                    foreach ($po_items as $item) {
                        $ingredient_id = intval($item['ingredient_id']);
                        $quantity = floatval($item['quantity']);
                        $unit_price = floatval($item['unit_price']);
                        
                        if ($quantity <= 0 || $unit_price <= 0) continue;
                        
                        // Get ingredient details
                        $stmt = $pdo->prepare("SELECT * FROM ingredients WHERE ingredient_id = ?");
                        $stmt->execute([$ingredient_id]);
                        $ingredient = $stmt->fetch();
                        
                        if (!$ingredient) {
                            throw new Exception('Invalid ingredient selected.');
                        }
                        
                        $subtotal = $quantity * $unit_price;
                        $total_amount += $subtotal;
                        
                        $validated_items[] = [
                            'ingredient_id' => $ingredient_id,
                            'quantity' => $quantity,
                            'unit_price' => $unit_price,
                            'subtotal' => $subtotal,
                            'ingredient_name' => $ingredient['ingredient_name']
                        ];
                    }
                    
                    if (empty($validated_items)) {
                        throw new Exception('No valid items in the purchase order.');
                    }
                    
                    // Check available funds
                    $available_funds = getAvailableFunds();
                    if ($available_funds < $total_amount) {
                        throw new Exception("Insufficient funds. Available: " . formatCurrency($available_funds) . ", Required: " . formatCurrency($total_amount));
                    }
                    
                    $pdo->beginTransaction();
                    
                    // Generate PO number
                    $po_number = generatePONumber();
                    
                    // Insert purchase order
                    $stmt = $pdo->prepare("
                        INSERT INTO purchase_orders (po_number, supplier_name, total_amount, created_by)
                        VALUES (?, ?, ?, ?)
                    ");
                    $stmt->execute([$po_number, $supplier_name, $total_amount, $_SESSION['user_id']]);
                    $po_id = $pdo->lastInsertId();
                    
                    // Insert PO items
                    $stmt = $pdo->prepare("
                        INSERT INTO purchase_order_items (po_id, ingredient_id, quantity, unit_price, subtotal)
                        VALUES (?, ?, ?, ?, ?)
                    ");
                    
                    foreach ($validated_items as $item) {
                        $stmt->execute([
                            $po_id,
                            $item['ingredient_id'],
                            $item['quantity'],
                            $item['unit_price'],
                            $item['subtotal']
                        ]);
                    }
                    
                    $pdo->commit();
                    
                    logActivity('Purchase Order Created', 'purchase_orders', $po_id, null, [
                        'po_number' => $po_number,
                        'supplier_name' => $supplier_name,
                        'total_amount' => $total_amount,
                        'items_count' => count($validated_items)
                    ]);
                    
                    $success_message = "Purchase Order #{$po_number} created successfully! Total: " . formatCurrency($total_amount);
                    break;
                    
                case 'update_status':
                    $po_id = intval($_POST['po_id']);
                    $new_status = $_POST['status'];
                    
                    if (!in_array($new_status, ['pending', 'ordered', 'received', 'paid'])) {
                        throw new Exception('Invalid status selected.');
                    }
                    
                    // Get PO details
                    $stmt = $pdo->prepare("SELECT * FROM purchase_orders WHERE po_id = ?");
                    $stmt->execute([$po_id]);
                    $po = $stmt->fetch();
                    
                    if (!$po) {
                        throw new Exception('Purchase order not found.');
                    }
                    
                    $pdo->beginTransaction();
                    
                    // Update status
                    $stmt = $pdo->prepare("UPDATE purchase_orders SET status = ? WHERE po_id = ?");
                    $stmt->execute([$new_status, $po_id]);
                    
                    // If status is 'received', update ingredient stock
                    if ($new_status === 'received' && $po['status'] !== 'received') {
                        $stmt = $pdo->prepare("
                            SELECT poi.*, i.ingredient_name
                            FROM purchase_order_items poi
                            JOIN ingredients i ON poi.ingredient_id = i.ingredient_id
                            WHERE poi.po_id = ?
                        ");
                        $stmt->execute([$po_id]);
                        $po_items = $stmt->fetchAll();
                        
                        foreach ($po_items as $item) {
                            // Update ingredient stock
                            updateIngredientStock(
                                $item['ingredient_id'],
                                $item['quantity'],
                                'in',
                                'purchase',
                                $po_id,
                                $_SESSION['user_id'],
                                "Stock received from PO #{$po['po_number']}"
                            );
                        }
                    }
                    
                    $pdo->commit();
                    
                    logActivity('Purchase Order Status Updated', 'purchase_orders', $po_id, 
                        ['status' => $po['status']], 
                        ['status' => $new_status]
                    );
                    
                    $success_message = "Purchase order status updated to " . ucfirst($new_status);
                    break;
            }
            
        } catch (Exception $e) {
            if (isset($pdo) && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error_message = $e->getMessage();
            logError($error_message);
        }
    }
}

try {
    $pdo = getPDO();
    
    // Get all purchase orders
    $stmt = $pdo->prepare("
        SELECT po.*, u.full_name as created_by_name,
               COUNT(poi.id) as items_count
        FROM purchase_orders po
        JOIN users u ON po.created_by = u.user_id
        LEFT JOIN purchase_order_items poi ON po.po_id = poi.po_id
        GROUP BY po.po_id
        ORDER BY po.created_at DESC
    ");
    $stmt->execute();
    $purchase_orders = $stmt->fetchAll();
    
    // Get low stock ingredients for auto-generation
    $low_stock_items = getLowStockIngredients();
    
    // Get all ingredients for manual PO creation
    $stmt = $pdo->prepare("
        SELECT ingredient_id, ingredient_name, ingredient_code, unit, current_stock, 
               threshold_quantity, unit_price
        FROM ingredients
        ORDER BY ingredient_name
    ");
    $stmt->execute();
    $all_ingredients = $stmt->fetchAll();
    
    // Get available funds
    $available_funds = getAvailableFunds();
    
    // Calculate statistics
    $total_pos = count($purchase_orders);
    $pending_pos = count(array_filter($purchase_orders, function($po) { return $po['status'] === 'pending'; }));
    $total_pending_amount = array_sum(array_map(function($po) { 
        return $po['status'] === 'pending' ? $po['total_amount'] : 0; 
    }, $purchase_orders));
    
} catch (Exception $e) {
    $error_message = "Error loading purchase orders: " . $e->getMessage();
    $purchase_orders = [];
    $low_stock_items = [];
    $all_ingredients = [];
}

$csrf_token = generateCSRFToken();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Purchase Orders</h1>
        <p class="text-muted">Manage supplier orders and inventory restocking</p>
    </div>
    <div>
        <?php if (!empty($low_stock_items)): ?>
            <button type="button" class="btn btn-warning me-2" onclick="generateAutoPO()">
                <i class="fas fa-magic me-2"></i>Auto Generate PO
            </button>
        <?php endif; ?>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createPOModal">
            <i class="fas fa-plus me-2"></i>Create Purchase Order
        </button>
    </div>
</div>

<?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i>
        <?php echo htmlspecialchars($success_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error_message): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon primary me-3">
                    <i class="fas fa-file-alt"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Total Purchase Orders</h6>
                    <h4 class="mb-0"><?php echo $total_pos; ?></h4>
                    <small class="text-muted">All time</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon warning me-3">
                    <i class="fas fa-clock"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Pending Orders</h6>
                    <h4 class="mb-0"><?php echo $pending_pos; ?></h4>
                    <small class="text-muted">Awaiting processing</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon danger me-3">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Low Stock Items</h6>
                    <h4 class="mb-0"><?php echo count($low_stock_items); ?></h4>
                    <small class="text-muted">Need restocking</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon success me-3">
                    <i class="fas fa-wallet"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Available Funds</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($available_funds); ?></h4>
                    <small class="text-muted">For purchases</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Low Stock Alert -->
<?php if (!empty($low_stock_items)): ?>
    <div class="alert alert-warning">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <i class="fas fa-exclamation-triangle me-2"></i>
                <strong><?php echo count($low_stock_items); ?> ingredients are running low on stock!</strong>
            </div>
            <button type="button" class="btn btn-sm btn-warning" onclick="generateAutoPO()">
                Generate Auto PO
            </button>
        </div>
    </div>
<?php endif; ?>

<!-- Purchase Orders Table -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-list me-2"></i>
            Purchase Orders
        </h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover data-table">
                <thead>
                    <tr>
                        <th>PO Number</th>
                        <th>Supplier</th>
                        <th>Items</th>
                        <th>Total Amount</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($purchase_orders as $po): ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($po['po_number']); ?></strong>
                            </td>
                            <td><?php echo htmlspecialchars($po['supplier_name']); ?></td>
                            <td>
                                <span class="badge bg-info"><?php echo $po['items_count']; ?> items</span>
                            </td>
                            <td>
                                <strong class="text-success"><?php echo formatCurrency($po['total_amount']); ?></strong>
                            </td>
                            <td>
                                <?php
                                $status_classes = [
                                    'pending' => 'warning',
                                    'ordered' => 'info',
                                    'received' => 'primary',
                                    'paid' => 'success'
                                ];
                                ?>
                                <span class="badge bg-<?php echo $status_classes[$po['status']] ?? 'secondary'; ?>">
                                    <?php echo ucfirst($po['status']); ?>
                                </span>
                            </td>
                            <td>
                                <div><?php echo formatDisplayDate($po['created_at']); ?></div>
                                <small class="text-muted">by <?php echo htmlspecialchars($po['created_by_name']); ?></small>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <button type="button" class="btn btn-sm btn-outline-info"
                                            onclick="viewPO(<?php echo $po['po_id']; ?>)">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-secondary"
                                            onclick="printPO(<?php echo $po['po_id']; ?>)">
                                        <i class="fas fa-print"></i>
                                    </button>
                                    <?php if ($po['status'] !== 'paid'): ?>
                                        <button type="button" class="btn btn-sm btn-outline-primary"
                                                onclick="updateStatus(<?php echo $po['po_id']; ?>, '<?php echo $po['status']; ?>')">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                    <?php endif; ?>
                                    <?php if ($po['status'] === 'ordered'): ?>
                                        <button type="button" class="btn btn-sm btn-success"
                                                onclick="markReceived(<?php echo $po['po_id']; ?>)">
                                            <i class="fas fa-check"></i> Received
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Create PO Modal -->
<div class="modal fade" id="createPOModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-plus me-2"></i>Create Purchase Order
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="create_po">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                
                <div class="modal-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="supplier_name" class="form-label">Supplier Name *</label>
                            <input type="text" class="form-control" id="supplier_name" name="supplier_name" required>
                            <div class="invalid-feedback">Please enter supplier name.</div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Available Funds</label>
                            <div class="form-control-plaintext">
                                <strong class="text-success"><?php echo formatCurrency($available_funds); ?></strong>
                            </div>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <div class="mb-3">
                        <label class="form-label">Purchase Order Items</label>
                        <div id="poItemsList">
                            <div class="po-item-row row mb-2 p-2 border rounded">
                                <div class="col-md-4">
                                    <select class="form-select" name="po_items[0][ingredient_id]" required>
                                        <option value="">Select Ingredient</option>
                                        <?php foreach ($all_ingredients as $ingredient): ?>
                                            <option value="<?php echo $ingredient['ingredient_id']; ?>" 
                                                    data-unit="<?php echo htmlspecialchars($ingredient['unit']); ?>"
                                                    data-current="<?php echo $ingredient['current_stock']; ?>"
                                                    data-threshold="<?php echo $ingredient['threshold_quantity']; ?>"
                                                    data-price="<?php echo $ingredient['unit_price']; ?>">
                                                <?php echo htmlspecialchars($ingredient['ingredient_name']); ?> 
                                                (<?php echo htmlspecialchars($ingredient['unit']); ?>)
                                                - Stock: <?php echo $ingredient['current_stock']; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <input type="number" class="form-control quantity-input" 
                                           name="po_items[0][quantity]" placeholder="Quantity" 
                                           step="0.01" min="0.01" required>
                                </div>
                                <div class="col-md-2">
                                    <input type="number" class="form-control price-input" 
                                           name="po_items[0][unit_price]" placeholder="Unit Price" 
                                           step="0.01" min="0.01" required>
                                </div>
                                <div class="col-md-2">
                                    <input type="text" class="form-control subtotal-display" 
                                           placeholder="Subtotal" readonly>
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-outline-danger" onclick="removePOItem(this)">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-outline-primary btn-sm" onclick="addPOItem()">
                            <i class="fas fa-plus me-1"></i>Add Item
                        </button>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 offset-md-6">
                            <div class="card bg-light">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <strong>Total Amount:</strong>
                                        <strong class="text-success" id="poTotalAmount">KES 0.00</strong>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="createPOBtn">
                        <i class="fas fa-save me-2"></i>Create Purchase Order
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Update Status Modal -->
<div class="modal fade" id="updateStatusModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-edit me-2"></i>Update PO Status
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="update_status">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="po_id" id="status_po_id">
                
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="status" class="form-label">New Status</label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="pending">Pending</option>
                            <option value="ordered">Ordered</option>
                            <option value="received">Received</option>
                            <option value="paid">Paid</option>
                        </select>
                    </div>
                    
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>Note:</strong> Setting status to "Received" will automatically update ingredient stock levels.
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Update Status
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View PO Modal -->
<div class="modal fade" id="viewPOModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-eye me-2"></i>Purchase Order Details
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="poDetailsContent">
                <div class="text-center">
                    <div class="spinner-border" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="printCurrentPO()">
                    <i class="fas fa-print me-2"></i>Print PO
                </button>
            </div>
        </div>
    </div>
</div>

<?php
$additional_js = "
<script>
let poItemCount = 1;

function addPOItem() {
    const poItemsList = document.getElementById('poItemsList');
    const newRow = document.createElement('div');
    newRow.className = 'po-item-row row mb-2 p-2 border rounded';
    newRow.innerHTML = `
        <div class='col-md-4'>
            <select class='form-select' name='po_items[\${poItemCount}][ingredient_id]' required>
                <option value=''>Select Ingredient</option>
                " . implode('', array_map(function($ingredient) {
                    return "<option value='{$ingredient['ingredient_id']}' " .
                           "data-unit='" . htmlspecialchars($ingredient['unit']) . "' " .
                           "data-current='{$ingredient['current_stock']}' " .
                           "data-threshold='{$ingredient['threshold_quantity']}' " .
                           "data-price='{$ingredient['unit_price']}'>" .
                           htmlspecialchars($ingredient['ingredient_name']) . " (" . 
                           htmlspecialchars($ingredient['unit']) . ") - Stock: {$ingredient['current_stock']}</option>";
                }, $all_ingredients)) . "
            </select>
        </div>
        <div class='col-md-2'>
            <input type='number' class='form-control quantity-input' 
                   name='po_items[\${poItemCount}][quantity]' placeholder='Quantity' 
                   step='0.01' min='0.01' required>
        </div>
        <div class='col-md-2'>
            <input type='number' class='form-control price-input' 
                   name='po_items[\${poItemCount}][unit_price]' placeholder='Unit Price' 
                   step='0.01' min='0.01' required>
        </div>
        <div class='col-md-2'>
            <input type='text' class='form-control subtotal-display' 
                   placeholder='Subtotal' readonly>
        </div>
        <div class='col-md-2'>
            <button type='button' class='btn btn-outline-danger' onclick='removePOItem(this)'>
                <i class='fas fa-minus'></i>
            </button>
        </div>
    `;
    poItemsList.appendChild(newRow);
    poItemCount++;
    
    // Add event listeners to new inputs
    addPOItemEventListeners(newRow);
}

function removePOItem(button) {
    const row = button.closest('.po-item-row');
    if (document.querySelectorAll('.po-item-row').length > 1) {
        row.remove();
        calculatePOTotal();
    }
}

function addPOItemEventListeners(row) {
    const select = row.querySelector('select');
    const quantityInput = row.querySelector('.quantity-input');
    const priceInput = row.querySelector('.price-input');
    
    select.addEventListener('change', function() {
        const option = this.options[this.selectedIndex];
        if (option.value) {
            priceInput.value = option.dataset.price || '';
            calculateRowSubtotal(row);
        }
    });
    
    quantityInput.addEventListener('input', () => calculateRowSubtotal(row));
    priceInput.addEventListener('input', () => calculateRowSubtotal(row));
}

function calculateRowSubtotal(row) {
    const quantity = parseFloat(row.querySelector('.quantity-input').value) || 0;
    const price = parseFloat(row.querySelector('.price-input').value) || 0;
    const subtotal = quantity * price;
    
    row.querySelector('.subtotal-display').value = 'KES ' + subtotal.toFixed(2);
    calculatePOTotal();
}

function calculatePOTotal() {
    let total = 0;
    document.querySelectorAll('.po-item-row').forEach(row => {
        const quantity = parseFloat(row.querySelector('.quantity-input').value) || 0;
        const price = parseFloat(row.querySelector('.price-input').value) || 0;
        total += quantity * price;
    });
    
    document.getElementById('poTotalAmount').textContent = 'KES ' + total.toFixed(2);
    
    // Check if total exceeds available funds
    const availableFunds = " . $available_funds . ";
    const createBtn = document.getElementById('createPOBtn');
    
    if (total > availableFunds) {
        createBtn.disabled = true;
        createBtn.innerHTML = '<i class=\"fas fa-exclamation-triangle me-2\"></i>Insufficient Funds';
        createBtn.className = 'btn btn-danger';
    } else {
        createBtn.disabled = false;
        createBtn.innerHTML = '<i class=\"fas fa-save me-2\"></i>Create Purchase Order';
        createBtn.className = 'btn btn-primary';
    }
}

function updateStatus(poId, currentStatus) {
    document.getElementById('status_po_id').value = poId;
    document.getElementById('status').value = currentStatus;
    
    new bootstrap.Modal(document.getElementById('updateStatusModal')).show();
}

function generateAutoPO() {
    // Pre-fill form with low stock items
    const modal = new bootstrap.Modal(document.getElementById('createPOModal'));
    
    // Clear existing items
    document.getElementById('poItemsList').innerHTML = '';
    poItemCount = 0;
    
    // Add low stock items
    " . json_encode($low_stock_items) . ".forEach((item, index) => {
        if (index === 0) {
            // Use first row
            const firstRow = document.querySelector('.po-item-row');
            if (firstRow) {
                const select = firstRow.querySelector('select');
                const quantityInput = firstRow.querySelector('.quantity-input');
                const priceInput = firstRow.querySelector('.price-input');
                
                select.value = item.ingredient_id;
                quantityInput.value = (item.threshold_quantity * 2).toFixed(2);
                priceInput.value = item.unit_price || '';
                
                calculateRowSubtotal(firstRow);
            }
        } else {
            addPOItem();
            const rows = document.querySelectorAll('.po-item-row');
            const newRow = rows[rows.length - 1];
            
            const select = newRow.querySelector('select');
            const quantityInput = newRow.querySelector('.quantity-input');
            const priceInput = newRow.querySelector('.price-input');
            
            select.value = item.ingredient_id;
            quantityInput.value = (item.threshold_quantity * 2).toFixed(2);
            priceInput.value = item.unit_price || '';
            
            calculateRowSubtotal(newRow);
        }
    });
    
    document.getElementById('supplier_name').value = 'Auto-Generated Supplier';
    modal.show();
}

function viewPO(poId) {
    const modal = new bootstrap.Modal(document.getElementById('viewPOModal'));
    modal.show();
    
    // Load PO details via AJAX
    fetch('/Restaurant_system/api/po_details.php?po_id=' + poId)
        .then(response => response.text())
        .then(data => {
            document.getElementById('poDetailsContent').innerHTML = data;
        })
        .catch(error => {
            document.getElementById('poDetailsContent').innerHTML =
                '<div class=\"alert alert-danger\">Error loading purchase order details.</div>';
        });
}

function printPO(poId) {
    window.open('/Restaurant_system/manager/inventory/print_po.php?po_id=' + poId, '_blank');
}

let currentPOId = null;

function printCurrentPO() {
    if (currentPOId) {
        printPO(currentPOId);
    }
}

function markReceived(poId) {
    if (confirm('Mark this purchase order as received? This will update ingredient stock levels.')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type=\"hidden\" name=\"action\" value=\"update_status\">
            <input type=\"hidden\" name=\"csrf_token\" value=\"<?php echo $csrf_token; ?>\">
            <input type=\"hidden\" name=\"po_id\" value=\"\${poId}\">
            <input type=\"hidden\" name=\"status\" value=\"received\">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}

// Initialize event listeners
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.po-item-row').forEach(addPOItemEventListeners);
    
    // Initialize DataTable
    if (typeof $ !== 'undefined' && $.fn.DataTable) {
        $('.data-table').DataTable({
            responsive: true,
            pageLength: 25,
            order: [[5, 'desc']], // Sort by created date descending
            columnDefs: [
                { orderable: false, targets: [6] } // Actions column
            ]
        });
    }
});
</script>
";

require_once '../../common/footer.php';
?>