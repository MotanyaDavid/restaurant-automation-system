<?php
// Manager - Ingredient Consumption Tracking
$page_title = 'Ingredient Consumption';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/manager/'],
    ['title' => 'Inventory', 'url' => '/Restaurant_system/manager/inventory/stock.php'],
    ['title' => 'Consumption', 'url' => '']
];

require_once '../../common/header.php';
requireRole('manager');

// Handle form submissions
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!validateCSRFToken($csrf_token)) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        try {
            $pdo = getPDO();
            
            switch ($action) {
                case 'update_recipe':
                    $menu_item_id = intval($_POST['menu_item_id']);
                    $ingredients = $_POST['ingredients'] ?? [];
                    
                    if (empty($menu_item_id) || empty($ingredients)) {
                        throw new Exception('Please select a menu item and add ingredients.');
                    }
                    
                    // Start transaction
                    $pdo->beginTransaction();
                    
                    try {
                        // Delete existing recipe ingredients
                        $stmt = $pdo->prepare("DELETE FROM recipe_ingredients WHERE menu_item_id = ?");
                        $stmt->execute([$menu_item_id]);
                        
                        // Insert new recipe ingredients
                        foreach ($ingredients as $ingredient) {
                            if (!empty($ingredient['ingredient_id']) && !empty($ingredient['quantity'])) {
                                $stmt = $pdo->prepare("
                                    INSERT INTO recipe_ingredients (menu_item_id, ingredient_id, quantity_required)
                                    VALUES (?, ?, ?)
                                ");
                                $stmt->execute([
                                    $menu_item_id,
                                    intval($ingredient['ingredient_id']),
                                    floatval($ingredient['quantity'])
                                ]);
                            }
                        }
                        
                        $pdo->commit();
                        
                        logActivity('Recipe Updated', 'recipe_ingredients', $menu_item_id, null, [
                            'menu_item_id' => $menu_item_id,
                            'ingredients_count' => count($ingredients)
                        ]);
                        
                        $success_message = 'Recipe updated successfully!';
                        
                    } catch (Exception $e) {
                        $pdo->rollBack();
                        throw $e;
                    }
                    break;
                    
                case 'process_consumption':
                    $order_id = intval($_POST['order_id']);
                    
                    if (empty($order_id)) {
                        throw new Exception('Please select an order to process.');
                    }
                    
                    // Get order items
                    $stmt = $pdo->prepare("
                        SELECT oi.*, mi.item_name
                        FROM order_items oi
                        JOIN menu_items mi ON oi.menu_item_id = mi.menu_item_id
                        WHERE oi.order_id = ?
                    ");
                    $stmt->execute([$order_id]);
                    $order_items = $stmt->fetchAll();
                    
                    if (empty($order_items)) {
                        throw new Exception('No items found for this order.');
                    }
                    
                    $pdo->beginTransaction();
                    
                    try {
                        $total_consumed = 0;
                        
                        foreach ($order_items as $item) {
                            // Get recipe ingredients for this menu item
                            $stmt = $pdo->prepare("
                                SELECT ri.*, i.ingredient_name, i.unit, i.current_stock
                                FROM recipe_ingredients ri
                                JOIN ingredients i ON ri.ingredient_id = i.ingredient_id
                                WHERE ri.menu_item_id = ?
                            ");
                            $stmt->execute([$item['menu_item_id']]);
                            $recipe_ingredients = $stmt->fetchAll();
                            
                            foreach ($recipe_ingredients as $recipe_ingredient) {
                                $consumption_quantity = $recipe_ingredient['quantity_required'] * $item['quantity'];
                                
                                // Check if enough stock is available
                                if ($recipe_ingredient['current_stock'] < $consumption_quantity) {
                                    throw new Exception(
                                        "Insufficient stock for {$recipe_ingredient['ingredient_name']}. " .
                                        "Required: {$consumption_quantity} {$recipe_ingredient['unit']}, " .
                                        "Available: {$recipe_ingredient['current_stock']} {$recipe_ingredient['unit']}"
                                    );
                                }
                                
                                // Update ingredient stock
                                updateIngredientStock(
                                    $recipe_ingredient['ingredient_id'],
                                    $consumption_quantity,
                                    'out',
                                    'usage',
                                    $order_id,
                                    $_SESSION['user_id'],
                                    "Used for {$item['item_name']} (Order #{$order_id})"
                                );
                                
                                $total_consumed++;
                            }
                        }
                        
                        // Mark order as processed for consumption
                        $stmt = $pdo->prepare("
                            UPDATE orders 
                            SET consumption_processed = 1, consumption_processed_at = NOW()
                            WHERE order_id = ?
                        ");
                        $stmt->execute([$order_id]);
                        
                        $pdo->commit();
                        
                        logActivity('Consumption Processed', 'orders', $order_id, null, [
                            'order_id' => $order_id,
                            'ingredients_consumed' => $total_consumed
                        ]);
                        
                        $success_message = "Consumption processed successfully! {$total_consumed} ingredient movements recorded.";
                        
                    } catch (Exception $e) {
                        $pdo->rollBack();
                        throw $e;
                    }
                    break;
                    
                case 'auto_process_consumption':
                    // Process consumption for all unprocessed completed orders
                    $stmt = $pdo->prepare("
                        SELECT order_id 
                        FROM orders 
                        WHERE status = 'completed' 
                        AND (consumption_processed = 0 OR consumption_processed IS NULL)
                        ORDER BY created_at ASC
                        LIMIT 50
                    ");
                    $stmt->execute();
                    $unprocessed_orders = $stmt->fetchAll();
                    
                    $processed_count = 0;
                    $error_count = 0;
                    
                    foreach ($unprocessed_orders as $order) {
                        try {
                            // Process each order individually
                            $_POST['order_id'] = $order['order_id'];
                            $_POST['action'] = 'process_consumption';
                            
                            // Recursive call to process_consumption case
                            $this_order_processed = false;
                            
                            // Get order items
                            $stmt = $pdo->prepare("
                                SELECT oi.*, mi.item_name
                                FROM order_items oi
                                JOIN menu_items mi ON oi.menu_item_id = mi.menu_item_id
                                WHERE oi.order_id = ?
                            ");
                            $stmt->execute([$order['order_id']]);
                            $order_items = $stmt->fetchAll();
                            
                            if (!empty($order_items)) {
                                $pdo->beginTransaction();
                                
                                try {
                                    foreach ($order_items as $item) {
                                        // Get recipe ingredients
                                        $stmt = $pdo->prepare("
                                            SELECT ri.*, i.ingredient_name, i.unit, i.current_stock
                                            FROM recipe_ingredients ri
                                            JOIN ingredients i ON ri.ingredient_id = i.ingredient_id
                                            WHERE ri.menu_item_id = ?
                                        ");
                                        $stmt->execute([$item['menu_item_id']]);
                                        $recipe_ingredients = $stmt->fetchAll();
                                        
                                        foreach ($recipe_ingredients as $recipe_ingredient) {
                                            $consumption_quantity = $recipe_ingredient['quantity_required'] * $item['quantity'];
                                            
                                            if ($recipe_ingredient['current_stock'] >= $consumption_quantity) {
                                                updateIngredientStock(
                                                    $recipe_ingredient['ingredient_id'],
                                                    $consumption_quantity,
                                                    'out',
                                                    'usage',
                                                    $order['order_id'],
                                                    $_SESSION['user_id'],
                                                    "Auto-processed consumption for {$item['item_name']}"
                                                );
                                            }
                                        }
                                    }
                                    
                                    // Mark as processed
                                    $stmt = $pdo->prepare("
                                        UPDATE orders 
                                        SET consumption_processed = 1, consumption_processed_at = NOW()
                                        WHERE order_id = ?
                                    ");
                                    $stmt->execute([$order['order_id']]);
                                    
                                    $pdo->commit();
                                    $processed_count++;
                                    
                                } catch (Exception $e) {
                                    $pdo->rollBack();
                                    $error_count++;
                                }
                            }
                            
                        } catch (Exception $e) {
                            $error_count++;
                        }
                    }
                    
                    logActivity('Auto Consumption Processing', null, null, null, [
                        'processed_orders' => $processed_count,
                        'error_orders' => $error_count
                    ]);
                    
                    $success_message = "Auto-processing completed! {$processed_count} orders processed, {$error_count} errors.";
                    break;
            }
            
        } catch (Exception $e) {
            $error_message = $e->getMessage();
            logError($error_message);
        }
    }
}

try {
    $pdo = getPDO();
    
    // Get consumption summary for today
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(DISTINCT sm.reference_id) as orders_processed,
            COUNT(*) as total_movements,
            SUM(sm.quantity) as total_quantity_consumed,
            COUNT(DISTINCT sm.ingredient_id) as ingredients_affected
        FROM stock_movements sm
        WHERE sm.movement_type = 'out' 
        AND sm.reference_type = 'usage'
        AND DATE(sm.created_at) = CURDATE()
    ");
    $stmt->execute();
    $consumption_summary = $stmt->fetch();
    
    // Get top consumed ingredients today
    $stmt = $pdo->prepare("
        SELECT 
            i.ingredient_name,
            i.unit,
            SUM(sm.quantity) as total_consumed,
            COUNT(*) as usage_count
        FROM stock_movements sm
        JOIN ingredients i ON sm.ingredient_id = i.ingredient_id
        WHERE sm.movement_type = 'out' 
        AND sm.reference_type = 'usage'
        AND DATE(sm.created_at) = CURDATE()
        GROUP BY sm.ingredient_id, i.ingredient_name, i.unit
        ORDER BY total_consumed DESC
        LIMIT 10
    ");
    $stmt->execute();
    $top_consumed = $stmt->fetchAll();
    
    // Get unprocessed orders
    $stmt = $pdo->prepare("
        SELECT o.*, u.full_name as clerk_name,
               (SELECT COUNT(*) FROM order_items WHERE order_id = o.order_id) as item_count
        FROM orders o
        JOIN users u ON o.created_by = u.user_id
        WHERE o.status = 'completed' 
        AND (o.consumption_processed = 0 OR o.consumption_processed IS NULL)
        ORDER BY o.created_at ASC
        LIMIT 20
    ");
    $stmt->execute();
    $unprocessed_orders = $stmt->fetchAll();
    
    // Get menu items for recipe management
    $stmt = $pdo->prepare("
        SELECT mi.*, 
               (SELECT COUNT(*) FROM recipe_ingredients WHERE menu_item_id = mi.menu_item_id) as ingredient_count
        FROM menu_items mi
        WHERE mi.is_available = 1
        ORDER BY mi.item_name
    ");
    $stmt->execute();
    $menu_items = $stmt->fetchAll();
    
    // Get all ingredients for recipe building
    $stmt = $pdo->prepare("
        SELECT ingredient_id, ingredient_name, unit, current_stock
        FROM ingredients
        ORDER BY ingredient_name
    ");
    $stmt->execute();
    $all_ingredients = $stmt->fetchAll();
    
    // Get recent consumption activities
    $stmt = $pdo->prepare("
        SELECT sm.*, i.ingredient_name, i.unit, u.full_name as user_name,
               o.order_number
        FROM stock_movements sm
        JOIN ingredients i ON sm.ingredient_id = i.ingredient_id
        JOIN users u ON sm.created_by = u.user_id
        LEFT JOIN orders o ON sm.reference_id = o.order_id AND sm.reference_type = 'usage'
        WHERE sm.movement_type = 'out' AND sm.reference_type = 'usage'
        ORDER BY sm.created_at DESC
        LIMIT 30
    ");
    $stmt->execute();
    $recent_consumption = $stmt->fetchAll();
    
} catch (Exception $e) {
    $error_message = "Error loading consumption data: " . $e->getMessage();
    $consumption_summary = [
        'orders_processed' => 0,
        'total_movements' => 0,
        'total_quantity_consumed' => 0,
        'ingredients_affected' => 0
    ];
    $top_consumed = [];
    $unprocessed_orders = [];
    $menu_items = [];
    $all_ingredients = [];
    $recent_consumption = [];
}

$csrf_token = generateCSRFToken();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Ingredient Consumption Tracking</h1>
        <p class="text-muted">Monitor and manage ingredient usage from orders</p>
    </div>
    <div>
        <button type="button" class="btn btn-warning me-2" onclick="autoProcessConsumption()">
            <i class="fas fa-cogs me-2"></i>Auto Process All
        </button>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#recipeModal">
            <i class="fas fa-utensils me-2"></i>Manage Recipes
        </button>
    </div>
</div>

<?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i>
        <?php echo htmlspecialchars($success_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error_message): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Consumption Summary Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon primary me-3">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Orders Processed</h6>
                    <h4 class="mb-0"><?php echo $consumption_summary['orders_processed']; ?></h4>
                    <small class="text-muted">Today</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon info me-3">
                    <i class="fas fa-exchange-alt"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Stock Movements</h6>
                    <h4 class="mb-0"><?php echo $consumption_summary['total_movements']; ?></h4>
                    <small class="text-muted">Consumption entries</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon warning me-3">
                    <i class="fas fa-cubes"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Ingredients Used</h6>
                    <h4 class="mb-0"><?php echo $consumption_summary['ingredients_affected']; ?></h4>
                    <small class="text-muted">Different ingredients</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon danger me-3">
                    <i class="fas fa-clock"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Pending Orders</h6>
                    <h4 class="mb-0"><?php echo count($unprocessed_orders); ?></h4>
                    <small class="text-muted">Need processing</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Unprocessed Orders Alert -->
<?php if (count($unprocessed_orders) > 0): ?>
    <div class="alert alert-warning">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <i class="fas fa-exclamation-triangle me-2"></i>
                <strong><?php echo count($unprocessed_orders); ?> completed orders need consumption processing!</strong>
            </div>
            <button type="button" class="btn btn-sm btn-warning" onclick="autoProcessConsumption()">
                Process All
            </button>
        </div>
    </div>
<?php endif; ?>

<div class="row">
    <!-- Top Consumed Ingredients -->
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-chart-bar me-2"></i>
                    Top Consumed Ingredients (Today)
                </h5>
            </div>
            <div class="card-body">
                <?php if (empty($top_consumed)): ?>
                    <p class="text-center text-muted py-3 mb-0">No consumption data for today</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Ingredient</th>
                                    <th>Total Used</th>
                                    <th>Usage Count</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($top_consumed as $ingredient): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($ingredient['ingredient_name']); ?></strong>
                                        </td>
                                        <td>
                                            <span class="text-danger">
                                                <?php echo number_format($ingredient['total_consumed'], 2); ?> 
                                                <?php echo htmlspecialchars($ingredient['unit']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-info"><?php echo $ingredient['usage_count']; ?></span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Unprocessed Orders -->
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-clock me-2"></i>
                    Unprocessed Orders
                </h5>
            </div>
            <div class="card-body">
                <?php if (empty($unprocessed_orders)): ?>
                    <p class="text-center text-muted py-3 mb-0">All orders are processed!</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm table-hover">
                            <thead>
                                <tr>
                                    <th>Order</th>
                                    <th>Items</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach (array_slice($unprocessed_orders, 0, 10) as $order): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($order['order_number']); ?></strong>
                                            <br>
                                            <small class="text-muted"><?php echo htmlspecialchars($order['clerk_name']); ?></small>
                                        </td>
                                        <td>
                                            <span class="badge bg-secondary"><?php echo $order['item_count']; ?> items</span>
                                        </td>
                                        <td>
                                            <small><?php echo formatDisplayDateTime($order['created_at']); ?></small>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-primary" 
                                                    onclick="processOrderConsumption(<?php echo $order['order_id']; ?>, '<?php echo htmlspecialchars($order['order_number']); ?>')">
                                                Process
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if (count($unprocessed_orders) > 10): ?>
                        <div class="text-center mt-2">
                            <small class="text-muted">
                                Showing 10 of <?php echo count($unprocessed_orders); ?> unprocessed orders
                            </small>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Recent Consumption Activities -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-history me-2"></i>
            Recent Consumption Activities
        </h5>
    </div>
    <div class="card-body">
        <?php if (empty($recent_consumption)): ?>
            <p class="text-center text-muted py-3 mb-0">No recent consumption activities</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Date/Time</th>
                            <th>Ingredient</th>
                            <th>Quantity Used</th>
                            <th>Order</th>
                            <th>User</th>
                            <th>Notes</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_consumption as $activity): ?>
                            <tr>
                                <td>
                                    <small><?php echo formatDisplayDateTime($activity['created_at']); ?></small>
                                </td>
                                <td>
                                    <strong><?php echo htmlspecialchars($activity['ingredient_name']); ?></strong>
                                </td>
                                <td>
                                    <span class="text-danger">
                                        -<?php echo number_format($activity['quantity'], 2); ?> 
                                        <?php echo htmlspecialchars($activity['unit']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($activity['order_number']): ?>
                                        <span class="badge bg-info"><?php echo htmlspecialchars($activity['order_number']); ?></span>
                                    <?php else: ?>
                                        <span class="text-muted">N/A</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <small><?php echo htmlspecialchars($activity['user_name']); ?></small>
                                </td>
                                <td>
                                    <small class="text-muted"><?php echo htmlspecialchars($activity['notes']); ?></small>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Recipe Management Modal -->
<div class="modal fade" id="recipeModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-utensils me-2"></i>Recipe Management
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-4">
                        <h6>Menu Items</h6>
                        <div class="list-group" id="menuItemsList">
                            <?php foreach ($menu_items as $item): ?>
                                <a href="#" class="list-group-item list-group-item-action" 
                                   onclick="loadRecipe(<?php echo $item['menu_item_id']; ?>, '<?php echo htmlspecialchars($item['item_name']); ?>')">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <strong><?php echo htmlspecialchars($item['item_name']); ?></strong>
                                            <br>
                                            <small class="text-muted"><?php echo formatCurrency($item['price']); ?></small>
                                        </div>
                                        <span class="badge bg-<?php echo $item['ingredient_count'] > 0 ? 'success' : 'warning'; ?>">
                                            <?php echo $item['ingredient_count']; ?> ingredients
                                        </span>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div id="recipeEditor" style="display: none;">
                            <h6>Recipe for: <span id="selectedItemName"></span></h6>
                            <form method="POST" id="recipeForm">
                                <input type="hidden" name="action" value="update_recipe">
                                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                <input type="hidden" name="menu_item_id" id="selectedMenuItemId">
                                
                                <div id="ingredientsList">
                                    <!-- Ingredients will be loaded here -->
                                </div>
                                
                                <div class="mt-3">
                                    <button type="button" class="btn btn-sm btn-outline-primary" onclick="addIngredientRow()">
                                        <i class="fas fa-plus me-2"></i>Add Ingredient
                                    </button>
                                    <button type="submit" class="btn btn-sm btn-primary">
                                        <i class="fas fa-save me-2"></i>Save Recipe
                                    </button>
                                </div>
                            </form>
                        </div>
                        <div id="recipeInstructions" class="text-center text-muted py-5">
                            <i class="fas fa-utensils fa-3x mb-3"></i>
                            <p>Select a menu item to manage its recipe</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// JavaScript functions for consumption tracking
let ingredientRowCounter = 0;
const allIngredients = <?php echo json_encode($all_ingredients); ?>;

function processOrderConsumption(orderId, orderNumber) {
    if (confirm(`Process consumption for order ${orderNumber}?`)) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="process_consumption">
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
            <input type="hidden" name="order_id" value="${orderId}">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}

function autoProcessConsumption() {
    if (confirm('This will automatically process consumption for all unprocessed completed orders. Continue?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="auto_process_consumption">
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}

function loadRecipe(menuItemId, itemName) {
    document.getElementById('selectedMenuItemId').value = menuItemId;
    document.getElementById('selectedItemName').textContent = itemName;
    document.getElementById('recipeInstructions').style.display = 'none';
    document.getElementById('recipeEditor').style.display = 'block';
    
    // Load existing recipe ingredients
    fetch(`/Restaurant_system/api/recipe_ingredients.php?menu_item_id=${menuItemId}`)
        .then(response => response.json())
        .then(data => {
            const ingredientsList = document.getElementById('ingredientsList');
            ingredientsList.innerHTML = '';
            ingredientRowCounter = 0;
            
            if (data.ingredients && data.ingredients.length > 0) {
                data.ingredients.forEach(ingredient => {
                    addIngredientRow(ingredient.ingredient_id, ingredient.quantity_required);
                });
            } else {
                addIngredientRow();
            }
        })
        .catch(error => {
            console.error('Error loading recipe:', error);
            addIngredientRow();
        });
}

function addIngredientRow(ingredientId = '', quantity = '') {
    ingredientRowCounter++;
    const ingredientsList = document.getElementById('ingredientsList');
    
    const row = document.createElement('div');
    row.className = 'row mb-2 ingredient-row';
    row.id = `ingredient-row-${ingredientRowCounter}`;
    
    let ingredientOptions = '<option value="">Select Ingredient</option>';
    allIngredients.forEach(ingredient => {
        const selected = ingredient.ingredient_id == ingredientId ? 'selected' : '';
        ingredientOptions += `<option value="${ingredient.ingredient_id}" ${selected}>
            ${ingredient.ingredient_name} (${ingredient.unit}) - Stock: ${ingredient.current_stock}
        </option>`;
    });
    
    row.innerHTML = `
        <div class="col-md-6">
            <select class="form-select" name="ingredients[${ingredientRowCounter}][ingredient_id]" required>
                ${ingredientOptions}
            </select>
        </div>
        <div class="col-md-4">
            <input type="number" class="form-control" name="ingredients[${ingredientRowCounter}][quantity]"
                   placeholder="Quantity required" step="0.01" min="0.01" value="${quantity}" required>
        </div>
        <div class="col-md-2">
            <button type="button" class="btn btn-outline-danger btn-sm" onclick="removeIngredientRow(${ingredientRowCounter})">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `;
    
    ingredientsList.appendChild(row);
}

function removeIngredientRow(rowId) {
    const row = document.getElementById(`ingredient-row-${rowId}`);
    if (row) {
        row.remove();
    }
}

// Auto-refresh consumption data every 3 minutes
setInterval(function() {
    if (!document.querySelector('.modal.show')) {
        location.reload();
    }
}, 180000);

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
    // Add initial ingredient row if recipe modal is opened without selection
    const recipeModal = document.getElementById('recipeModal');
    if (recipeModal) {
        recipeModal.addEventListener('shown.bs.modal', function() {
            if (document.getElementById('ingredientsList').children.length === 0) {
                addIngredientRow();
            }
        });
    }
});
</script>

<?php require_once '../../common/footer.php'; ?>