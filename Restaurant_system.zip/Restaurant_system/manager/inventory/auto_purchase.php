<?php
// Manager - Automatic Purchase Order Generation
$page_title = 'Auto Purchase Orders';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/manager/'],
    ['title' => 'Inventory', 'url' => '/Restaurant_system/manager/inventory/stock.php'],
    ['title' => 'Auto Purchase', 'url' => '']
];

require_once '../../common/header.php';
requireRole('manager');

// Handle form submissions
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!validateCSRFToken($csrf_token)) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        try {
            $pdo = getPDO();
            
            switch ($action) {
                case 'generate_auto_po':
                    $selected_ingredients = $_POST['ingredients'] ?? [];
                    $supplier_id = intval($_POST['supplier_id'] ?? 0);
                    $delivery_date = sanitizeInput($_POST['delivery_date']);
                    $notes = sanitizeInput($_POST['notes'] ?? '');
                    
                    if (empty($selected_ingredients)) {
                        throw new Exception('Please select at least one ingredient.');
                    }
                    
                    if (empty($delivery_date)) {
                        throw new Exception('Please select a delivery date.');
                    }
                    
                    // Start transaction
                    $pdo->beginTransaction();
                    
                    try {
                        // Generate PO number
                        $po_number = 'AUTO-PO-' . date('Ymd') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
                        
                        // Calculate total amount
                        $total_amount = 0;
                        $po_items = [];
                        
                        foreach ($selected_ingredients as $ingredient_id) {
                            // Get ingredient details
                            $stmt = $pdo->prepare("
                                SELECT i.*, 
                                       GREATEST(i.threshold_quantity * 3, 50) as suggested_quantity
                                FROM ingredients i 
                                WHERE i.ingredient_id = ?
                            ");
                            $stmt->execute([$ingredient_id]);
                            $ingredient = $stmt->fetch();
                            
                            if ($ingredient) {
                                $quantity = $ingredient['suggested_quantity'];
                                $unit_price = $ingredient['unit_price'];
                                $total_price = $quantity * $unit_price;
                                $total_amount += $total_price;
                                
                                $po_items[] = [
                                    'ingredient_id' => $ingredient_id,
                                    'ingredient_name' => $ingredient['ingredient_name'],
                                    'quantity' => $quantity,
                                    'unit_price' => $unit_price,
                                    'total_price' => $total_price,
                                    'unit' => $ingredient['unit']
                                ];
                            }
                        }
                        
                        if (empty($po_items)) {
                            throw new Exception('No valid ingredients found.');
                        }
                        
                        // Check fund availability
                        $stmt = $pdo->prepare("
                            SELECT available_funds 
                            FROM fund_management 
                            WHERE fund_type = 'purchase_orders' 
                            ORDER BY created_at DESC 
                            LIMIT 1
                        ");
                        $stmt->execute();
                        $fund_info = $stmt->fetch();
                        
                        if (!$fund_info || $fund_info['available_funds'] < $total_amount) {
                            throw new Exception('Insufficient funds available. Required: ' . formatCurrency($total_amount) . 
                                              ', Available: ' . formatCurrency($fund_info['available_funds'] ?? 0));
                        }
                        
                        // Create purchase order
                        $stmt = $pdo->prepare("
                            INSERT INTO purchase_orders (po_number, supplier_id, total_amount, delivery_date, 
                                                       status, notes, created_by, created_at)
                            VALUES (?, ?, ?, ?, 'pending', ?, ?, NOW())
                        ");
                        $stmt->execute([
                            $po_number, $supplier_id, $total_amount, $delivery_date, 
                            $notes, $_SESSION['user_id']
                        ]);
                        
                        $po_id = $pdo->lastInsertId();
                        
                        // Create purchase order items
                        foreach ($po_items as $item) {
                            $stmt = $pdo->prepare("
                                INSERT INTO purchase_order_items (po_id, ingredient_id, ingredient_name, 
                                                                 quantity, unit_price, total_price)
                                VALUES (?, ?, ?, ?, ?, ?)
                            ");
                            $stmt->execute([
                                $po_id, $item['ingredient_id'], $item['ingredient_name'],
                                $item['quantity'], $item['unit_price'], $item['total_price']
                            ]);
                        }
                        
                        // Update fund allocation
                        $stmt = $pdo->prepare("
                            UPDATE fund_management 
                            SET allocated_funds = allocated_funds + ?,
                                available_funds = available_funds - ?
                            WHERE fund_type = 'purchase_orders'
                            ORDER BY created_at DESC 
                            LIMIT 1
                        ");
                        $stmt->execute([$total_amount, $total_amount]);
                        
                        // Create fund transaction record
                        $stmt = $pdo->prepare("
                            INSERT INTO fund_transactions (fund_type, transaction_type, amount, 
                                                         reference_type, reference_id, description, 
                                                         created_by, created_at)
                            VALUES ('purchase_orders', 'allocation', ?, 'purchase_order', ?, ?, ?, NOW())
                        ");
                        $stmt->execute([
                            $total_amount, $po_id, 
                            "Auto-generated PO: {$po_number}", $_SESSION['user_id']
                        ]);
                        
                        $pdo->commit();
                        
                        logActivity('Auto Purchase Order Generated', 'purchase_orders', $po_id, null, [
                            'po_number' => $po_number,
                            'total_amount' => $total_amount,
                            'items_count' => count($po_items)
                        ]);
                        
                        $success_message = "Auto purchase order {$po_number} generated successfully! Total: " . formatCurrency($total_amount);
                        
                    } catch (Exception $e) {
                        $pdo->rollBack();
                        throw $e;
                    }
                    break;
                    
                case 'update_auto_settings':
                    $auto_generation_enabled = isset($_POST['auto_generation_enabled']) ? 1 : 0;
                    $threshold_multiplier = floatval($_POST['threshold_multiplier'] ?? 3);
                    $min_order_amount = floatval($_POST['min_order_amount'] ?? 1000);
                    $default_supplier_id = intval($_POST['default_supplier_id'] ?? 0);
                    $auto_delivery_days = intval($_POST['auto_delivery_days'] ?? 3);
                    
                    // Update or insert auto purchase settings
                    $stmt = $pdo->prepare("
                        INSERT INTO system_settings (setting_key, setting_value, updated_by, updated_at)
                        VALUES 
                            ('auto_po_enabled', ?, ?, NOW()),
                            ('auto_po_threshold_multiplier', ?, ?, NOW()),
                            ('auto_po_min_amount', ?, ?, NOW()),
                            ('auto_po_default_supplier', ?, ?, NOW()),
                            ('auto_po_delivery_days', ?, ?, NOW())
                        ON DUPLICATE KEY UPDATE
                            setting_value = VALUES(setting_value),
                            updated_by = VALUES(updated_by),
                            updated_at = VALUES(updated_at)
                    ");
                    $stmt->execute([
                        $auto_generation_enabled, $_SESSION['user_id'],
                        $threshold_multiplier, $_SESSION['user_id'],
                        $min_order_amount, $_SESSION['user_id'],
                        $default_supplier_id, $_SESSION['user_id'],
                        $auto_delivery_days, $_SESSION['user_id']
                    ]);
                    
                    logActivity('Auto Purchase Settings Updated', 'system_settings', null, null, [
                        'auto_enabled' => $auto_generation_enabled,
                        'threshold_multiplier' => $threshold_multiplier,
                        'min_order_amount' => $min_order_amount
                    ]);
                    
                    $success_message = 'Auto purchase settings updated successfully!';
                    break;
                    
                case 'run_auto_check':
                    // Run automatic check for low stock items
                    $auto_po_result = runAutoPurchaseCheck();
                    
                    if ($auto_po_result['success']) {
                        $success_message = $auto_po_result['message'];
                    } else {
                        $error_message = $auto_po_result['message'];
                    }
                    break;
            }
            
        } catch (Exception $e) {
            $error_message = $e->getMessage();
            logError($error_message);
        }
    }
}

try {
    $pdo = getPDO();
    
    // Get current auto purchase settings
    $stmt = $pdo->prepare("
        SELECT setting_key, setting_value 
        FROM system_settings 
        WHERE setting_key LIKE 'auto_po_%'
    ");
    $stmt->execute();
    $settings_data = $stmt->fetchAll();
    
    $auto_settings = [
        'auto_po_enabled' => 0,
        'auto_po_threshold_multiplier' => 3,
        'auto_po_min_amount' => 1000,
        'auto_po_default_supplier' => 0,
        'auto_po_delivery_days' => 3
    ];
    
    foreach ($settings_data as $setting) {
        $auto_settings[$setting['setting_key']] = $setting['setting_value'];
    }
    
    // Get low stock ingredients
    $stmt = $pdo->prepare("
        SELECT i.*, 
               CASE 
                   WHEN i.current_stock <= i.threshold_quantity THEN 'critical'
                   WHEN i.current_stock <= (i.threshold_quantity * 1.5) THEN 'low'
                   ELSE 'normal'
               END as stock_level,
               GREATEST(i.threshold_quantity * ?, 50) as suggested_order_qty,
               (GREATEST(i.threshold_quantity * ?, 50) * i.unit_price) as estimated_cost
        FROM ingredients i
        WHERE i.current_stock <= (i.threshold_quantity * 1.5)
        ORDER BY 
            CASE 
                WHEN i.current_stock <= i.threshold_quantity THEN 1
                WHEN i.current_stock <= (i.threshold_quantity * 1.5) THEN 2
                ELSE 3
            END,
            i.ingredient_name
    ");
    $threshold_multiplier = floatval($auto_settings['auto_po_threshold_multiplier']);
    $stmt->execute([$threshold_multiplier, $threshold_multiplier]);
    $low_stock_ingredients = $stmt->fetchAll();
    
    // Get suppliers
    $stmt = $pdo->prepare("
        SELECT supplier_id, supplier_name, contact_person, phone, email
        FROM suppliers
        WHERE is_active = 1
        ORDER BY supplier_name
    ");
    $stmt->execute();
    $suppliers = $stmt->fetchAll();
    
    // Get recent auto purchase orders
    $stmt = $pdo->prepare("
        SELECT po.*, s.supplier_name,
               (SELECT COUNT(*) FROM purchase_order_items WHERE po_id = po.po_id) as item_count
        FROM purchase_orders po
        LEFT JOIN suppliers s ON po.supplier_id = s.supplier_id
        WHERE po.po_number LIKE 'AUTO-PO-%'
        ORDER BY po.created_at DESC
        LIMIT 10
    ");
    $stmt->execute();
    $recent_auto_pos = $stmt->fetchAll();
    
    // Calculate statistics
    $critical_count = count(array_filter($low_stock_ingredients, function($ing) { return $ing['stock_level'] === 'critical'; }));
    $low_count = count(array_filter($low_stock_ingredients, function($ing) { return $ing['stock_level'] === 'low'; }));
    $total_estimated_cost = array_sum(array_column($low_stock_ingredients, 'estimated_cost'));
    
    // Get fund availability
    $stmt = $pdo->prepare("
        SELECT available_funds, allocated_funds, total_budget
        FROM fund_management 
        WHERE fund_type = 'purchase_orders' 
        ORDER BY created_at DESC 
        LIMIT 1
    ");
    $stmt->execute();
    $fund_info = $stmt->fetch();
    
} catch (Exception $e) {
    $error_message = "Error loading auto purchase data: " . $e->getMessage();
    $low_stock_ingredients = [];
    $suppliers = [];
    $recent_auto_pos = [];
    $auto_settings = [];
    $fund_info = null;
}

// Function to run automatic purchase check
function runAutoPurchaseCheck() {
    try {
        $pdo = getPDO();
        
        // Get auto purchase settings
        $stmt = $pdo->prepare("
            SELECT setting_key, setting_value 
            FROM system_settings 
            WHERE setting_key LIKE 'auto_po_%'
        ");
        $stmt->execute();
        $settings_data = $stmt->fetchAll();
        
        $settings = [];
        foreach ($settings_data as $setting) {
            $settings[$setting['setting_key']] = $setting['setting_value'];
        }
        
        // Check if auto generation is enabled
        if (empty($settings['auto_po_enabled']) || $settings['auto_po_enabled'] != 1) {
            return ['success' => false, 'message' => 'Auto purchase order generation is disabled.'];
        }
        
        // Get critical stock ingredients
        $stmt = $pdo->prepare("
            SELECT ingredient_id, ingredient_name, current_stock, threshold_quantity, unit_price
            FROM ingredients
            WHERE current_stock <= threshold_quantity
            AND unit_price > 0
        ");
        $stmt->execute();
        $critical_ingredients = $stmt->fetchAll();
        
        if (empty($critical_ingredients)) {
            return ['success' => true, 'message' => 'No critical stock items found. No action needed.'];
        }
        
        // Calculate total estimated cost
        $threshold_multiplier = floatval($settings['auto_po_threshold_multiplier'] ?? 3);
        $total_cost = 0;
        
        foreach ($critical_ingredients as $ingredient) {
            $suggested_qty = max($ingredient['threshold_quantity'] * $threshold_multiplier, 50);
            $total_cost += $suggested_qty * $ingredient['unit_price'];
        }
        
        $min_order_amount = floatval($settings['auto_po_min_amount'] ?? 1000);
        
        if ($total_cost < $min_order_amount) {
            return ['success' => true, 'message' => "Total estimated cost ({$total_cost}) is below minimum order amount ({$min_order_amount}). No PO generated."];
        }
        
        // Check fund availability
        $stmt = $pdo->prepare("
            SELECT available_funds 
            FROM fund_management 
            WHERE fund_type = 'purchase_orders' 
            ORDER BY created_at DESC 
            LIMIT 1
        ");
        $stmt->execute();
        $fund_info = $stmt->fetch();
        
        if (!$fund_info || $fund_info['available_funds'] < $total_cost) {
            return ['success' => false, 'message' => 'Insufficient funds for auto purchase order generation.'];
        }
        
        // Generate automatic purchase order
        $po_number = 'AUTO-PO-' . date('Ymd-His');
        $delivery_date = date('Y-m-d', strtotime('+' . ($settings['auto_po_delivery_days'] ?? 3) . ' days'));
        $supplier_id = intval($settings['auto_po_default_supplier'] ?? 0);
        
        $pdo->beginTransaction();
        
        try {
            // Create purchase order
            $stmt = $pdo->prepare("
                INSERT INTO purchase_orders (po_number, supplier_id, total_amount, delivery_date, 
                                           status, notes, created_by, created_at)
                VALUES (?, ?, ?, ?, 'pending', 'Auto-generated based on stock thresholds', 1, NOW())
            ");
            $stmt->execute([$po_number, $supplier_id, $total_cost, $delivery_date]);
            
            $po_id = $pdo->lastInsertId();
            
            // Create purchase order items
            foreach ($critical_ingredients as $ingredient) {
                $suggested_qty = max($ingredient['threshold_quantity'] * $threshold_multiplier, 50);
                $total_price = $suggested_qty * $ingredient['unit_price'];
                
                $stmt = $pdo->prepare("
                    INSERT INTO purchase_order_items (po_id, ingredient_id, ingredient_name, 
                                                     quantity, unit_price, total_price)
                    VALUES (?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $po_id, $ingredient['ingredient_id'], $ingredient['ingredient_name'],
                    $suggested_qty, $ingredient['unit_price'], $total_price
                ]);
            }
            
            // Update fund allocation
            $stmt = $pdo->prepare("
                UPDATE fund_management 
                SET allocated_funds = allocated_funds + ?,
                    available_funds = available_funds - ?
                WHERE fund_type = 'purchase_orders'
                ORDER BY created_at DESC 
                LIMIT 1
            ");
            $stmt->execute([$total_cost, $total_cost]);
            
            $pdo->commit();
            
            return ['success' => true, 'message' => "Auto purchase order {$po_number} generated successfully! Items: " . count($critical_ingredients) . ", Total: " . formatCurrency($total_cost)];
            
        } catch (Exception $e) {
            $pdo->rollBack();
            throw $e;
        }
        
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Error during auto purchase check: ' . $e->getMessage()];
    }
}

$csrf_token = generateCSRFToken();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Automatic Purchase Orders</h1>
        <p class="text-muted">Generate purchase orders automatically based on stock thresholds</p>
    </div>
    <div>
        <button type="button" class="btn btn-warning me-2" onclick="runAutoCheck()">
            <i class="fas fa-play me-2"></i>Run Auto Check
        </button>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#settingsModal">
            <i class="fas fa-cog me-2"></i>Settings
        </button>
    </div>
</div>

<?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i>
        <?php echo htmlspecialchars($success_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error_message): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Status Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon danger me-3">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Critical Stock</h6>
                    <h4 class="mb-0"><?php echo $critical_count; ?></h4>
                    <small class="text-muted">Need immediate ordering</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon warning me-3">
                    <i class="fas fa-clock"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Low Stock</h6>
                    <h4 class="mb-0"><?php echo $low_count; ?></h4>
                    <small class="text-muted">Monitor closely</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon info me-3">
                    <i class="fas fa-calculator"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Estimated Cost</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($total_estimated_cost); ?></h4>
                    <small class="text-muted">For all low stock items</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon success me-3">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Available Funds</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($fund_info['available_funds'] ?? 0); ?></h4>
                    <small class="text-muted">For purchase orders</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Auto Generation Status -->
<div class="alert alert-<?php echo $auto_settings['auto_po_enabled'] ? 'success' : 'warning'; ?>">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <i class="fas fa-<?php echo $auto_settings['auto_po_enabled'] ? 'check-circle' : 'pause-circle'; ?> me-2"></i>
            <strong>Auto Purchase Generation: <?php echo $auto_settings['auto_po_enabled'] ? 'ENABLED' : 'DISABLED'; ?></strong>
            <?php if ($auto_settings['auto_po_enabled']): ?>
                <br><small>Minimum order: <?php echo formatCurrency($auto_settings['auto_po_min_amount']); ?>, 
                Threshold multiplier: <?php echo $auto_settings['auto_po_threshold_multiplier']; ?>x</small>
            <?php endif; ?>
        </div>
        <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#settingsModal">
            Configure
        </button>
    </div>
</div>

<div class="row">
    <!-- Low Stock Ingredients -->
    <div class="col-md-8 mb-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Low Stock Ingredients
                </h5>
                <?php if (!empty($low_stock_ingredients)): ?>
                    <button type="button" class="btn btn-sm btn-primary" onclick="generateAutoPO()">
                        <i class="fas fa-plus me-2"></i>Generate PO
                    </button>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <?php if (empty($low_stock_ingredients)): ?>
                    <p class="text-center text-muted py-3 mb-0">All ingredients are well stocked!</p>
                <?php else: ?>
                    <form id="autoPOForm">
                        <div class="table-responsive">
                            <table class="table table-sm table-hover">
                                <thead>
                                    <tr>
                                        <th>
                                            <input type="checkbox" id="selectAll" onchange="toggleAllIngredients()">
                                        </th>
                                        <th>Ingredient</th>
                                        <th>Current Stock</th>
                                        <th>Threshold</th>
                                        <th>Status</th>
                                        <th>Suggested Qty</th>
                                        <th>Est. Cost</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($low_stock_ingredients as $ingredient): ?>
                                        <tr>
                                            <td>
                                                <input type="checkbox" name="ingredients[]" 
                                                       value="<?php echo $ingredient['ingredient_id']; ?>"
                                                       class="ingredient-checkbox"
                                                       <?php echo $ingredient['stock_level'] === 'critical' ? 'checked' : ''; ?>>
                                            </td>
                                            <td>
                                                <div>
                                                    <strong><?php echo htmlspecialchars($ingredient['ingredient_name']); ?></strong>
                                                    <br>
                                                    <small class="text-muted">
                                                        <span class="badge bg-secondary"><?php echo htmlspecialchars($ingredient['ingredient_code']); ?></span>
                                                        <?php echo htmlspecialchars($ingredient['unit']); ?>
                                                    </small>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="text-<?php echo $ingredient['stock_level'] === 'critical' ? 'danger' : 'warning'; ?>">
                                                    <?php echo number_format($ingredient['current_stock'], 2); ?> 
                                                    <?php echo htmlspecialchars($ingredient['unit']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php echo number_format($ingredient['threshold_quantity'], 2); ?> 
                                                <?php echo htmlspecialchars($ingredient['unit']); ?>
                                            </td>
                                            <td>
                                                <span class="badge bg-<?php echo $ingredient['stock_level'] === 'critical' ? 'danger' : 'warning'; ?>">
                                                    <?php echo ucfirst($ingredient['stock_level']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <strong><?php echo number_format($ingredient['suggested_order_qty'], 2); ?></strong>
                                                <?php echo htmlspecialchars($ingredient['unit']); ?>
                                            </td>
                                            <td>
                                                <strong><?php echo formatCurrency($ingredient['estimated_cost']); ?></strong>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Recent Auto POs -->
    <div class="col-md-4 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-history me-2"></i>
                    Recent Auto POs
                </h5>
            </div>
            <div class="card-body">
                <?php if (empty($recent_auto_pos)): ?>
                    <p class="text-center text-muted py-3 mb-0">No auto purchase orders yet</p>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach ($recent_auto_pos as $po): ?>
                            <div class="list-group-item px-0">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <strong><?php echo htmlspecialchars($po['po_number']); ?></strong>
                                        <br>
                                        <small class="text-muted">
                                            <?php echo htmlspecialchars($po['supplier_name'] ?: 'No Supplier'); ?>
                                        </small>
                                        <br>
                                        <small class="text-muted">
                                            <?php echo formatDisplayDateTime($po['created_at']); ?>
                                        </small>
                                    </div>
                                    <div class="text-end">
                                        <strong><?php echo formatCurrency($po['total_amount']); ?></strong>
                                        <br>
                                        <span class="badge bg-<?php echo $po['status'] === 'pending' ? 'warning' : ($po['status'] === 'approved' ? 'success' : 'secondary'); ?>">
                                            <?php echo ucfirst($po['status']); ?>
                                        </span>
                                        <br>
                                        <small class="text-muted"><?php echo $po['item_count']; ?> items</small>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Generate Auto PO Modal -->
<div class="modal fade" id="generatePOModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-plus me-2"></i>Generate Auto Purchase Order
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="generate_auto_po">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="selected_ingredients" id="selectedIngredients">
                
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Selected ingredients will be ordered with suggested quantities based on threshold multiplier.
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="supplier_id" class="form-label">Supplier</label>
                            <select class="form-select" id="supplier_id" name="supplier_id">
                                <option value="">Select Supplier</option>
                                <?php foreach ($suppliers as $supplier): ?>
                                    <option value="<?php echo $supplier['supplier_id']; ?>"
                                            <?php echo $supplier['supplier_id'] == $auto_settings['auto_po_default_supplier'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($supplier['supplier_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="delivery_date" class="form-label">Delivery Date *</label>
                            <input type="date" class="form-control" id="delivery_date" name="delivery_date"
                                   min="<?php echo date('Y-m-d'); ?>"
                                   value="<?php echo date('Y-m-d', strtotime('+' . $auto_settings['auto_po_delivery_days'] . ' days')); ?>" required>
                            <div class="invalid-feedback">Please select delivery date.</div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="notes" class="form-label">Notes</label>
                        <textarea class="form-control" id="notes" name="notes" rows="2"
                                  placeholder="Additional notes for this purchase order...">Auto-generated purchase order based on stock thresholds</textarea>
                    </div>
                    
                    <div id="selectedIngredientsPreview"></div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>Generate Purchase Order
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Auto Purchase Settings Modal -->
<div class="modal fade" id="settingsModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-cog me-2"></i>Auto Purchase Settings
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="update_auto_settings">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                
                <div class="modal-body">
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="auto_generation_enabled"
                                   name="auto_generation_enabled" <?php echo $auto_settings['auto_po_enabled'] ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="auto_generation_enabled">
                                <strong>Enable Automatic Purchase Order Generation</strong>
                            </label>
                        </div>
                        <small class="text-muted">When enabled, system will automatically generate POs for critical stock items</small>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="threshold_multiplier" class="form-label">Threshold Multiplier</label>
                            <input type="number" class="form-control" id="threshold_multiplier" name="threshold_multiplier"
                                   step="0.1" min="1" max="10" value="<?php echo $auto_settings['auto_po_threshold_multiplier']; ?>" required>
                            <div class="form-text">Order quantity = threshold × multiplier</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="min_order_amount" class="form-label">Minimum Order Amount (KES)</label>
                            <input type="number" class="form-control currency-input" id="min_order_amount" name="min_order_amount"
                                   step="0.01" min="0" value="<?php echo $auto_settings['auto_po_min_amount']; ?>" required>
                            <div class="form-text">Don't generate PO if total is below this amount</div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="default_supplier_id" class="form-label">Default Supplier</label>
                            <select class="form-select" id="default_supplier_id" name="default_supplier_id">
                                <option value="">No Default</option>
                                <?php foreach ($suppliers as $supplier): ?>
                                    <option value="<?php echo $supplier['supplier_id']; ?>"
                                            <?php echo $supplier['supplier_id'] == $auto_settings['auto_po_default_supplier'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($supplier['supplier_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="auto_delivery_days" class="form-label">Default Delivery Days</label>
                            <input type="number" class="form-control" id="auto_delivery_days" name="auto_delivery_days"
                                   min="1" max="30" value="<?php echo $auto_settings['auto_po_delivery_days']; ?>" required>
                            <div class="form-text">Days from today for delivery date</div>
                        </div>
                    </div>
                    
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <strong>Note:</strong> Auto-generated POs will still require manual approval before processing.
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Save Settings
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// JavaScript functions for auto purchase management
function toggleAllIngredients() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.ingredient-checkbox');
    
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAll.checked;
    });
}

function generateAutoPO() {
    const checkedBoxes = document.querySelectorAll('.ingredient-checkbox:checked');
    
    if (checkedBoxes.length === 0) {
        alert('Please select at least one ingredient to generate purchase order.');
        return;
    }
    
    // Collect selected ingredient IDs
    const selectedIds = Array.from(checkedBoxes).map(cb => cb.value);
    document.getElementById('selectedIngredients').value = JSON.stringify(selectedIds);
    
    // Update preview
    updateSelectedIngredientsPreview(selectedIds);
    
    // Show modal
    new bootstrap.Modal(document.getElementById('generatePOModal')).show();
}

function updateSelectedIngredientsPreview(selectedIds) {
    const preview = document.getElementById('selectedIngredientsPreview');
    
    if (selectedIds.length === 0) {
        preview.innerHTML = '';
        return;
    }
    
    let totalCost = 0;
    let previewHtml = '<h6>Selected Ingredients:</h6><div class="table-responsive"><table class="table table-sm"><thead><tr><th>Ingredient</th><th>Suggested Qty</th><th>Est. Cost</th></tr></thead><tbody>';
    
    selectedIds.forEach(id => {
        const row = document.querySelector(`input[value="${id}"]`).closest('tr');
        const cells = row.querySelectorAll('td');
        const ingredientName = cells[1].querySelector('strong').textContent;
        const suggestedQty = cells[5].querySelector('strong').textContent;
        const estCost = cells[6].querySelector('strong').textContent;
        
        previewHtml += `<tr><td>${ingredientName}</td><td>${suggestedQty}</td><td>${estCost}</td></tr>`;
        
        // Extract numeric value from currency string for total calculation
        const costValue = parseFloat(estCost.replace(/[^\d.-]/g, ''));
        totalCost += costValue;
    });
    
    previewHtml += `</tbody><tfoot><tr class="table-primary"><th colspan="2">Total Estimated Cost:</th><th>KES ${totalCost.toLocaleString('en-KE', {minimumFractionDigits: 2})}</th></tr></tfoot></table></div>`;
    
    preview.innerHTML = previewHtml;
}

function runAutoCheck() {
    if (confirm('Run automatic check for low stock items and generate purchase orders if needed?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="run_auto_check">
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}

// Auto-refresh data every 5 minutes
setInterval(function() {
    if (!document.querySelector('.modal.show')) {
        location.reload();
    }
}, 300000);

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
    // Update ingredient selection when checkboxes change
    document.querySelectorAll('.ingredient-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const selectAll = document.getElementById('selectAll');
            const allCheckboxes = document.querySelectorAll('.ingredient-checkbox');
            const checkedBoxes = document.querySelectorAll('.ingredient-checkbox:checked');
            
            // Update select all checkbox state
            if (checkedBoxes.length === 0) {
                selectAll.indeterminate = false;
                selectAll.checked = false;
            } else if (checkedBoxes.length === allCheckboxes.length) {
                selectAll.indeterminate = false;
                selectAll.checked = true;
            } else {
                selectAll.indeterminate = true;
            }
        });
    });
    
    // Set initial state of select all checkbox
    const allCheckboxes = document.querySelectorAll('.ingredient-checkbox');
    const checkedBoxes = document.querySelectorAll('.ingredient-checkbox:checked');
    const selectAll = document.getElementById('selectAll');
    
    if (selectAll && allCheckboxes.length > 0) {
        if (checkedBoxes.length === 0) {
            selectAll.indeterminate = false;
            selectAll.checked = false;
        } else if (checkedBoxes.length === allCheckboxes.length) {
            selectAll.indeterminate = false;
            selectAll.checked = true;
        } else {
            selectAll.indeterminate = true;
        }
    }
});
</script>

<?php require_once '../../common/footer.php'; ?>