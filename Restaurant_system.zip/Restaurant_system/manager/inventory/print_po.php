<?php
// Print Purchase Order
require_once '../../config/session.php';
require_once '../../config/functions.php';

// Check if user is logged in and has appropriate role
if (!isLoggedIn() || !hasRole(['manager', 'business_owner'])) {
    header('Location: /Restaurant_system/access_denied.php');
    exit;
}

$po_id = intval($_GET['po_id'] ?? 0);

if (!$po_id) {
    die('Invalid purchase order ID.');
}

try {
    $pdo = getPDO();
    
    // Get purchase order details
    $stmt = $pdo->prepare("
        SELECT po.*, u.full_name as created_by_name
        FROM purchase_orders po
        JOIN users u ON po.created_by = u.user_id
        WHERE po.po_id = ?
    ");
    $stmt->execute([$po_id]);
    $po = $stmt->fetch();
    
    if (!$po) {
        die('Purchase order not found.');
    }
    
    // Get purchase order items
    $stmt = $pdo->prepare("
        SELECT poi.*, i.ingredient_name, i.ingredient_code, i.unit
        FROM purchase_order_items poi
        JOIN ingredients i ON poi.ingredient_id = i.ingredient_id
        WHERE poi.po_id = ?
        ORDER BY i.ingredient_name
    ");
    $stmt->execute([$po_id]);
    $po_items = $stmt->fetchAll();
    
} catch (Exception $e) {
    die('Error loading purchase order: ' . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Order - <?php echo htmlspecialchars($po['po_number']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        @media print {
            .no-print { display: none !important; }
            body { font-size: 12px; }
            .container { max-width: none; }
        }
        
        .company-header {
            border-bottom: 3px solid #007bff;
            margin-bottom: 30px;
            padding-bottom: 20px;
        }
        
        .po-title {
            background: #007bff;
            color: white;
            padding: 10px 15px;
            margin: 20px 0;
            font-size: 1.2em;
            font-weight: bold;
        }
        
        .info-section {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .items-table th {
            background: #e9ecef;
            font-weight: bold;
        }
        
        .total-row {
            background: #007bff;
            color: white;
            font-weight: bold;
        }
        
        .signature-section {
            margin-top: 50px;
            border-top: 1px solid #dee2e6;
            padding-top: 30px;
        }
        
        .signature-box {
            border-bottom: 1px solid #000;
            height: 50px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <!-- Print Button -->
        <div class="no-print mb-3">
            <button onclick="window.print()" class="btn btn-primary">
                <i class="fas fa-print me-2"></i>Print Purchase Order
            </button>
            <button onclick="window.close()" class="btn btn-secondary ms-2">
                Close
            </button>
        </div>
        
        <!-- Company Header -->
        <div class="company-header">
            <div class="row">
                <div class="col-md-6">
                    <h2 class="mb-1">Restaurant Management System</h2>
                    <p class="mb-0 text-muted">Professional Restaurant Management</p>
                    <p class="mb-0">Phone: +254 XXX XXX XXX</p>
                    <p class="mb-0">Email: info@restaurant.com</p>
                </div>
                <div class="col-md-6 text-end">
                    <h3 class="text-primary">PURCHASE ORDER</h3>
                    <p class="mb-1"><strong>PO Number:</strong> <?php echo htmlspecialchars($po['po_number']); ?></p>
                    <p class="mb-1"><strong>Date:</strong> <?php echo formatDisplayDate($po['created_at']); ?></p>
                    <p class="mb-0"><strong>Status:</strong> 
                        <span class="badge bg-<?php echo $po['status'] === 'paid' ? 'success' : ($po['status'] === 'received' ? 'primary' : 'warning'); ?>">
                            <?php echo ucfirst($po['status']); ?>
                        </span>
                    </p>
                </div>
            </div>
        </div>
        
        <!-- Supplier Information -->
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="info-section">
                    <h5 class="mb-3">Supplier Information</h5>
                    <p class="mb-1"><strong>Supplier Name:</strong></p>
                    <p class="mb-3"><?php echo htmlspecialchars($po['supplier_name']); ?></p>
                    <p class="mb-1"><strong>Contact Information:</strong></p>
                    <p class="mb-0">Please provide contact details</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="info-section">
                    <h5 class="mb-3">Order Information</h5>
                    <p class="mb-1"><strong>Created By:</strong> <?php echo htmlspecialchars($po['created_by_name']); ?></p>
                    <p class="mb-1"><strong>Order Date:</strong> <?php echo formatDisplayDateTime($po['created_at']); ?></p>
                    <p class="mb-1"><strong>Items Count:</strong> <?php echo count($po_items); ?> items</p>
                    <p class="mb-0"><strong>Total Amount:</strong> <span class="text-success fw-bold"><?php echo formatCurrency($po['total_amount']); ?></span></p>
                </div>
            </div>
        </div>
        
        <!-- Order Items -->
        <div class="po-title">ORDER ITEMS</div>
        
        <table class="table table-bordered items-table">
            <thead>
                <tr>
                    <th width="5%">#</th>
                    <th width="30%">Ingredient Name</th>
                    <th width="15%">Code</th>
                    <th width="15%">Quantity</th>
                    <th width="15%">Unit Price</th>
                    <th width="20%">Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($po_items as $index => $item): ?>
                    <tr>
                        <td><?php echo $index + 1; ?></td>
                        <td>
                            <strong><?php echo htmlspecialchars($item['ingredient_name']); ?></strong>
                        </td>
                        <td><?php echo htmlspecialchars($item['ingredient_code']); ?></td>
                        <td><?php echo number_format($item['quantity'], 2); ?> <?php echo htmlspecialchars($item['unit']); ?></td>
                        <td><?php echo formatCurrency($item['unit_price']); ?></td>
                        <td><strong><?php echo formatCurrency($item['subtotal']); ?></strong></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr class="total-row">
                    <th colspan="5" class="text-end">TOTAL AMOUNT:</th>
                    <th><strong><?php echo formatCurrency($po['total_amount']); ?></strong></th>
                </tr>
            </tfoot>
        </table>
        
        <!-- Terms and Conditions -->
        <div class="row mt-4">
            <div class="col-12">
                <h5>Terms and Conditions:</h5>
                <ul class="small">
                    <li>All items must be delivered in good condition and within the specified timeframe.</li>
                    <li>Any damaged or incorrect items will be returned at supplier's expense.</li>
                    <li>Payment terms: Net 30 days from delivery date.</li>
                    <li>Please include this purchase order number on all correspondence and invoices.</li>
                    <li>Delivery should be made during business hours (8:00 AM - 6:00 PM).</li>
                </ul>
            </div>
        </div>
        
        <!-- Signature Section -->
        <div class="signature-section">
            <div class="row">
                <div class="col-md-4">
                    <p class="mb-1"><strong>Prepared By:</strong></p>
                    <div class="signature-box"></div>
                    <p class="small mb-0"><?php echo htmlspecialchars($po['created_by_name']); ?></p>
                    <p class="small text-muted">Manager</p>
                </div>
                <div class="col-md-4">
                    <p class="mb-1"><strong>Approved By:</strong></p>
                    <div class="signature-box"></div>
                    <p class="small mb-0">_________________</p>
                    <p class="small text-muted">Business Owner</p>
                </div>
                <div class="col-md-4">
                    <p class="mb-1"><strong>Supplier Acknowledgment:</strong></p>
                    <div class="signature-box"></div>
                    <p class="small mb-0">_________________</p>
                    <p class="small text-muted">Supplier Representative</p>
                </div>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="text-center mt-4 pt-3 border-top">
            <p class="small text-muted mb-0">
                This is a computer-generated purchase order. Generated on <?php echo date('Y-m-d H:i:s'); ?>
            </p>
        </div>
    </div>
    
    <script>
        // Auto-print when page loads (optional)
        // window.onload = function() { window.print(); }
    </script>
</body>
</html>