<?php
// Manager - Inventory Management
$page_title = 'Inventory Management';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/manager/'],
    ['title' => 'Inventory', 'url' => '']
];

require_once '../../common/header.php';
requireRole('manager');

// Handle form submissions
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!validateCSRFToken($csrf_token)) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        try {
            $pdo = getPDO();
            
            switch ($action) {
                case 'add_ingredient':
                    $ingredient_name = sanitizeInput($_POST['ingredient_name']);
                    $ingredient_code = sanitizeInput($_POST['ingredient_code']);
                    $unit = sanitizeInput($_POST['unit']);
                    $current_stock = floatval($_POST['current_stock']);
                    $threshold_quantity = floatval($_POST['threshold_quantity']);
                    $unit_price = floatval($_POST['unit_price']);
                    $supplier_info = sanitizeInput($_POST['supplier_info']);
                    
                    if (empty($ingredient_name) || empty($ingredient_code) || empty($unit)) {
                        throw new Exception('Please fill in all required fields.');
                    }
                    
                    // Check if ingredient code already exists
                    $stmt = $pdo->prepare("SELECT ingredient_id FROM ingredients WHERE ingredient_code = ?");
                    $stmt->execute([$ingredient_code]);
                    if ($stmt->fetch()) {
                        throw new Exception('Ingredient code already exists. Please choose a different code.');
                    }
                    
                    // Insert ingredient
                    $stmt = $pdo->prepare("
                        INSERT INTO ingredients (ingredient_name, ingredient_code, unit, current_stock, 
                                               threshold_quantity, unit_price, supplier_info)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $ingredient_name, $ingredient_code, $unit, $current_stock,
                        $threshold_quantity, $unit_price, $supplier_info
                    ]);
                    
                    $ingredient_id = $pdo->lastInsertId();
                    
                    // Log initial stock if any
                    if ($current_stock > 0) {
                        updateIngredientStock(
                            $ingredient_id, $current_stock, 'in', 'adjustment', 
                            null, $_SESSION['user_id'], 'Initial stock entry'
                        );
                    }
                    
                    logActivity('Ingredient Added', 'ingredients', $ingredient_id, null, [
                        'ingredient_name' => $ingredient_name,
                        'ingredient_code' => $ingredient_code,
                        'current_stock' => $current_stock
                    ]);
                    
                    $success_message = 'Ingredient added successfully!';
                    break;
                    
                case 'update_ingredient':
                    $ingredient_id = intval($_POST['ingredient_id']);
                    $ingredient_name = sanitizeInput($_POST['ingredient_name']);
                    $unit = sanitizeInput($_POST['unit']);
                    $threshold_quantity = floatval($_POST['threshold_quantity']);
                    $unit_price = floatval($_POST['unit_price']);
                    $supplier_info = sanitizeInput($_POST['supplier_info']);
                    
                    if (empty($ingredient_name) || empty($unit)) {
                        throw new Exception('Please fill in all required fields.');
                    }
                    
                    // Get old values for logging
                    $stmt = $pdo->prepare("SELECT * FROM ingredients WHERE ingredient_id = ?");
                    $stmt->execute([$ingredient_id]);
                    $old_ingredient = $stmt->fetch();
                    
                    if (!$old_ingredient) {
                        throw new Exception('Ingredient not found.');
                    }
                    
                    // Update ingredient
                    $stmt = $pdo->prepare("
                        UPDATE ingredients 
                        SET ingredient_name = ?, unit = ?, threshold_quantity = ?, 
                            unit_price = ?, supplier_info = ?
                        WHERE ingredient_id = ?
                    ");
                    $stmt->execute([
                        $ingredient_name, $unit, $threshold_quantity, 
                        $unit_price, $supplier_info, $ingredient_id
                    ]);
                    
                    logActivity('Ingredient Updated', 'ingredients', $ingredient_id, $old_ingredient, [
                        'ingredient_name' => $ingredient_name,
                        'threshold_quantity' => $threshold_quantity,
                        'unit_price' => $unit_price
                    ]);
                    
                    $success_message = 'Ingredient updated successfully!';
                    break;
                    
                case 'adjust_stock':
                    $ingredient_id = intval($_POST['ingredient_id']);
                    $adjustment_type = $_POST['adjustment_type'];
                    $quantity = floatval($_POST['quantity']);
                    $notes = sanitizeInput($_POST['notes']);
                    
                    if ($quantity <= 0) {
                        throw new Exception('Please enter a valid quantity.');
                    }
                    
                    // Get ingredient details
                    $stmt = $pdo->prepare("SELECT * FROM ingredients WHERE ingredient_id = ?");
                    $stmt->execute([$ingredient_id]);
                    $ingredient = $stmt->fetch();
                    
                    if (!$ingredient) {
                        throw new Exception('Ingredient not found.');
                    }
                    
                    // Check if adjustment would result in negative stock
                    if ($adjustment_type === 'decrease' && $ingredient['current_stock'] < $quantity) {
                        throw new Exception('Insufficient stock. Current stock: ' . $ingredient['current_stock'] . ' ' . $ingredient['unit']);
                    }
                    
                    // Update stock
                    $movement_type = $adjustment_type === 'increase' ? 'in' : 'out';
                    updateIngredientStock(
                        $ingredient_id, $quantity, $movement_type, 'adjustment',
                        null, $_SESSION['user_id'], $notes
                    );
                    
                    logActivity('Stock Adjusted', 'ingredients', $ingredient_id, null, [
                        'adjustment_type' => $adjustment_type,
                        'quantity' => $quantity,
                        'notes' => $notes
                    ]);
                    
                    $success_message = 'Stock adjusted successfully!';
                    break;
                    
                case 'recalculate_thresholds':
                    // Recalculate thresholds for all ingredients
                    $stmt = $pdo->prepare("SELECT ingredient_id FROM ingredients");
                    $stmt->execute();
                    $ingredients = $stmt->fetchAll();
                    
                    $updated_count = 0;
                    foreach ($ingredients as $ingredient) {
                        $stmt = $pdo->prepare("CALL CalculateIngredientThreshold(?)");
                        $stmt->execute([$ingredient['ingredient_id']]);
                        $updated_count++;
                    }
                    
                    logActivity('Thresholds Recalculated', null, null, null, [
                        'ingredients_updated' => $updated_count
                    ]);
                    
                    $success_message = "Thresholds recalculated for {$updated_count} ingredients!";
                    break;
            }
            
        } catch (Exception $e) {
            $error_message = $e->getMessage();
            logError($error_message);
        }
    }
}

try {
    $pdo = getPDO();
    
    // Get all ingredients with stock status
    $stmt = $pdo->prepare("
        SELECT i.*,
               CASE 
                   WHEN i.current_stock <= i.threshold_quantity THEN 'low'
                   WHEN i.current_stock <= (i.threshold_quantity * 1.5) THEN 'medium'
                   ELSE 'good'
               END as stock_status,
               (SELECT SUM(CASE WHEN sm.movement_type = 'out' THEN sm.quantity ELSE 0 END)
                FROM stock_movements sm 
                WHERE sm.ingredient_id = i.ingredient_id 
                AND sm.created_at >= DATE_SUB(CURDATE(), INTERVAL 3 DAY)
                AND sm.reference_type = 'usage') as usage_3days
        FROM ingredients i
        ORDER BY 
            CASE 
                WHEN i.current_stock <= i.threshold_quantity THEN 1
                WHEN i.current_stock <= (i.threshold_quantity * 1.5) THEN 2
                ELSE 3
            END,
            i.ingredient_name
    ");
    $stmt->execute();
    $ingredients = $stmt->fetchAll();
    
    // Get stock movement summary
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_movements,
            SUM(CASE WHEN movement_type = 'in' THEN quantity ELSE 0 END) as total_in,
            SUM(CASE WHEN movement_type = 'out' THEN quantity ELSE 0 END) as total_out
        FROM stock_movements 
        WHERE DATE(created_at) = CURDATE()
    ");
    $stmt->execute();
    $movement_summary = $stmt->fetch();
    
    // Calculate statistics
    $total_ingredients = count($ingredients);
    $low_stock_count = count(array_filter($ingredients, function($ing) { return $ing['stock_status'] === 'low'; }));
    $medium_stock_count = count(array_filter($ingredients, function($ing) { return $ing['stock_status'] === 'medium'; }));
    $good_stock_count = count(array_filter($ingredients, function($ing) { return $ing['stock_status'] === 'good'; }));
    
    // Get recent stock movements
    $stmt = $pdo->prepare("
        SELECT sm.*, i.ingredient_name, i.unit, u.full_name as user_name
        FROM stock_movements sm
        JOIN ingredients i ON sm.ingredient_id = i.ingredient_id
        JOIN users u ON sm.created_by = u.user_id
        ORDER BY sm.created_at DESC
        LIMIT 20
    ");
    $stmt->execute();
    $recent_movements = $stmt->fetchAll();
    
} catch (Exception $e) {
    $error_message = "Error loading inventory data: " . $e->getMessage();
    $ingredients = [];
    $recent_movements = [];
}

$csrf_token = generateCSRFToken();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Inventory Management</h1>
        <p class="text-muted">Monitor and manage ingredient stock levels</p>
    </div>
    <div>
        <button type="button" class="btn btn-warning me-2" onclick="recalculateThresholds()">
            <i class="fas fa-calculator me-2"></i>Recalculate Thresholds
        </button>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addIngredientModal">
            <i class="fas fa-plus me-2"></i>Add Ingredient
        </button>
    </div>
</div>

<?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i>
        <?php echo htmlspecialchars($success_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error_message): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon primary me-3">
                    <i class="fas fa-boxes"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Total Ingredients</h6>
                    <h4 class="mb-0"><?php echo $total_ingredients; ?></h4>
                    <small class="text-muted">In inventory</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon danger me-3">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Low Stock</h6>
                    <h4 class="mb-0"><?php echo $low_stock_count; ?></h4>
                    <small class="text-muted">Need restocking</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon warning me-3">
                    <i class="fas fa-clock"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Medium Stock</h6>
                    <h4 class="mb-0"><?php echo $medium_stock_count; ?></h4>
                    <small class="text-muted">Monitor closely</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon success me-3">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Good Stock</h6>
                    <h4 class="mb-0"><?php echo $good_stock_count; ?></h4>
                    <small class="text-muted">Well stocked</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Stock Status Alert -->
<?php if ($low_stock_count > 0): ?>
    <div class="alert alert-warning">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <i class="fas fa-exclamation-triangle me-2"></i>
                <strong><?php echo $low_stock_count; ?> ingredients are running low on stock!</strong>
            </div>
            <a href="/Restaurant_system/manager/inventory/purchase_orders.php" class="btn btn-sm btn-warning">
                Create Purchase Order
            </a>
        </div>
    </div>
<?php endif; ?>

<!-- Ingredients Table -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-list me-2"></i>
            Ingredients Inventory
        </h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover data-table">
                <thead>
                    <tr>
                        <th>Ingredient</th>
                        <th>Current Stock</th>
                        <th>Threshold</th>
                        <th>Status</th>
                        <th>Unit Price</th>
                        <th>3-Day Usage</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($ingredients as $ingredient): ?>
                        <tr>
                            <td>
                                <div>
                                    <strong><?php echo htmlspecialchars($ingredient['ingredient_name']); ?></strong>
                                    <br>
                                    <small class="text-muted">
                                        <span class="badge bg-secondary"><?php echo htmlspecialchars($ingredient['ingredient_code']); ?></span>
                                        <?php echo htmlspecialchars($ingredient['unit']); ?>
                                    </small>
                                </div>
                            </td>
                            <td>
                                <strong class="<?php echo $ingredient['stock_status'] === 'low' ? 'text-danger' : ($ingredient['stock_status'] === 'medium' ? 'text-warning' : 'text-success'); ?>">
                                    <?php echo number_format($ingredient['current_stock'], 2); ?> <?php echo htmlspecialchars($ingredient['unit']); ?>
                                </strong>
                            </td>
                            <td>
                                <?php echo number_format($ingredient['threshold_quantity'], 2); ?> <?php echo htmlspecialchars($ingredient['unit']); ?>
                            </td>
                            <td>
                                <?php
                                $status_classes = [
                                    'low' => 'danger',
                                    'medium' => 'warning',
                                    'good' => 'success'
                                ];
                                $status_labels = [
                                    'low' => 'Low Stock',
                                    'medium' => 'Medium',
                                    'good' => 'Good'
                                ];
                                ?>
                                <span class="badge bg-<?php echo $status_classes[$ingredient['stock_status']]; ?>">
                                    <?php echo $status_labels[$ingredient['stock_status']]; ?>
                                </span>
                            </td>
                            <td>
                                <?php echo formatCurrency($ingredient['unit_price']); ?>
                            </td>
                            <td>
                                <?php if ($ingredient['usage_3days']): ?>
                                    <span class="text-info">
                                        <?php echo number_format($ingredient['usage_3days'], 2); ?> <?php echo htmlspecialchars($ingredient['unit']); ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">No usage</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <button type="button" class="btn btn-sm btn-outline-primary" 
                                            onclick="editIngredient(<?php echo htmlspecialchars(json_encode($ingredient)); ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-success" 
                                            onclick="adjustStock(<?php echo $ingredient['ingredient_id']; ?>, '<?php echo htmlspecialchars($ingredient['ingredient_name']); ?>', <?php echo $ingredient['current_stock']; ?>, '<?php echo htmlspecialchars($ingredient['unit']); ?>')">
                                        <i class="fas fa-plus-minus"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Recent Stock Movements -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-history me-2"></i>
            Recent Stock Movements
        </h5>
    </div>
    <div class="card-body">
        <?php if (empty($recent_movements)): ?>
            <p class="text-center text-muted py-3 mb-0">No recent stock movements</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Date/Time</th>
                            <th>Ingredient</th>
                            <th>Type</th>
                            <th>Quantity</th>
                            <th>Reference</th>
                            <th>User</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_movements as $movement): ?>
                            <tr>
                                <td>
                                    <small><?php echo formatDisplayDateTime($movement['created_at']); ?></small>
                                </td>
                                <td>
                                    <strong><?php echo htmlspecialchars($movement['ingredient_name']); ?></strong>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo $movement['movement_type'] === 'in' ? 'success' : 'danger'; ?>">
                                        <?php echo $movement['movement_type'] === 'in' ? 'Stock In' : 'Stock Out'; ?>
                                    </span>
                                </td>
                                <td>
                                    <?php echo number_format($movement['quantity'], 2); ?> <?php echo htmlspecialchars($movement['unit']); ?>
                                </td>
                                <td>
                                    <span class="badge bg-info"><?php echo ucfirst($movement['reference_type']); ?></span>
                                    <?php if ($movement['notes']): ?>
                                        <br><small class="text-muted"><?php echo htmlspecialchars($movement['notes']); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <small><?php echo htmlspecialchars($movement['user_name']); ?></small>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Add Ingredient Modal -->
<div class="modal fade" id="addIngredientModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-plus me-2"></i>Add New Ingredient
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="add_ingredient">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="ingredient_name" class="form-label">Ingredient Name *</label>
                            <input type="text" class="form-control" id="ingredient_name" name="ingredient_name" required>
                            <div class="invalid-feedback">Please enter ingredient name.</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="ingredient_code" class="form-label">Ingredient Code *</label>
                            <input type="text" class="form-control" id="ingredient_code" name="ingredient_code" required>
                            <div class="invalid-feedback">Please enter ingredient code.</div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="unit" class="form-label">Unit *</label>
                            <select class="form-select" id="unit" name="unit" required>
                                <option value="">Select Unit</option>
                                <?php foreach (MEASUREMENT_UNITS as $unit_key => $unit_label): ?>
                                    <option value="<?php echo $unit_key; ?>"><?php echo $unit_label; ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback">Please select a unit.</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="current_stock" class="form-label">Current Stock</label>
                            <input type="number" class="form-control" id="current_stock" name="current_stock" 
                                   step="0.01" min="0" value="0">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="threshold_quantity" class="form-label">Threshold Quantity</label>
                            <input type="number" class="form-control" id="threshold_quantity" name="threshold_quantity" 
                                   step="0.01" min="0" value="10">
                            <div class="form-text">Minimum stock level before reordering</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="unit_price" class="form-label">Unit Price (KES)</label>
                            <input type="number" class="form-control currency-input" id="unit_price" name="unit_price" 
                                   step="0.01" min="0" value="0">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="supplier_info" class="form-label">Supplier Information</label>
                        <textarea class="form-control" id="supplier_info" name="supplier_info" rows="2" 
                                  placeholder="Supplier name, contact details, etc."></textarea>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Add Ingredient
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Ingredient Modal -->
<div class="modal fade" id="editIngredientModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-edit me-2"></i>Edit Ingredient
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="update_ingredient">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="ingredient_id" id="edit_ingredient_id">
                
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="edit_ingredient_name" class="form-label">Ingredient Name *</label>
                        <input type="text" class="form-control" id="edit_ingredient_name" name="ingredient_name" required>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="edit_unit" class="form-label">Unit *</label>
                            <select class="form-select" id="edit_unit" name="unit" required>
                                <?php foreach (MEASUREMENT_UNITS as $unit_key => $unit_label): ?>
                                    <option value="<?php echo $unit_key; ?>"><?php echo $unit_label; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="edit_threshold_quantity" class="form-label">Threshold Quantity</label>
                            <input type="number" class="form-control" id="edit_threshold_quantity" name="threshold_quantity" 
                                   step="0.01" min="0">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_unit_price" class="form-label">Unit Price (KES)</label>
                        <input type="number" class="form-control currency-input" id="edit_unit_price" name="unit_price" 
                               step="0.01" min="0">
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_supplier_info" class="form-label">Supplier Information</label>
                        <textarea class="form-control" id="edit_supplier_info" name="supplier_info" rows="2"></textarea>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Update Ingredient
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Adjust Stock Modal -->
<div class="modal fade" id="adjustStockModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-plus-minus me-2"></i>Adjust Stock
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="adjust_stock">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="ingredient_id" id="adjust_ingredient_id">
                
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Adjusting stock for <strong id="adjust_ingredient_name"></strong>
                        <br>Current stock: <strong id="adjust_current_stock"></strong>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="adjustment_type" class="form-label">Adjustment Type *</label>
                            <select class="form-select" id="adjustment_type" name="adjustment_type" required>
                                <option value="">Select Type</option>
                                <option value="increase">Increase Stock</option>
                                <option value="decrease">Decrease Stock</option>
                            </select>
                            <div class="invalid-feedback">Please select adjustment type.</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="quantity" class="form-label">Quantity *</label>
                            <input type="number" class="form-control" id="quantity" name="quantity"
                                   step="0.01" min="0.01" required>
                            <div class="invalid-feedback">Please enter a valid quantity.</div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="notes" class="form-label">Notes</label>
                        <textarea class="form-control" id="notes" name="notes" rows="2"
                                  placeholder="Reason for adjustment..."></textarea>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Adjust Stock
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// JavaScript functions for inventory management
function editIngredient(ingredient) {
    document.getElementById('edit_ingredient_id').value = ingredient.ingredient_id;
    document.getElementById('edit_ingredient_name').value = ingredient.ingredient_name;
    document.getElementById('edit_unit').value = ingredient.unit;
    document.getElementById('edit_threshold_quantity').value = ingredient.threshold_quantity;
    document.getElementById('edit_unit_price').value = ingredient.unit_price;
    document.getElementById('edit_supplier_info').value = ingredient.supplier_info || '';
    
    new bootstrap.Modal(document.getElementById('editIngredientModal')).show();
}

function adjustStock(ingredientId, ingredientName, currentStock, unit) {
    document.getElementById('adjust_ingredient_id').value = ingredientId;
    document.getElementById('adjust_ingredient_name').textContent = ingredientName;
    document.getElementById('adjust_current_stock').textContent = currentStock + ' ' + unit;
    
    // Reset form
    document.getElementById('adjustment_type').value = '';
    document.getElementById('quantity').value = '';
    document.getElementById('notes').value = '';
    
    new bootstrap.Modal(document.getElementById('adjustStockModal')).show();
}

function recalculateThresholds() {
    if (confirm('This will recalculate thresholds for all ingredients based on usage patterns. Continue?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="recalculate_thresholds">
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}

// Auto-refresh stock data every 5 minutes
setInterval(function() {
    if (!document.querySelector('.modal.show')) {
        location.reload();
    }
}, 300000);

// Initialize DataTable
document.addEventListener('DOMContentLoaded', function() {
    if (typeof $ !== 'undefined' && $.fn.DataTable) {
        // Check if DataTable is already initialized and destroy it first
        if ($.fn.DataTable.isDataTable('.data-table')) {
            $('.data-table').DataTable().destroy();
        }
        
        $('.data-table').DataTable({
            responsive: true,
            pageLength: 25,
            order: [[3, 'asc']], // Sort by status (low stock first)
            columnDefs: [
                { orderable: false, targets: [6] } // Actions column
            ]
        });
    }
});
</script>

<?php require_once '../../common/footer.php'; ?>