<?php
// Manager - Monthly Reports
$page_title = 'Monthly Reports';
$breadcrumbs = [
    ['title' => 'Dashboard', 'url' => '/Restaurant_system/manager/'],
    ['title' => 'Monthly Reports', 'url' => '']
];

require_once '../../common/header.php';
requireRole('manager');

// Get selected month and year
$selected_month = $_GET['month'] ?? date('n');
$selected_year = $_GET['year'] ?? date('Y');

try {
    $pdo = getPDO();
    
    // Sales Report for selected month
    $stmt = $pdo->prepare("
        SELECT 
            DATE(o.created_at) as order_date,
            COUNT(o.order_id) as total_orders,
            SUM(o.total_amount) as daily_revenue,
            AVG(o.total_amount) as avg_order_value
        FROM orders o
        WHERE YEAR(o.created_at) = ? 
        AND MONTH(o.created_at) = ?
        AND o.status IN ('served', 'ready')
        GROUP BY DATE(o.created_at)
        ORDER BY order_date ASC
    ");
    $stmt->execute([$selected_year, $selected_month]);
    $daily_sales = $stmt->fetchAll();
    
    // Monthly totals
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(o.order_id) as total_orders,
            SUM(o.total_amount) as total_revenue,
            AVG(o.total_amount) as avg_order_value,
            MIN(o.total_amount) as min_order,
            MAX(o.total_amount) as max_order
        FROM orders o
        WHERE YEAR(o.created_at) = ? 
        AND MONTH(o.created_at) = ?
        AND o.status IN ('served', 'ready')
    ");
    $stmt->execute([$selected_year, $selected_month]);
    $monthly_totals = $stmt->fetch();
    
    // Top selling items for the month
    $stmt = $pdo->prepare("
        SELECT 
            mi.item_name,
            mi.item_code,
            mi.price,
            SUM(oi.quantity) as total_quantity,
            SUM(oi.subtotal) as total_revenue,
            COUNT(DISTINCT o.order_id) as order_count
        FROM order_items oi
        JOIN menu_items mi ON oi.item_id = mi.item_id
        JOIN orders o ON oi.order_id = o.order_id
        WHERE YEAR(o.created_at) = ? 
        AND MONTH(o.created_at) = ?
        AND o.status IN ('served', 'ready')
        GROUP BY mi.item_id
        ORDER BY total_quantity DESC
        LIMIT 10
    ");
    $stmt->execute([$selected_year, $selected_month]);
    $top_items = $stmt->fetchAll();
    
    // Sales by category
    $stmt = $pdo->prepare("
        SELECT 
            mi.category,
            COUNT(DISTINCT mi.item_id) as items_count,
            SUM(oi.quantity) as total_quantity,
            SUM(oi.subtotal) as total_revenue
        FROM order_items oi
        JOIN menu_items mi ON oi.item_id = mi.item_id
        JOIN orders o ON oi.order_id = o.order_id
        WHERE YEAR(o.created_at) = ? 
        AND MONTH(o.created_at) = ?
        AND o.status IN ('served', 'ready')
        GROUP BY mi.category
        ORDER BY total_revenue DESC
    ");
    $stmt->execute([$selected_year, $selected_month]);
    $category_sales = $stmt->fetchAll();
    
    // Expenses Report for selected month
    $stmt = $pdo->prepare("
        SELECT 
            DATE(i.created_at) as expense_date,
            i.supplier_name,
            i.invoice_number,
            i.total_amount,
            i.status,
            po.po_number
        FROM invoices i
        LEFT JOIN purchase_orders po ON i.po_id = po.po_id
        WHERE YEAR(i.created_at) = ? 
        AND MONTH(i.created_at) = ?
        ORDER BY i.created_at DESC
    ");
    $stmt->execute([$selected_year, $selected_month]);
    $monthly_expenses = $stmt->fetchAll();
    
    // Expense totals
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(i.invoice_id) as total_invoices,
            SUM(CASE WHEN i.status = 'paid' THEN i.total_amount ELSE 0 END) as paid_amount,
            SUM(CASE WHEN i.status = 'pending' THEN i.total_amount ELSE 0 END) as pending_amount,
            SUM(i.total_amount) as total_expenses
        FROM invoices i
        WHERE YEAR(i.created_at) = ? 
        AND MONTH(i.created_at) = ?
    ");
    $stmt->execute([$selected_year, $selected_month]);
    $expense_totals = $stmt->fetch();
    
    // Sales clerk performance
    $stmt = $pdo->prepare("
        SELECT 
            u.full_name,
            u.username,
            COUNT(o.order_id) as total_orders,
            SUM(o.total_amount) as total_sales,
            AVG(o.total_amount) as avg_order_value
        FROM orders o
        JOIN users u ON o.created_by = u.user_id
        WHERE YEAR(o.created_at) = ? 
        AND MONTH(o.created_at) = ?
        AND o.status IN ('served', 'ready')
        AND u.role = 'sales_clerk'
        GROUP BY u.user_id
        ORDER BY total_sales DESC
    ");
    $stmt->execute([$selected_year, $selected_month]);
    $clerk_performance = $stmt->fetchAll();
    
    // Calculate profit/loss
    $total_revenue = $monthly_totals['total_revenue'] ?? 0;
    $total_paid_expenses = $expense_totals['paid_amount'] ?? 0;
    $net_profit = $total_revenue - $total_paid_expenses;
    
} catch (Exception $e) {
    $error_message = "Error loading report data: " . $e->getMessage();
    logError($error_message);
}

// Generate month options for dropdown
$months = [
    1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
    5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
    9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
];

$years = range(date('Y') - 2, date('Y'));
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0">Monthly Reports</h1>
        <p class="text-muted">Sales and expense reports for <?php echo $months[$selected_month] . ' ' . $selected_year; ?></p>
    </div>
    <div>
        <button type="button" class="btn btn-success me-2" onclick="exportReport()">
            <i class="fas fa-download me-2"></i>Export PDF
        </button>
        <button type="button" class="btn btn-primary" onclick="window.print()">
            <i class="fas fa-print me-2"></i>Print Report
        </button>
    </div>
</div>

<!-- Month/Year Selection -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-4">
                <label for="month" class="form-label">Month</label>
                <select class="form-select" id="month" name="month">
                    <?php foreach ($months as $num => $name): ?>
                        <option value="<?php echo $num; ?>" <?php echo $num == $selected_month ? 'selected' : ''; ?>>
                            <?php echo $name; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label for="year" class="form-label">Year</label>
                <select class="form-select" id="year" name="year">
                    <?php foreach ($years as $year): ?>
                        <option value="<?php echo $year; ?>" <?php echo $year == $selected_year ? 'selected' : ''; ?>>
                            <?php echo $year; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search me-2"></i>Generate Report
                </button>
            </div>
        </form>
    </div>
</div>

<?php if (isset($error_message)): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?php echo htmlspecialchars($error_message); ?>
    </div>
<?php endif; ?>

<!-- Summary Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon success me-3">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Total Revenue</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($total_revenue); ?></h4>
                    <small class="text-muted"><?php echo $monthly_totals['total_orders'] ?? 0; ?> orders</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon danger me-3">
                    <i class="fas fa-money-bill"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Total Expenses</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($total_paid_expenses); ?></h4>
                    <small class="text-muted"><?php echo $expense_totals['total_invoices'] ?? 0; ?> invoices</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon <?php echo $net_profit >= 0 ? 'primary' : 'warning'; ?> me-3">
                    <i class="fas fa-calculator"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Net <?php echo $net_profit >= 0 ? 'Profit' : 'Loss'; ?></h6>
                    <h4 class="mb-0 <?php echo $net_profit >= 0 ? 'text-success' : 'text-danger'; ?>">
                        <?php echo formatCurrency(abs($net_profit)); ?>
                    </h4>
                    <small class="text-muted">Revenue - Expenses</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="d-flex align-items-center">
                <div class="stats-icon info me-3">
                    <i class="fas fa-receipt"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Avg Order Value</h6>
                    <h4 class="mb-0"><?php echo formatCurrency($monthly_totals['avg_order_value'] ?? 0); ?></h4>
                    <small class="text-muted">Per order</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Charts Row -->
<div class="row mb-4">
    <div class="col-lg-8 mb-3">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-chart-area me-2"></i>
                    Daily Sales Trend
                </h5>
            </div>
            <div class="card-body">
                <canvas id="dailySalesChart" height="100"></canvas>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4 mb-3">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-chart-pie me-2"></i>
                    Sales by Category
                </h5>
            </div>
            <div class="card-body">
                <canvas id="categoryChart" height="200"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Detailed Reports -->
<div class="row">
    <!-- Top Selling Items -->
    <div class="col-lg-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-trophy me-2"></i>
                    Top Selling Items
                </h5>
            </div>
            <div class="card-body">
                <?php if (empty($top_items)): ?>
                    <p class="text-center text-muted py-3 mb-0">No sales data for this month</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Rank</th>
                                    <th>Item</th>
                                    <th>Qty Sold</th>
                                    <th>Revenue</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($top_items as $index => $item): ?>
                                    <tr>
                                        <td>
                                            <span class="badge bg-<?php echo $index < 3 ? 'warning' : 'secondary'; ?>">
                                                #<?php echo $index + 1; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($item['item_name']); ?></strong>
                                            <br>
                                            <small class="text-muted"><?php echo htmlspecialchars($item['item_code']); ?></small>
                                        </td>
                                        <td><?php echo $item['total_quantity']; ?></td>
                                        <td><?php echo formatCurrency($item['total_revenue']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Sales Clerk Performance -->
    <div class="col-lg-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-users me-2"></i>
                    Sales Clerk Performance
                </h5>
            </div>
            <div class="card-body">
                <?php if (empty($clerk_performance)): ?>
                    <p class="text-center text-muted py-3 mb-0">No sales clerk data for this month</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Clerk</th>
                                    <th>Orders</th>
                                    <th>Sales</th>
                                    <th>Avg Order</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($clerk_performance as $clerk): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($clerk['full_name']); ?></strong>
                                            <br>
                                            <small class="text-muted">@<?php echo htmlspecialchars($clerk['username']); ?></small>
                                        </td>
                                        <td><?php echo $clerk['total_orders']; ?></td>
                                        <td><?php echo formatCurrency($clerk['total_sales']); ?></td>
                                        <td><?php echo formatCurrency($clerk['avg_order_value']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Expenses Table -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-file-invoice-dollar me-2"></i>
            Monthly Expenses
        </h5>
    </div>
    <div class="card-body">
        <?php if (empty($monthly_expenses)): ?>
            <p class="text-center text-muted py-3 mb-0">No expenses recorded for this month</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Invoice #</th>
                            <th>Supplier</th>
                            <th>PO #</th>
                            <th>Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($monthly_expenses as $expense): ?>
                            <tr>
                                <td><?php echo formatDisplayDate($expense['expense_date']); ?></td>
                                <td><?php echo htmlspecialchars($expense['invoice_number']); ?></td>
                                <td><?php echo htmlspecialchars($expense['supplier_name']); ?></td>
                                <td>
                                    <?php if ($expense['po_number']): ?>
                                        <span class="badge bg-info"><?php echo htmlspecialchars($expense['po_number']); ?></span>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo formatCurrency($expense['total_amount']); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo $expense['status'] === 'paid' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($expense['status']); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr class="table-light">
                            <th colspan="4">Total Expenses</th>
                            <th><?php echo formatCurrency($expense_totals['total_expenses']); ?></th>
                            <th>
                                <small>
                                    Paid: <?php echo formatCurrency($expense_totals['paid_amount']); ?><br>
                                    Pending: <?php echo formatCurrency($expense_totals['pending_amount']); ?>
                                </small>
                            </th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
// Prepare chart data
$chart_dates = [];
$chart_revenue = [];
$chart_orders = [];

// Fill in missing dates with zero values
$days_in_month = cal_days_in_month(CAL_GREGORIAN, $selected_month, $selected_year);
for ($day = 1; $day <= $days_in_month; $day++) {
    $date = sprintf('%04d-%02d-%02d', $selected_year, $selected_month, $day);
    $chart_dates[] = date('M d', strtotime($date));
    
    // Find data for this date
    $found = false;
    foreach ($daily_sales as $sale) {
        if ($sale['order_date'] === $date) {
            $chart_revenue[] = $sale['daily_revenue'];
            $chart_orders[] = $sale['total_orders'];
            $found = true;
            break;
        }
    }
    
    if (!$found) {
        $chart_revenue[] = 0;
        $chart_orders[] = 0;
    }
}

$additional_js = "
<script>
// Daily Sales Chart
const dailySalesCtx = document.getElementById('dailySalesChart').getContext('2d');
const dailySalesChart = new Chart(dailySalesCtx, {
    type: 'line',
    data: {
        labels: [" . implode(',', array_map(function($date) { return "'$date'"; }, $chart_dates)) . "],
        datasets: [{
            label: 'Revenue',
            data: [" . implode(',', $chart_revenue) . "],
            borderColor: '#28a745',
            backgroundColor: 'rgba(40, 167, 69, 0.1)',
            borderWidth: 3,
            fill: true,
            tension: 0.4,
            yAxisID: 'y'
        }, {
            label: 'Orders',
            data: [" . implode(',', $chart_orders) . "],
            borderColor: '#007bff',
            backgroundColor: 'rgba(0, 123, 255, 0.1)',
            borderWidth: 2,
            fill: false,
            yAxisID: 'y1'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
            mode: 'index',
            intersect: false,
        },
        scales: {
            y: {
                type: 'linear',
                display: true,
                position: 'left',
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Revenue (KES)'
                },
                ticks: {
                    callback: function(value) {
                        return 'KES ' + value.toLocaleString();
                    }
                }
            },
            y1: {
                type: 'linear',
                display: true,
                position: 'right',
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Orders'
                },
                grid: {
                    drawOnChartArea: false,
                }
            }
        }
    }
});

// Category Chart
const categoryCtx = document.getElementById('categoryChart').getContext('2d');
const categoryChart = new Chart(categoryCtx, {
    type: 'doughnut',
    data: {
        labels: [" . implode(',', array_map(function($cat) { return "'" . htmlspecialchars($cat['category']) . "'"; }, $category_sales)) . "],
        datasets: [{
            data: [" . implode(',', array_column($category_sales, 'total_revenue')) . "],
            backgroundColor: [
                '#FF6384',
                '#36A2EB',
                '#FFCE56',
                '#4BC0C0',
                '#9966FF',
                '#FF9F40'
            ]
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom'
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return context.label + ': KES ' + context.parsed.toLocaleString();
                    }
                }
            }
        }
    }
});

function exportReport() {
    // Simple export functionality - in a real application, you'd generate a proper PDF
    window.print();
}
</script>
";

require_once '../../common/footer.php';
?>