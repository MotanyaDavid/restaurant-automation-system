<?php
// Main login page for Restaurant Automation System
require_once 'config/config.php';
require_once 'config/session.php';
require_once 'config/functions.php';

// Redirect if already logged in
if (isLoggedIn()) {
    $dashboard_url = getDashboardUrl($_SESSION['role']);
    header("Location: $dashboard_url");
    exit();
}

// Handle login form submission
$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitizeInput($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    // Validate CSRF token
    if (!validateCSRFToken($csrf_token)) {
        $error_message = 'Invalid security token. Please try again.';
    } elseif (empty($username) || empty($password)) {
        $error_message = 'Please enter both username and password.';
    } else {
        // Attempt to authenticate user
        $user = getUserByUsername($username);
        
        if ($user && verifyPassword($password, $user['password'])) {
            // Successful login
            setUserSession($user);
            logActivity('User Login', 'users', $user['user_id']);
            
            // Redirect to appropriate dashboard
            $dashboard_url = getDashboardUrl($user['role']);
            header("Location: $dashboard_url");
            exit();
        } else {
            $error_message = 'Invalid username or password.';
            logActivity('Failed Login Attempt', null, null, null, ['username' => $username]);
        }
    }
}

// Handle URL parameters for messages
if (isset($_GET['error'])) {
    switch ($_GET['error']) {
        case 'login_required':
            $error_message = 'Please login to access this page.';
            break;
        case 'session_timeout':
            $error_message = 'Your session has expired. Please login again.';
            break;
        case 'access_denied':
            $error_message = 'Access denied. Insufficient permissions.';
            break;
    }
}

if (isset($_GET['success'])) {
    switch ($_GET['success']) {
        case 'logout':
            $success_message = 'You have been logged out successfully.';
            break;
    }
}

// Generate CSRF token
$csrf_token = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Login</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .login-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            padding: 2.5rem;
            width: 100%;
            max-width: 450px;
            margin: 0 auto;
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .login-header h2 {
            color: #333;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .login-header p {
            color: #666;
            font-size: 0.9rem;
        }
        
        .form-floating {
            margin-bottom: 1rem;
        }
        
        .form-control {
            border: 2px solid #e1e5e9;
            border-radius: 10px;
            padding: 0.75rem 1rem;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        
        .btn-login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 10px;
            padding: 0.75rem 2rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            width: 100%;
        }
        
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
        }
        
        .alert {
            border-radius: 10px;
            border: none;
            margin-bottom: 1.5rem;
        }
        
        .user-roles {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 1rem;
            margin-top: 1.5rem;
        }
        
        .user-roles h6 {
            color: #495057;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .role-item {
            display: flex;
            align-items: center;
            margin-bottom: 0.3rem;
            font-size: 0.85rem;
            color: #6c757d;
        }
        
        .role-item i {
            width: 20px;
            margin-right: 0.5rem;
        }
        
        .footer-text {
            text-align: center;
            margin-top: 2rem;
            font-size: 0.8rem;
            color: #6c757d;
        }
        
        .system-info {
            background: #e3f2fd;
            border-radius: 10px;
            padding: 1rem;
            margin-top: 1rem;
            border-left: 4px solid #2196f3;
        }
        
        .system-info h6 {
            color: #1976d2;
            margin-bottom: 0.5rem;
        }
        
        .system-info p {
            margin: 0;
            font-size: 0.8rem;
            color: #424242;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="login-container">
                    <div class="login-header">
                        <i class="fas fa-utensils fa-3x text-primary mb-3"></i>
                        <h2><?php echo APP_NAME; ?></h2>
                        <p>Please sign in to access your dashboard</p>
                    </div>
                    
                    <?php if ($error_message): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <?php echo htmlspecialchars($error_message); ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($success_message): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle me-2"></i>
                            <?php echo htmlspecialchars($success_message); ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" id="loginForm">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        
                        <div class="form-floating">
                            <input type="text" class="form-control" id="username" name="username" 
                                   placeholder="Username" required autocomplete="username"
                                   value="<?php echo htmlspecialchars($username ?? ''); ?>">
                            <label for="username">
                                <i class="fas fa-user me-2"></i>Username
                            </label>
                        </div>
                        
                        <div class="form-floating">
                            <input type="password" class="form-control" id="password" name="password" 
                                   placeholder="Password" required autocomplete="current-password">
                            <label for="password">
                                <i class="fas fa-lock me-2"></i>Password
                            </label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-login">
                            <i class="fas fa-sign-in-alt me-2"></i>Sign In
                        </button>
                    </form>
                    
                    <!-- <div class="user-roles">
                        <h6><i class="fas fa-users me-2"></i>User Roles</h6>
                        <div class="role-item">
                            <i class="fas fa-crown text-warning"></i>
                            <span><strong>Business Owner:</strong> Full system access</span>
                        </div>
                        <div class="role-item">
                            <i class="fas fa-user-tie text-info"></i>
                            <span><strong>Manager:</strong> Operations & staff management</span>
                        </div>
                        <div class="role-item">
                            <i class="fas fa-cash-register text-success"></i>
                            <span><strong>Sales Clerk:</strong> Order processing & billing</span>
                        </div>
                    </div> -->
                    
                    <!-- <div class="system-info">
                        <h6><i class="fas fa-info-circle me-2"></i>Default Login</h6>
                        <p><strong>Username:</strong> admin</p>
                        <p><strong>Password:</strong> password</p>
                        <p><em>Change default credentials after first login</em></p>
                    </div> -->
                    
                    <div class="footer-text">
                        <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?></p>
                        <!-- <p>Version <?php echo APP_VERSION; ?></p> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Focus on username field when page loads
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('username').focus();
        });
        
        // Form validation
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value;
            
            if (!username || !password) {
                e.preventDefault();
                alert('Please enter both username and password.');
                return false;
            }
            
            // Show loading state
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Signing In...';
            submitBtn.disabled = true;
            
            // Re-enable button after 5 seconds (in case of slow response)
            setTimeout(function() {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }, 5000);
        });
        
        // Clear error messages after 5 seconds
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                if (alert.classList.contains('alert-danger')) {
                    alert.style.transition = 'opacity 0.5s';
                    alert.style.opacity = '0';
                    setTimeout(function() {
                        alert.remove();
                    }, 500);
                }
            });
        }, 5000);
    </script>
</body>
</html>