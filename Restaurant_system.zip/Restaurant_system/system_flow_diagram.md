# Restaurant Automation System - User Flow Diagrams

## System Login Flow

```mermaid
flowchart TD
    A[User Access Login Page] --> B[Enter Username & Password]
    B --> C[System Authentication]
    C --> D{Valid Credentials?}
    D -->|No| E[Show Error Message]
    E --> B
    D -->|Yes| F{Check User Role}
    F -->|Business Owner| G[Business Owner Dashboard]
    F -->|Manager| H[Manager Dashboard]
    F -->|Sales Clerk| I[Sales Clerk Dashboard]
    
    G --> G1[User Management]
    G --> G2[Financial Management]
    G --> G3[System Reports]
    G --> G4[Settings]
    
    H --> H1[Sales Clerk Management]
    H --> H2[Menu Management]
    H --> H3[Purchase Orders]
    H --> H4[Invoice Processing]
    H --> H5[Monthly Reports]
    
    I --> I1[Take Orders]
    I --> I2[View Order List]
    I --> I3[Generate Bills]
    I --> I4[Basic Reports]
```

## Order Processing Flow

```mermaid
flowchart TD
    A[Sales Clerk Takes Order] --> B[Enter Item Codes & Quantities]
    B --> C[System Calculates Total]
    C --> D[Generate Bill]
    D --> E[Update Ingredient Stock]
    E --> F{Stock Below Threshold?}
    F -->|Yes| G[Add to Purchase Order Queue]
    F -->|No| H[Order Complete]
    G --> H
    H --> I[Print Receipt]
```

## Purchase Order Flow

```mermaid
flowchart TD
    A[Daily Stock Check] --> B{Any Item Below Threshold?}
    B -->|No| C[No Action Required]
    B -->|Yes| D[Generate Purchase Order]
    D --> E[Manager Reviews PO]
    E --> F[Send to Supplier]
    F --> G[Receive Goods]
    G --> H[Manager Enters Invoice]
    H --> I{Sufficient Funds?}
    I -->|Yes| J[Generate Cheque]
    I -->|No| K[Mark as Pending Payment]
    J --> L[Update Stock Levels]
    K --> M[Notify Business Owner]
    L --> N[PO Complete]
    M --> N
```

## User Management Flow

```mermaid
flowchart TD
    A{User Role} --> B[Business Owner]
    A --> C[Manager]
    
    B --> D[Can Add/Edit/Delete]
    D --> E[Managers]
    D --> F[Sales Clerks]
    
    C --> G[Can Add/Edit/Delete]
    G --> H[Sales Clerks Only]
    
    E --> I[Create User Account]
    F --> I
    H --> I
    
    I --> J[Set Username/Password]
    J --> K[Assign Role]
    K --> L[Set Permissions]
    L --> M[Save to Database]
```

## Financial Management Flow

```mermaid
flowchart TD
    A[Business Owner] --> B[Set Available Funds]
    B --> C[System Updates Financial Settings]
    C --> D[Funds Available for Operations]
    
    E[Invoice Processing] --> F{Check Available Funds}
    F -->|Sufficient| G[Generate Cheque]
    F -->|Insufficient| H[Mark as Pending]
    
    G --> I[Deduct from Available Funds]
    H --> J[Add to Pending Payments List]
    
    I --> K[Update Financial Records]
    J --> L[Notify Business Owner]
```

## Inventory Management Flow

```mermaid
flowchart TD
    A[Order Placed] --> B[Calculate Ingredient Usage]
    B --> C[Update Stock Levels]
    C --> D[Calculate 3-Day Average Consumption]
    D --> E[Update Threshold Values]
    E --> F{Current Stock < Threshold?}
    F -->|Yes| G[Add to Purchase Order List]
    F -->|No| H[Continue Operations]
    
    I[Daily Batch Process] --> J[Check All Ingredients]
    J --> K{Any Below Threshold?}
    K -->|Yes| L[Generate Purchase Orders]
    K -->|No| M[No Action Required]
    
    G --> N[Queue for Next PO Generation]
    L --> O[Send to Manager for Review]
```

## Menu Management Flow

```mermaid
flowchart TD
    A[Manager Access Menu Management] --> B{Action Type}
    B -->|Add Item| C[Enter Item Details]
    B -->|Edit Item| D[Select Existing Item]
    B -->|Delete Item| E[Select Item to Remove]
    B -->|Update Price| F[Select Item & New Price]
    
    C --> G[Set Item Code & Name]
    G --> H[Set Price & Category]
    H --> I[Define Required Ingredients]
    I --> J[Save Menu Item]
    
    D --> K[Modify Item Details]
    K --> J
    
    E --> L[Confirm Deletion]
    L --> M[Remove from Menu]
    
    F --> N[Update Price]
    N --> O[Update Menu Cards]
    
    J --> P[Update Menu Display]
    M --> P
    O --> P
```

## Reporting System Flow

```mermaid
flowchart TD
    A{User Role} --> B[Business Owner]
    A --> C[Manager]
    A --> D[Sales Clerk]
    
    B --> E[All System Reports]
    E --> F[Financial Reports]
    E --> G[Sales Analytics]
    E --> H[User Activity]
    E --> I[Budget Analysis]
    
    C --> J[Operational Reports]
    J --> K[Monthly Sales]
    J --> L[Monthly Expenses]
    J --> M[Inventory Reports]
    J --> N[Purchase Order History]
    
    D --> O[Basic Reports]
    O --> P[Daily Sales Summary]
    O --> Q[Order History]
    O --> R[Personal Performance]
```

## System Security Flow

```mermaid
flowchart TD
    A[User Login Attempt] --> B[Validate Input]
    B --> C[Hash Password]
    C --> D[Check Database]
    D --> E{Valid User?}
    E -->|No| F[Log Failed Attempt]
    E -->|Yes| G[Create Session]
    
    F --> H[Return Error]
    G --> I[Set Session Variables]
    I --> J[Redirect to Dashboard]
    
    K[Page Access] --> L[Check Session]
    L --> M{Valid Session?}
    M -->|No| N[Redirect to Login]
    M -->|Yes| O{Correct Role?}
    O -->|No| P[Access Denied]
    O -->|Yes| Q[Allow Access]
    
    R[Session Timeout] --> S[Clear Session]
    S --> T[Redirect to Login]