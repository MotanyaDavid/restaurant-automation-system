<?php
// API endpoint for recipe ingredients
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/session.php';
require_once '../dbconnect.php';

// Check if user is logged in and has appropriate role
if (!isLoggedIn() || !hasRole(['manager', 'business_owner'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Access denied']);
    exit;
}

try {
    $pdo = getPDO();
    
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $menu_item_id = intval($_GET['menu_item_id'] ?? 0);
        
        if (empty($menu_item_id)) {
            throw new Exception('Menu item ID is required');
        }
        
        // Get recipe ingredients for the menu item
        $stmt = $pdo->prepare("
            SELECT ri.*, i.ingredient_name, i.unit, i.current_stock
            FROM recipe_ingredients ri
            JOIN ingredients i ON ri.ingredient_id = i.ingredient_id
            WHERE ri.menu_item_id = ?
            ORDER BY i.ingredient_name
        ");
        $stmt->execute([$menu_item_id]);
        $ingredients = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'ingredients' => $ingredients
        ]);
        
    } else {
        throw new Exception('Method not allowed');
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>