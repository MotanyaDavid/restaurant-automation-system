<?php
// API endpoint for order details
require_once '../config/config.php';
require_once '../config/session.php';
require_once '../config/functions.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

$order_id = intval($_GET['order_id'] ?? 0);

if (!$order_id) {
    echo json_encode(['success' => false, 'message' => 'Invalid order ID']);
    exit();
}

try {
    $pdo = getPDO();
    
    // Get order details
    $stmt = $pdo->prepare("
        SELECT o.*, u.full_name as clerk_name
        FROM orders o
        JOIN users u ON o.created_by = u.user_id
        WHERE o.order_id = ?
    ");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch();
    
    if (!$order) {
        echo json_encode(['success' => false, 'message' => 'Order not found']);
        exit();
    }
    
    // Check permissions - sales clerks can only view their own orders
    if ($_SESSION['role'] === 'sales_clerk' && $order['created_by'] != $_SESSION['user_id']) {
        echo json_encode(['success' => false, 'message' => 'Access denied']);
        exit();
    }
    
    // Get order items
    $stmt = $pdo->prepare("
        SELECT oi.*, mi.item_name, mi.item_code
        FROM order_items oi
        JOIN menu_items mi ON oi.item_id = mi.item_id
        WHERE oi.order_id = ?
        ORDER BY mi.item_name
    ");
    $stmt->execute([$order_id]);
    $order_items = $stmt->fetchAll();
    
    // Generate HTML for order details
    $html = "
    <div class='receipt-header'>
        <h4>" . getSystemSetting('restaurant_name', 'Restaurant System') . "</h4>
        <p class='mb-0'>Order Receipt</p>
    </div>
    
    <div class='receipt-details'>
        <div class='row'>
            <div class='col-6'>
                <strong>Order Number:</strong><br>
                {$order['order_number']}
            </div>
            <div class='col-6'>
                <strong>Date & Time:</strong><br>
                " . formatDisplayDateTime($order['created_at']) . "
            </div>
        </div>
        <div class='row mt-2'>
            <div class='col-6'>
                <strong>Customer:</strong><br>
                " . htmlspecialchars($order['customer_name'] ?: 'Walk-in Customer') . "
            </div>
            <div class='col-6'>
                <strong>Table:</strong><br>
                " . htmlspecialchars($order['table_number'] ?: 'N/A') . "
            </div>
        </div>
        <div class='row mt-2'>
            <div class='col-6'>
                <strong>Status:</strong><br>
                <span class='badge bg-" . ($order['status'] === 'served' ? 'success' : 'warning') . "'>" . ucfirst($order['status']) . "</span>
            </div>
            <div class='col-6'>
                <strong>Served by:</strong><br>
                " . htmlspecialchars($order['clerk_name']) . "
            </div>
        </div>
    </div>
    
    <hr>
    
    <div class='receipt-items-section'>
        <h6>Order Items</h6>
        <table class='table table-sm receipt-items'>
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>";
    
    foreach ($order_items as $item) {
        $html .= "
                <tr>
                    <td>
                        <strong>" . htmlspecialchars($item['item_name']) . "</strong><br>
                        <small class='text-muted'>" . htmlspecialchars($item['item_code']) . "</small>
                    </td>
                    <td>" . $item['quantity'] . "</td>
                    <td>" . formatCurrency($item['unit_price']) . "</td>
                    <td>" . formatCurrency($item['subtotal']) . "</td>
                </tr>";
    }
    
    $html .= "
            </tbody>
            <tfoot>
                <tr class='receipt-total'>
                    <th colspan='3'>Total Amount:</th>
                    <th>" . formatCurrency($order['total_amount']) . "</th>
                </tr>
            </tfoot>
        </table>
    </div>
    
    <hr>
    
    <div class='text-center'>
        <p class='mb-0'><strong>Thank you for your business!</strong></p>
        <small class='text-muted'>Generated on " . date('M d, Y H:i:s') . "</small>
    </div>";
    
    echo json_encode(['success' => true, 'html' => $html]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>