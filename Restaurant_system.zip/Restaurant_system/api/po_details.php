<?php
// API endpoint for purchase order details
require_once '../config/session.php';
require_once '../config/functions.php';

// Check if user is logged in and has appropriate role
if (!isLoggedIn() || !hasRole(['manager', 'business_owner'])) {
    http_response_code(403);
    echo '<div class="alert alert-danger">Access denied.</div>';
    exit;
}

$po_id = intval($_GET['po_id'] ?? 0);

if (!$po_id) {
    echo '<div class="alert alert-danger">Invalid purchase order ID.</div>';
    exit;
}

try {
    $pdo = getPDO();
    
    // Get purchase order details
    $stmt = $pdo->prepare("
        SELECT po.*, u.full_name as created_by_name
        FROM purchase_orders po
        JOIN users u ON po.created_by = u.user_id
        WHERE po.po_id = ?
    ");
    $stmt->execute([$po_id]);
    $po = $stmt->fetch();
    
    if (!$po) {
        echo '<div class="alert alert-danger">Purchase order not found.</div>';
        exit;
    }
    
    // Get purchase order items
    $stmt = $pdo->prepare("
        SELECT poi.*, i.ingredient_name, i.ingredient_code, i.unit
        FROM purchase_order_items poi
        JOIN ingredients i ON poi.ingredient_id = i.ingredient_id
        WHERE poi.po_id = ?
        ORDER BY i.ingredient_name
    ");
    $stmt->execute([$po_id]);
    $po_items = $stmt->fetchAll();
    
} catch (Exception $e) {
    echo '<div class="alert alert-danger">Error loading purchase order details: ' . htmlspecialchars($e->getMessage()) . '</div>';
    exit;
}

// Set current PO ID for printing
echo "<script>currentPOId = {$po_id};</script>";
?>

<div class="row mb-3">
    <div class="col-md-6">
        <h6 class="text-muted">Purchase Order Information</h6>
        <table class="table table-sm">
            <tr>
                <td><strong>PO Number:</strong></td>
                <td><?php echo htmlspecialchars($po['po_number']); ?></td>
            </tr>
            <tr>
                <td><strong>Supplier:</strong></td>
                <td><?php echo htmlspecialchars($po['supplier_name']); ?></td>
            </tr>
            <tr>
                <td><strong>Status:</strong></td>
                <td>
                    <?php
                    $status_classes = [
                        'pending' => 'warning',
                        'ordered' => 'info',
                        'received' => 'primary',
                        'paid' => 'success'
                    ];
                    ?>
                    <span class="badge bg-<?php echo $status_classes[$po['status']] ?? 'secondary'; ?>">
                        <?php echo ucfirst($po['status']); ?>
                    </span>
                </td>
            </tr>
            <tr>
                <td><strong>Total Amount:</strong></td>
                <td><strong class="text-success"><?php echo formatCurrency($po['total_amount']); ?></strong></td>
            </tr>
        </table>
    </div>
    
    <div class="col-md-6">
        <h6 class="text-muted">Order Details</h6>
        <table class="table table-sm">
            <tr>
                <td><strong>Created By:</strong></td>
                <td><?php echo htmlspecialchars($po['created_by_name']); ?></td>
            </tr>
            <tr>
                <td><strong>Created Date:</strong></td>
                <td><?php echo formatDisplayDateTime($po['created_at']); ?></td>
            </tr>
            <tr>
                <td><strong>Items Count:</strong></td>
                <td><?php echo count($po_items); ?> items</td>
            </tr>
            <?php if ($po['updated_at'] && $po['updated_at'] !== $po['created_at']): ?>
            <tr>
                <td><strong>Last Updated:</strong></td>
                <td><?php echo formatDisplayDateTime($po['updated_at']); ?></td>
            </tr>
            <?php endif; ?>
        </table>
    </div>
</div>

<h6 class="text-muted mb-3">Order Items</h6>
<div class="table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Ingredient</th>
                <th>Code</th>
                <th>Quantity</th>
                <th>Unit Price</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($po_items as $item): ?>
                <tr>
                    <td>
                        <strong><?php echo htmlspecialchars($item['ingredient_name']); ?></strong>
                    </td>
                    <td>
                        <span class="badge bg-secondary"><?php echo htmlspecialchars($item['ingredient_code']); ?></span>
                    </td>
                    <td>
                        <?php echo number_format($item['quantity'], 2); ?> <?php echo htmlspecialchars($item['unit']); ?>
                    </td>
                    <td>
                        <?php echo formatCurrency($item['unit_price']); ?>
                    </td>
                    <td>
                        <strong><?php echo formatCurrency($item['subtotal']); ?></strong>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr class="table-info">
                <th colspan="4" class="text-end">Total Amount:</th>
                <th><strong class="text-success"><?php echo formatCurrency($po['total_amount']); ?></strong></th>
            </tr>
        </tfoot>
    </table>
</div>

<?php if ($po['status'] === 'pending' || $po['status'] === 'ordered'): ?>
    <div class="alert alert-info">
        <i class="fas fa-info-circle me-2"></i>
        <strong>Note:</strong> This purchase order is still <?php echo $po['status']; ?>. 
        <?php if ($po['status'] === 'ordered'): ?>
            Mark as "Received" to update ingredient stock levels.
        <?php endif; ?>
    </div>
<?php elseif ($po['status'] === 'received'): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle me-2"></i>
        <strong>Received:</strong> This purchase order has been received and ingredient stock levels have been updated.
    </div>
<?php endif; ?>