<?php
// Common utility functions for the Restaurant System

// Include database connection
require_once __DIR__ . '/../dbconnect.php';

// Sanitize input data
function sanitizeInput($data) {
    if (is_array($data)) {
        return array_map('sanitizeInput', $data);
    }
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

// Validate email format
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

// Validate phone number (basic validation)
function isValidPhone($phone) {
    return preg_match('/^[0-9+\-\s()]{10,15}$/', $phone);
}

// Generate unique order number
function generateOrderNumber() {
    return 'ORD' . date('Ymd') . str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
}

// Generate unique purchase order number
function generatePONumber() {
    return 'PO' . date('Ymd') . str_pad(mt_rand(1, 999), 3, '0', STR_PAD_LEFT);
}

// Generate unique invoice number
function generateInvoiceNumber() {
    return 'INV' . date('Ymd') . str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
}

// Format currency
function formatCurrency($amount, $currency = 'KES') {
    return $currency . ' ' . number_format($amount, 2);
}

// Format date for display
function formatDate($date, $format = 'Y-m-d H:i:s') {
    if ($date instanceof DateTime) {
        return $date->format($format);
    }
    return date($format, strtotime($date));
}

// Format date for display (user-friendly)
function formatDisplayDate($date) {
    return date('M d, Y', strtotime($date));
}

// Format datetime for display (user-friendly)
function formatDisplayDateTime($datetime) {
    return date('M d, Y g:i A', strtotime($datetime));
}

// Get system setting value
function getSystemSetting($key, $default = null) {
    try {
        $pdo = getPDO();
        $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $result = $stmt->fetch();
        
        return $result ? $result['setting_value'] : $default;
    } catch (Exception $e) {
        error_log("Error getting system setting: " . $e->getMessage());
        return $default;
    }
}

// Update system setting
function updateSystemSetting($key, $value, $user_id) {
    try {
        $pdo = getPDO();
        $stmt = $pdo->prepare("
            INSERT INTO system_settings (setting_key, setting_value, updated_by) 
            VALUES (?, ?, ?) 
            ON DUPLICATE KEY UPDATE 
            setting_value = VALUES(setting_value), 
            updated_by = VALUES(updated_by),
            updated_at = CURRENT_TIMESTAMP
        ");
        
        return $stmt->execute([$key, $value, $user_id]);
    } catch (Exception $e) {
        error_log("Error updating system setting: " . $e->getMessage());
        return false;
    }
}

// Get available funds
function getAvailableFunds() {
    try {
        $pdo = getPDO();
        $stmt = $pdo->prepare("SELECT available_funds FROM financial_settings ORDER BY id DESC LIMIT 1");
        $stmt->execute();
        $result = $stmt->fetch();
        
        return $result ? floatval($result['available_funds']) : 0.00;
    } catch (Exception $e) {
        error_log("Error getting available funds: " . $e->getMessage());
        return 0.00;
    }
}

// Update available funds
function updateAvailableFunds($amount, $user_id) {
    try {
        $pdo = getPDO();
        $stmt = $pdo->prepare("
            INSERT INTO financial_settings (available_funds, updated_by) 
            VALUES (?, ?)
        ");
        
        return $stmt->execute([$amount, $user_id]);
    } catch (Exception $e) {
        error_log("Error updating available funds: " . $e->getMessage());
        return false;
    }
}

// Check if ingredient stock is below threshold
function isStockBelowThreshold($ingredient_id) {
    try {
        $pdo = getPDO();
        $stmt = $pdo->prepare("
            SELECT current_stock, threshold_quantity 
            FROM ingredients 
            WHERE ingredient_id = ?
        ");
        $stmt->execute([$ingredient_id]);
        $result = $stmt->fetch();
        
        if ($result) {
            return floatval($result['current_stock']) <= floatval($result['threshold_quantity']);
        }
        
        return false;
    } catch (Exception $e) {
        error_log("Error checking stock threshold: " . $e->getMessage());
        return false;
    }
}

// Get low stock ingredients
function getLowStockIngredients() {
    try {
        $pdo = getPDO();
        $stmt = $pdo->prepare("
            SELECT ingredient_id, ingredient_name, ingredient_code, 
                   current_stock, threshold_quantity, unit,
                   (threshold_quantity - current_stock) as shortage_quantity
            FROM ingredients 
            WHERE current_stock <= threshold_quantity
            ORDER BY (current_stock / threshold_quantity) ASC
        ");
        $stmt->execute();
        
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("Error getting low stock ingredients: " . $e->getMessage());
        return [];
    }
}

// Update ingredient stock
function updateIngredientStock($ingredient_id, $quantity, $movement_type, $reference_type, $reference_id = null, $user_id = null, $notes = null) {
    try {
        $pdo = getPDO();
        $pdo->beginTransaction();
        
        // Update ingredient stock
        if ($movement_type === 'in') {
            $stmt = $pdo->prepare("
                UPDATE ingredients 
                SET current_stock = current_stock + ?, updated_at = CURRENT_TIMESTAMP 
                WHERE ingredient_id = ?
            ");
        } else {
            $stmt = $pdo->prepare("
                UPDATE ingredients 
                SET current_stock = current_stock - ?, updated_at = CURRENT_TIMESTAMP 
                WHERE ingredient_id = ?
            ");
        }
        
        $stmt->execute([$quantity, $ingredient_id]);
        
        // Log stock movement
        $stmt = $pdo->prepare("
            INSERT INTO stock_movements (ingredient_id, movement_type, quantity, reference_type, reference_id, notes, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $ingredient_id,
            $movement_type,
            $quantity,
            $reference_type,
            $reference_id,
            $notes,
            $user_id
        ]);
        
        $pdo->commit();
        return true;
        
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("Error updating ingredient stock: " . $e->getMessage());
        return false;
    }
}

// Get menu item with ingredients
function getMenuItemWithIngredients($item_id) {
    try {
        $pdo = getPDO();
        
        // Get menu item details
        $stmt = $pdo->prepare("
            SELECT * FROM menu_items WHERE item_id = ?
        ");
        $stmt->execute([$item_id]);
        $item = $stmt->fetch();
        
        if (!$item) {
            return null;
        }
        
        // Get required ingredients
        $stmt = $pdo->prepare("
            SELECT i.ingredient_id, i.ingredient_name, i.unit, 
                   mii.quantity_required, i.current_stock
            FROM menu_item_ingredients mii
            JOIN ingredients i ON mii.ingredient_id = i.ingredient_id
            WHERE mii.item_id = ?
        ");
        $stmt->execute([$item_id]);
        $item['ingredients'] = $stmt->fetchAll();
        
        return $item;
    } catch (Exception $e) {
        error_log("Error getting menu item with ingredients: " . $e->getMessage());
        return null;
    }
}

// Check if order can be fulfilled (enough ingredients)
function canFulfillOrder($order_items) {
    try {
        $pdo = getPDO();
        
        foreach ($order_items as $item) {
            $item_id = $item['item_id'];
            $quantity = $item['quantity'];
            
            // Get required ingredients for this menu item
            $stmt = $pdo->prepare("
                SELECT i.ingredient_id, i.ingredient_name, i.current_stock,
                       mii.quantity_required
                FROM menu_item_ingredients mii
                JOIN ingredients i ON mii.ingredient_id = i.ingredient_id
                WHERE mii.item_id = ?
            ");
            $stmt->execute([$item_id]);
            $ingredients = $stmt->fetchAll();
            
            // Check if we have enough of each ingredient
            foreach ($ingredients as $ingredient) {
                $required = $ingredient['quantity_required'] * $quantity;
                if ($ingredient['current_stock'] < $required) {
                    return [
                        'can_fulfill' => false,
                        'missing_ingredient' => $ingredient['ingredient_name'],
                        'required' => $required,
                        'available' => $ingredient['current_stock']
                    ];
                }
            }
        }
        
        return ['can_fulfill' => true];
        
    } catch (Exception $e) {
        error_log("Error checking order fulfillment: " . $e->getMessage());
        return ['can_fulfill' => false, 'error' => $e->getMessage()];
    }
}

// Generate alert message HTML
function generateAlert($type, $message, $dismissible = true) {
    $alert_class = 'alert-' . $type;
    $dismiss_button = $dismissible ? '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>' : '';
    
    return "
    <div class='alert {$alert_class} " . ($dismissible ? 'alert-dismissible' : '') . " fade show' role='alert'>
        {$message}
        {$dismiss_button}
    </div>";
}

// Validate password strength
function isStrongPassword($password) {
    // At least 8 characters, contains uppercase, lowercase, number
    return strlen($password) >= 8 && 
           preg_match('/[A-Z]/', $password) && 
           preg_match('/[a-z]/', $password) && 
           preg_match('/[0-9]/', $password);
}

// Hash password
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

// Verify password
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// Get user by username
function getUserByUsername($username) {
    try {
        $pdo = getPDO();
        $stmt = $pdo->prepare("
            SELECT user_id, username, password, full_name, email, phone, role, status
            FROM users 
            WHERE username = ? AND status = 'active'
        ");
        $stmt->execute([$username]);
        
        return $stmt->fetch();
    } catch (Exception $e) {
        error_log("Error getting user by username: " . $e->getMessage());
        return false;
    }
}

// Get user by ID
function getUserById($user_id) {
    try {
        $pdo = getPDO();
        $stmt = $pdo->prepare("
            SELECT user_id, username, full_name, email, phone, role, status, created_at
            FROM users 
            WHERE user_id = ?
        ");
        $stmt->execute([$user_id]);
        
        return $stmt->fetch();
    } catch (Exception $e) {
        error_log("Error getting user by ID: " . $e->getMessage());
        return false;
    }
}

// Log error to file
function logError($message, $file = null, $line = null) {
    $log_message = date('Y-m-d H:i:s') . " - " . $message;
    if ($file) {
        $log_message .= " in " . $file;
    }
    if ($line) {
        $log_message .= " on line " . $line;
    }
    
    error_log($log_message);
}

// Redirect with message
function redirectWithMessage($url, $message, $type = 'info') {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = $type;
    header("Location: $url");
    exit();
}

// Get and clear flash message
function getFlashMessage() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (isset($_SESSION['flash_message'])) {
        $message = $_SESSION['flash_message'];
        $type = $_SESSION['flash_type'] ?? 'info';
        unset($_SESSION['flash_message'], $_SESSION['flash_type']);
        return ['message' => $message, 'type' => $type];
    }
    return null;
}

// Pagination helper
function paginate($total_records, $records_per_page, $current_page) {
    $total_pages = ceil($total_records / $records_per_page);
    $offset = ($current_page - 1) * $records_per_page;
    
    return [
        'total_pages' => $total_pages,
        'current_page' => $current_page,
        'offset' => $offset,
        'limit' => $records_per_page,
        'has_previous' => $current_page > 1,
        'has_next' => $current_page < $total_pages
    ];
}
?>