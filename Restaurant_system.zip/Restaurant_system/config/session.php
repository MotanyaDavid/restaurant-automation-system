<?php
// Session management and security functions
// Start session with secure settings
if (session_status() === PHP_SESSION_NONE) {
    // Set secure session parameters
    ini_set('session.cookie_httponly', 1);
    ini_set('session.cookie_secure', 0); // Set to 1 for HTTPS
    ini_set('session.use_strict_mode', 1);
    ini_set('session.cookie_samesite', 'Strict');
    
    // Set session timeout (30 minutes)
    ini_set('session.gc_maxlifetime', 1800);
    
    session_start();
}

// Regenerate session ID for security
function regenerateSession() {
    session_regenerate_id(true);
}

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['username']) && isset($_SESSION['role']);
}

// Check if user has specific role
function hasRole($required_role) {
    if (!isLoggedIn()) {
        return false;
    }
    
    $user_role = $_SESSION['role'];
    
    // Business owner has access to everything
    if ($user_role === 'business_owner') {
        return true;
    }
    
    // Manager has access to manager and sales_clerk functions
    if ($user_role === 'manager' && in_array($required_role, ['manager', 'sales_clerk'])) {
        return true;
    }
    
    // Sales clerk only has access to sales_clerk functions
    if ($user_role === 'sales_clerk' && $required_role === 'sales_clerk') {
        return true;
    }
    
    return $user_role === $required_role;
}

// Require login - redirect to login page if not logged in
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: /Restaurant_system/index.php?error=login_required');
        exit();
    }
}

// Require specific role - show access denied if insufficient permissions
function requireRole($required_role) {
    requireLogin();
    
    if (!hasRole($required_role)) {
        header('Location: /Restaurant_system/access_denied.php');
        exit();
    }
}

// Set user session data after successful login
function setUserSession($user_data) {
    $_SESSION['user_id'] = $user_data['user_id'];
    $_SESSION['username'] = $user_data['username'];
    $_SESSION['full_name'] = $user_data['full_name'];
    $_SESSION['email'] = $user_data['email'];
    $_SESSION['role'] = $user_data['role'];
    $_SESSION['login_time'] = time();
    $_SESSION['last_activity'] = time();
    
    // Regenerate session ID for security
    regenerateSession();
}

// Update last activity time
function updateLastActivity() {
    if (isLoggedIn()) {
        $_SESSION['last_activity'] = time();
    }
}

// Check session timeout
function checkSessionTimeout() {
    if (isLoggedIn()) {
        $timeout = 1800; // 30 minutes
        
        if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
            destroySession();
            header('Location: /Restaurant_system/index.php?error=session_timeout');
            exit();
        }
        
        updateLastActivity();
    }
}

// Destroy session and logout user
function destroySession() {
    if (session_status() === PHP_SESSION_ACTIVE) {
        $_SESSION = array();
        
        // Delete session cookie
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        
        session_destroy();
    }
}

// Get user role display name
function getRoleDisplayName($role) {
    switch ($role) {
        case 'business_owner':
            return 'Business Owner';
        case 'manager':
            return 'Manager';
        case 'sales_clerk':
            return 'Sales Clerk';
        default:
            return 'Unknown';
    }
}

// Get dashboard URL based on user role
function getDashboardUrl($role) {
    switch ($role) {
        case 'business_owner':
            return '/Restaurant_system/business_owner/';
        case 'manager':
            return '/Restaurant_system/manager/';
        case 'sales_clerk':
            return '/Restaurant_system/sales_clerk/';
        default:
            return '/Restaurant_system/';
    }
}

// Log user activity
function logActivity($action, $table_name = null, $record_id = null, $old_values = null, $new_values = null) {
    if (!isLoggedIn()) {
        return false;
    }
    
    try {
        require_once __DIR__ . '/../dbconnect.php';
        $pdo = getPDO();
        
        $stmt = $pdo->prepare("
            INSERT INTO activity_logs (user_id, action, table_name, record_id, old_values, new_values, ip_address, user_agent, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([
            $_SESSION['user_id'],
            $action,
            $table_name,
            $record_id,
            $old_values ? json_encode($old_values) : null,
            $new_values ? json_encode($new_values) : null,
            $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
        ]);
        
        return true;
    } catch (Exception $e) {
        error_log("Activity logging failed: " . $e->getMessage());
        return false;
    }
}

// CSRF Protection
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function validateCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Initialize session security
checkSessionTimeout();
?>