<?php
// System Configuration Constants
// Restaurant Automation System

// Application Information
define('APP_NAME', 'Fork & Spoon');
define('APP_VERSION', '1.0.0');
define('APP_AUTHOR', 'Restaurant Management Team');

// Base URLs and Paths
define('BASE_URL', '/Restaurant_system');
define('BASE_PATH', __DIR__ . '/..');
define('ASSETS_URL', BASE_URL . '/assets');
define('UPLOADS_PATH', BASE_PATH . '/uploads');

// Database Configuration (imported from dbconnect.php)
define('DB_HOST', 'localhost');
define('DB_NAME', 'restaurant_system');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Security Settings
define('SESSION_TIMEOUT', 1800); // 30 minutes
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 minutes
define('CSRF_TOKEN_EXPIRE', 3600); // 1 hour

// Password Requirements
define('MIN_PASSWORD_LENGTH', 8);
define('REQUIRE_UPPERCASE', true);
define('REQUIRE_LOWERCASE', true);
define('REQUIRE_NUMBERS', true);
define('REQUIRE_SPECIAL_CHARS', false);

// File Upload Settings
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif']);
define('ALLOWED_DOCUMENT_TYPES', ['pdf', 'doc', 'docx', 'xls', 'xlsx']);

// Business Logic Settings
define('DEFAULT_CURRENCY', 'KES');
define('CURRENCY_SYMBOL', 'KES');
define('TAX_RATE', 16.00); // 16% VAT
define('MIN_STOCK_DAYS', 2); // Minimum stock days to maintain
define('THRESHOLD_CALCULATION_DAYS', 3); // Days for threshold calculation

// Order Settings
define('ORDER_NUMBER_PREFIX', 'ORD');
define('PO_NUMBER_PREFIX', 'PO');
define('INVOICE_NUMBER_PREFIX', 'INV');
define('CHEQUE_NUMBER_PREFIX', 'CHQ');

// Pagination Settings
define('RECORDS_PER_PAGE', 20);
define('MAX_RECORDS_PER_PAGE', 100);

// Date and Time Settings
define('DEFAULT_TIMEZONE', 'Africa/Nairobi');
define('DATE_FORMAT', 'Y-m-d');
define('DATETIME_FORMAT', 'Y-m-d H:i:s');
define('DISPLAY_DATE_FORMAT', 'M d, Y');
define('DISPLAY_DATETIME_FORMAT', 'M d, Y g:i A');

// Email Settings (for future use)
define('SMTP_HOST', 'localhost');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', '');
define('SMTP_PASSWORD', '');
define('FROM_EMAIL', 'noreply@restaurant.com');
define('FROM_NAME', 'Restaurant System');

// Logging Settings
define('ENABLE_LOGGING', true);
define('LOG_LEVEL', 'INFO'); // DEBUG, INFO, WARNING, ERROR
define('LOG_FILE_PATH', BASE_PATH . '/logs/');
define('MAX_LOG_FILE_SIZE', 10 * 1024 * 1024); // 10MB

// Cache Settings
define('ENABLE_CACHE', false);
define('CACHE_DURATION', 3600); // 1 hour
define('CACHE_PATH', BASE_PATH . '/cache/');

// Menu Categories
define('MENU_CATEGORIES', [
    'Appetizers',
    'Main Course',
    'Fast Food',
    'Light Meals',
    'Beverages',
    'Desserts',
    'Specials'
]);

// User Roles and Permissions
define('USER_ROLES', [
    'business_owner' => 'Business Owner',
    'manager' => 'Manager',
    'sales_clerk' => 'Sales Clerk'
]);

// Order Status Options
define('ORDER_STATUSES', [
    'pending' => 'Pending',
    'preparing' => 'Preparing',
    'ready' => 'Ready',
    'served' => 'Served',
    'cancelled' => 'Cancelled'
]);

// Purchase Order Status Options
define('PO_STATUSES', [
    'pending' => 'Pending',
    'ordered' => 'Ordered',
    'received' => 'Received',
    'paid' => 'Paid'
]);

// Invoice Status Options
define('INVOICE_STATUSES', [
    'pending' => 'Pending Payment',
    'paid' => 'Paid'
]);

// Stock Movement Types
define('STOCK_MOVEMENT_TYPES', [
    'in' => 'Stock In',
    'out' => 'Stock Out'
]);

// Reference Types for Stock Movements
define('STOCK_REFERENCE_TYPES', [
    'purchase' => 'Purchase',
    'usage' => 'Usage',
    'adjustment' => 'Adjustment'
]);

// Units of Measurement
define('MEASUREMENT_UNITS', [
    'kg' => 'Kilograms',
    'g' => 'Grams',
    'liters' => 'Liters',
    'ml' => 'Milliliters',
    'pieces' => 'Pieces',
    'packets' => 'Packets',
    'boxes' => 'Boxes',
    'bottles' => 'Bottles',
    'cans' => 'Cans',
    'loaves' => 'Loaves'
]);

// Payment Methods
define('PAYMENT_METHODS', [
    'cash' => 'Cash',
    'cheque' => 'Cheque',
    'bank_transfer' => 'Bank Transfer',
    'mobile_money' => 'Mobile Money'
]);

// Report Types
define('REPORT_TYPES', [
    'daily_sales' => 'Daily Sales Report',
    'monthly_sales' => 'Monthly Sales Report',
    'inventory' => 'Inventory Report',
    'financial' => 'Financial Report',
    'user_activity' => 'User Activity Report'
]);

// System Messages
define('SUCCESS_MESSAGES', [
    'login' => 'Login successful! Welcome back.',
    'logout' => 'You have been logged out successfully.',
    'save' => 'Data saved successfully.',
    'update' => 'Data updated successfully.',
    'delete' => 'Data deleted successfully.',
    'order_placed' => 'Order placed successfully.',
    'payment_processed' => 'Payment processed successfully.'
]);

define('ERROR_MESSAGES', [
    'login_failed' => 'Invalid username or password.',
    'access_denied' => 'Access denied. Insufficient permissions.',
    'session_expired' => 'Your session has expired. Please login again.',
    'invalid_data' => 'Invalid data provided.',
    'database_error' => 'Database error occurred. Please try again.',
    'file_upload_error' => 'File upload failed.',
    'insufficient_stock' => 'Insufficient stock to fulfill this order.',
    'insufficient_funds' => 'Insufficient funds to process this payment.'
]);

// Set default timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Error reporting (adjust for production)
if (defined('ENVIRONMENT') && constant('ENVIRONMENT') === 'production') {
    error_reporting(0);
    ini_set('display_errors', 0);
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
}

// Create necessary directories if they don't exist
$directories = [
    UPLOADS_PATH,
    LOG_FILE_PATH,
    CACHE_PATH
];

foreach ($directories as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
}

// Helper function to get configuration value
function getConfig($key, $default = null) {
    return defined($key) ? constant($key) : $default;
}

// Helper function to check if feature is enabled
function isFeatureEnabled($feature) {
    $constant_name = 'ENABLE_' . strtoupper($feature);
    return defined($constant_name) && constant($constant_name) === true;
}
?>