<?php
// Database configuration
$servername = "localhost";
$username = "root"; // default MySQL username
$password = ""; // default MySQL password (empty for XAMPP)
$dbname = "restaurant_system";

try {
    // Create PDO connection for better security and functionality
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8mb4", $username, $password);
    
    // Set PDO attributes for better error handling
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    
    // Also create MySQLi connection for compatibility
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check MySQLi connection
    if ($conn->connect_error) {
        throw new Exception("MySQLi Connection failed: " . $conn->connect_error);
    }
    
    // Set charset for MySQLi
    $conn->set_charset("utf8mb4");
    
} catch(PDOException $e) {
    die("❌ Database Connection Error: " . $e->getMessage());
} catch(Exception $e) {
    die("❌ Connection Error: " . $e->getMessage());
}

// Function to get PDO connection
function getPDO() {
    global $pdo;
    return $pdo;
}

// Function to get MySQLi connection
function getMySQLi() {
    global $conn;
    return $conn;
}

// Don't close connection here - let individual scripts handle it
?>